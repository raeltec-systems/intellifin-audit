## 2026-09-30 — Accepted Zobba revision 3 and brownfield course correction

The owner accepted revision 3 and requested active-document consolidation,
implementation planning, Pair screen updates and sized operating costs. Use
[`ACTIVE-BASELINE.md`](_bmad-output/planning-artifacts/ACTIVE-BASELINE.md) as the
current entry point. Existing PRD/architecture paths are updated in place; active
UX is `ux-Zobba-2026-09-25`. The SPEC is re-derived through `bmad-spec` with CAP-17–30.
Retired IDs retain historical meaning; exact prior artifacts are archived.

This is the `bmad-correct-course` path, followed by `bmad-create-epics-and-stories`
and `bmad-sprint-planning`. New stories start at Epic 20. Keep the standard
`implementation-artifacts/sprint-status.yaml` as the active queue because
`bmad-build` resolves that fixed name; a parallel named queue would be ignored.
The old queue is archived without changing statuses. `bmad-build` should receive
explicit new story IDs; legacy unfinished specs on disk are not new-build work.

The operating budget lives in `zobba-operating-budget-2026-09-30/` and replaces
the prior $300 allowance with sized shared services and explicit customer/model
consumption. Region, app qualification and commercial terms are assumptions/gates,
not deployment approval. The accepted revision3 package remains a dated design
snapshot; the implementation handoff is the current delivery view. Pair screens
are verified prototypes, not live computers or implemented audit capabilities.

Use `UV_CACHE_DIR=/tmp/zobba-uv-cache` with `uv run` in the current cloud sandbox;
the default home cache is read-only. Do not change HOME or disable verification.

## 2026-09-30 — Zobba product and architecture recommendation (historical preparation)

The review package lives in
[`_bmad-output/planning-artifacts/zobba-product-architecture-2026-09-30/`](./_bmad-output/planning-artifacts/zobba-product-architecture-2026-09-30/README.md).
Start with `Owner-Summary.md`; the integrated design includes the product experience,
recommended Rust architecture, code disposition and consequential owner decisions.
Revision 2 keeps the owner's confirmed lead direction: clean Rust/fresh schema,
continuing Task, managed computer and standing Permissions. It adds costed computer
readiness, typed audit evaluations/recurring methods and first-task methodology,
skills and working knowledge. Admin configuration uses ordinary versioned Save;
audit review supports teams and honestly labelled solo use. Remaining business
choices are launch support, data terms and pricing. This is design, not an approved
implementation plan or a rewrite of existing planning documents. Bundled references are research
sources, not working instructions or application dependencies.
Revision 3 integrates the user's Dots UX reference: a continuing engagement
conversation coordinates distinct Tasks, with exact message/command targets,
contextual private sign-in, meaningful updates and stable output navigation.
The bounded research/source bundle is `references/dots/`; the integrated design
governs over supporting notes. Prior reference screens and build plans require
reconciliation before reuse. Product behavior is observed or documented; no
Dots runtime, cost or performance claims are inferred from its interface.
The package README links to `Zobba-Design-Package.zip` in the same folder. When updating
the package, refresh `MANIFEST.json` and rebuild the ZIP; the manifest excludes itself
and the archive, and the ZIP contains all manifest-listed files plus the manifest.

## 2026-09-29 — Story 10.12: one expression for an order, and the page shown gets its marks

The eight Epic 10 owner items (`epic-10-follow-up-owner-items.md`), as one story. No
migration, no event type; the only new words are the owner's for items 2 and 8.

- **A list cut by one order and shown in another makes "the first N" false.** Pause requests
  were capped by chain order and shown by request time. `readPauseRequests` now orders, cuts
  and dates them by ONE SQL value, `coalesce(requested_at, occurred_at)` (ties in chain order),
  and `pauseHistoryRows` keeps each list's read order and only merges the two: re-sorting by an
  id or a millisecond instant can undo the microsecond order the SQL cut relied on.
- **Reading an instant out of JSON text needs two checks in PostgreSQL 18:** an ISO-prefix
  regex (`'now'` and `'yesterday'` are valid `timestamptz`) and
  `pg_input_is_valid(x, 'timestamptz')` (an impossible date passes the regex and the cast then
  throws). An impossible date now reads as not recorded, never rolled over as `Date.parse` does.
- **A bounded LIST and the MARKS on the page shown are two reads.** Replay's gap list stays at
  `REPLAY_GAP_LIMIT` with exact counts; the scrubber's marks come from `window`, every gap among
  the frames shown (the default prefix, or the record page at its cursor), so a gap past the
  first 100 is still marked on its page. Gaps are placed in ONE ordered pass over frames and
  gaps (a running count), not a count of every frame per gap.
- **Replay and the Timeline name an Escalation's record by one rule** (`replay-v1.md`, "Where
  a jump lands"): when the raise's cited Evidence establishes one record the Timeline's way,
  Replay lands on the latest frame those Tool Actions captured (`landedBy: 'cited-evidence'`);
  otherwise the time rule. The "every element is a string" check survives mutation by design:
  a number can never match an Evidence id, so it is a second lock on the same door.
- **`pnpm test:integration -- <file>` runs the WHOLE suite**; the filter is not applied. One
  file: `pnpm exec vitest run -c tests/integration/vitest.config.ts <file>`. Without
  `PLAYWRIGHT_BROWSERS_PATH` about 75 browser-backed integration tests fail with
  `WorkspaceProvisionError: unavailable`, which is the environment, not the code.
- **`pnpm seed:identity` needs `BETTER_AUTH_SECRET`, `BETTER_AUTH_URL` and `SERVICE_NAME`**
  as well as `DATABASE_URL`, `SEED_PASSWORD` and `--name`.
- **A stopped `next dev` can leave `apps/web/.next/dev/types/routes.d.ts` half-written**, and
  the root typecheck then fails with parse errors in that generated file. Remove
  `apps/web/.next/dev/types` (git ignores it) and run it again.
- **React escapes the apostrophe in "this record's" to `&#x27;`** in SSR markup; an SSR test
  unescapes before comparing.

## 2026-09-29 — A red gate can be the job's clock, not a test

CI on `main` at `d9c72c8` (Epic 10 merged) cancelled the browser job at its 40-minute
limit after 305 of 313 tests had passed and none had failed, so Release was skipped and
every open PR went red the same way. The job limit is 60 minutes now. When a job ends
"cancelled" with no failed test, read its last test line and its duration before
looking for a defect; the fix is the budget, never a skipped spec.

## 2026-09-26 — Stacked story PRs need an admitted CI base

Stories 10.9 and 10.10 keep the handover's `claude/10-6-legacy-visibility` PR base.
The CI pull-request branch filter must include that exact base or a published candidate
receives no run. Adding the base changes admission only; jobs, assertions, permissions
and main-only push behavior stay unchanged. Never infer verification from a successful push.

## 2026-09-26 — Decision-history review reads a total and its rows together (Story 10.10 continuation)

`[EXTENDED 2026-09-29]` Sheet 2B is decided (approved in full); omitted-history access and a
request-aware introduction are still owner decisions, listed in the 10.10 record.

A bounded history's count and rows must share a statement snapshot while another decision
commits. Use a window count in the row query, including a zero-limit request; do not count
first and then read a newer list. The regression test commits a second fact after the first
real SELECT resolves and checks that the returned count still describes its rows.

Supporting Evidence IDs are accepted as case-insensitive UUID text but PostgreSQL returns
lowercase UUIDs. Normalize the map lookup, not the immutable event. Sentences that name an
instant leave a slot for the shared `Timestamp`, retaining exact `datetime` and `title` with
readable UTC text. Independent raise-writer negatives and absent/duplicate/mismatched Abort
events pin the existing read contract; invalid option duplicates are already refused by the
real raise command. Sheet 2B, omitted-history access and a request-aware introduction remain
owner decisions, and this continuation remains WIP pending the database/browser gates.

## 2026-09-26 — A decision a Run recorded is a Timeline entry, read by identity (Story 10.10)

Story 10.10 meets legacy 4.8 AC 4, 5.6 AC 3 and 5.4 AC 3: an answered or aborted Escalation and
a pause request the Run never honoured were events in the audit chain and nothing a reader could
see. The Execution Timeline now lists them — "Escalation answers" beside "Pauses and resumes",
and a "Pause request" entry inside it. No event type, column or migration was added, and no
event is rewritten. Contracts: `durable-escalation-v1.md` (35c–35f), `run-pause-v1.md`,
`replay-v1.md`.

- **Every fact is read by identity, never by time.** A wait's ONE `execution.escalation-raised`
  and ONE `execution.escalation-answered` event are found by `payload->>'waitId'`; a wait with
  more than one establishes nothing. The Work Item is established only when EVERY supporting
  Evidence id the raise named resolves through `run_evidence_capture` → `run_tool_action` →
  `run_step_execution` (the Step Execution's Work Item first), every join bound to the Run, to
  ONE Work Item at the raise's own plan step; otherwise the entry names the step and says the
  Work Item was not recorded. "The Run was canceled by this answer." comes from the answer's own
  event, never from the Run's present state.
- **Each event is read only from the writer that appends it** — the raise from
  `escalation-platform`/platform/success, `lifecycle.pause-superseded` from
  `result-sealer`/worker/failure, `lifecycle.deferred-pause-superseded` from
  `deferred-pause-coordinator`/web or worker/failure. **A forged-writer test changes ONE field
  per case**: a fixture that differs in every field is refused by whichever check survives, so
  it proves one check exists and not which. The first version did that, and the mutation that
  dropped one writer check survived it.
- **"Every Evidence id" needs a MIXED case.** `every` → `some` survived the first round, because
  each fixture's Evidence either all resolved or none did. The test that kills it names one
  captured and one uncaptured artifact on one raise.
- `[EXTENDED 2026-09-29: every sentence this note calls proposed was approved — sheet 2, B1–B15]`
  **An approved sentence can be false in a case its list did not foresee.** "The Run ended
  before the pause took effect, so its own outcome stands." is right for a request the Run
  outran; a "pause after this inspection" request retired by a request to pause at once saw no
  Run end, so it says a PROPOSED sentence that a pause at once replaced it, and a reason this
  build does not name says it could not be read. Every proposed sentence is in
  `apps/web/src/runs/decision-words.ts` and needs owner confirmation.
- **The owner's approved layout fixes the entry order** — title, who answered, the answer (and
  the abort), where it was raised, "Open in Replay". It is not chronological like a pause entry,
  and that is the approval, not an inconsistency to repair.
- **Reading the screenshots found a false sentence no test could.** A Run with no frames, opened
  from "Open in Replay", said "…no frame was captured before it was raised. Choose a recorded
  target below." over a "Jump to" list of absences. The pointer is now said only when that list
  holds a target with a frame (`escalationReplayAbsenceWords`), proven by mutation both ways.
- **Replay writes a selection note in up to four places when no frame is selected** (the status
  line, the stage, "What the Agent was doing", "Observations") — the inspection link's pattern.
  A browser assertion on it targets the status line, `.ls-session > p[role="status"]`; a
  `getByText` meets Playwright's strict mode there.
- **The reads live in `decision-history.ts`, not in `run-detail-repository.ts`** as the Code Map
  said, so Story 10.9's parallel edits to that file cannot conflict. `capture-run-binding`
  survives mutation by design: the Run-bound `workItems()` read is a second lock on that door.
- **A cropped screenshot is not a measurement.** In one crop the two section headings looked
  different sizes; `getComputedStyle` read 16px/600 for both, and all seven entries of the two
  lists had the same gap, padding, border, left edge and width. Measure before changing CSS.
- **Vitest does not check types.** The integration file passed 6/6 three times while it gave
  `pauseRun` a `requireControllerLease` dependency it does not have (a pause takes no
  controller lease) and typed a forged event type as `string`; only the root `pnpm typecheck`
  refused both. Run it before committing a test file, not only after.

## 2026-09-26 — Preserve the database's Replay landing ordinal (Story 10.9 continuation)

`readEscalations` compares stored timestamps at database precision. The default Replay prefix
must use its `framesThrough` ordinal for every landing, not recompute the in-prefix case with
`Date.parse`: distinct stored instants can collapse into one millisecond and select a capture
that happened after the question. Two red-green regressions cover an intervening wait and a
wait before the first capture within the same rendered millisecond.

A clicked record's optional frame denominator cannot be calculated from a bounded session
prefix. Withhold that denominator when the full record total is unknown; retain the exact
session counter. An inspection page has no jump buttons and does not enter that clicked state.
The bounded-history P-4 fixture uses retry-or-skip decisions; P-4 refuses candidate matching.

## 2026-09-26 — A bounded Replay view says what it covers, and the count beside a frame is exact (Story 10.9)

Story 10.9 closes legacy 5.8's limitation (2): Replay's default view read its waits, its
Observation-registration events and its Exceptions in pages of `REPLAY_PAGE_SIZE` (500) and
said nothing when a page was full. No migration, no event type, no raised limit (the owner did
not approve raising one). Contract: `replay-v1.md`, "A bounded jump list says what it covers".

- **A count beside a frame is computed per frame in SQL, never summed from a bounded page.**
  The view summed the first 500 registration events in the browser, so past them the count
  stopped short while its sentence read as a total. `readFrames` now answers each frame's
  count through `observationTotals`, the ONE fragment `readInspectionReplay` also uses, so one
  frame cannot have two counts. Sixth appearance of "a limit belongs to the cardinality of the
  read".
- **A bounded list carries its exact total and says what it shows, ABOVE the list, in the
  owner's words** (`REPLAY_BOUND_WORDS`). `readEscalations` and `readReplayExceptions` answer
  `{ rows, total }`; `shown` is counted from the targets the list renders, never taken from a
  read, so the sentence always describes the list under it. A pause is neither listed nor
  counted: it is not a jump target.
- **"The first N" must be true of the Run, so each list is read in RAISE order.** Exceptions
  were read by `exception_id`, a derived UUIDv8 (a hash), so the 500 shown were an arbitrary
  500. One registration raises its whole batch at one instant (a P-4 page raises every
  parameter's Exception at once), so within an instant they are read by record, byte-wise
  (`COLLATE "C"`), and the jump list keeps each read's order where targets tie on a frame.
  An order no reader can see is no order: by id, a P-4 page's Exceptions were listed in none.
- **An Escalation's landing frame is found over EVERY frame the Run registered.** Resolved over
  the 500 frames read, an Escalation raised after them landed on the last frame read, a screen
  the question was not about. The read returns how many frames precede its frame and the
  inspection page (`?workItem=&cursor=`) that holds it; the row says the frame is not among
  those shown and links that page.
- **The rest is reached through the path that already exists.** "record review" in the
  owner's sentence links the Evidence tab, where a record's inspector offers **Replay this
  inspection**. No new route and no new read.
- **Reading the screenshots found what every test passed over.** The default view's counter
  said `Frame 500 of 500` over a Run of 520 frames, the bound presented as the session while
  its inspection pages said `of 520`; it counts among every retained frame now. The
  Exceptions of a P-4 page were listed in no order (above). The bound sentences, as three
  paragraphs in an `ls-stack`, were spaced like three items of the card; they are one note,
  a sentence to a line. And a row with no frame sat off the buttons' text edge in another
  size; it shares their edge, size and row height now. A test asserts what it was told to;
  only a reader looking at the page asks whether the page is true.

Three mechanical notes:

- **`jsonb_to_recordset` matches keys to its column list by exact name, and a key that does not
  match is NULL, not an error.** The integration fixture's camelCase `stepExecutionId`
  inserted NULLs until the keys were `step_execution_id`.
- **`ORDER BY sequence` names the OUTPUT column when the select list has one called
  `sequence`.** The test oracle selected `sequence::text AS sequence` and so ordered
  1, 10, 100, ...; qualify it (`ORDER BY audit_events.sequence`).
- **The over-the-bound browser fixture is its own spec file** (`replay-bounded-history.spec.ts`),
  because Story 10.6's branch edits `replay.spec.ts`. It seeds one sealed, terminal Run in ONE
  transaction, with its frame objects in storage BEFORE the commit: the worker's integrity
  sweep reads a sealed package's artifacts, and a missing object is a permanent finding.

## 2026-09-26 — Only the stream brings a lost Live View back, and the route boundary claims only what it knows (Story 10.8)

- **A server re-read is not stream recovery.** `useLiveTimeline`'s `[url, cursor]` effect
  restarted the silence clock whenever it ran, and a re-read that moves the cursor re-runs
  it, so `BellLive` refreshing a page because ANOTHER Run ended showed `live` for 15 s and
  reopened every live control for 60 s while the stream was down. `LiveClock`
  (`live-status.ts`) now moves only on a frame the stream sends (a Timeline event or a
  heartbeat); `followLiveStream` (`live-stream.ts`) opens a connection without touching it;
  and a remount takes the clock the last subscription to the same stream left
  (`createLiveClockHandOff`). Thresholds and `RUN_ENDING_EVENTS` are unchanged. Contract:
  `docs/contracts/live-view-v1.md`, "Only the stream brings a lost page back".
- **`open` is not a frame, so the stream speaks first.** The events route answers before it
  arms its LISTEN, and one whose LISTEN fails sends `end`, closes and is reopened two seconds
  later, so an `open` counted as a frame calls a stream that delivers nothing `live` every two
  seconds. `open` is therefore not listened for at all, and the CHANNEL sends one heartbeat as
  soon as a stream is armed and caught up, before the first tick (both streams; none when the
  LISTEN or the first read fails). The review found why that had to be the server's job: with
  the first frame ten seconds away, every planned renewal gave ~22 s of silence on a healthy,
  quiet Run (the lifetime ends just before a beat, then the 2 s retry, then 10 s), every page
  move more than ~5 s after a beat went `stale`, and a page moved every few seconds never
  heard a frame and went `lost`. **A client's silence rule and the server's cadence are one
  system: test them together** — `tests/unit/live-channel-cadence.test.ts` drives the real
  engine and the real subscription through an emulated `EventSource` that takes its retry
  from the stream's own `retry:` frame.
- **A remount hands on everything the clock said, `live` included** (`resumedLiveClock`
  keeps `everConnected`), minus only the time no subscriber was listening. The hand-off is a
  layout effect so the first paint is the inherited clock; the layout CLEANUP closes the
  connection before it leaves the clock (`endLiveSubscription`), because the passive
  cleanup runs after the next page has already taken it and a frame in between would land
  on state nobody reads; and every repaint goes through `nextLiveTick`, because React skips a
  setter handed the value it holds and two `Date.now()` in one millisecond are equal.
- **A stream's first cursor is its page's own, never the larger of it and the last seen.**
  `beginLiveSubscription` resets it when the stream changes. The page reads the chain head
  BESIDE its content (`Promise.all`), so a head ahead of the content is possible, and
  resuming from it would skip the one frame that says the Run ended. `[NAMED, NOT FIXED]` The
  same race exists at first mount, which starts from that head.
- **An effect body the unit suite must see lives outside the effect.** `followLiveStream`
  has no React and no DOM and is driven with a fake `EventSource`; a new cursor is a second
  call with the SAME state, which is exactly what the re-running effect does.
- **"Throughout" means more than one read.** Mutation put the clock reset back and the
  browser test failed on its THIRD sample, not its first: the status re-renders on a
  one-second tick, so one read right after the re-read passes against the defect.
  `expectThroughout` reads every fact in one page read, eight times over four seconds.
- **A test that a re-read does NOT reset something must first prove the re-read
  re-subscribed.** `live-drop.spec.ts` counts `EventSource` constructions per URL through an
  init script and requires a new one before it asserts anything; without that precondition
  it would pass against the defect whenever the cursor happened not to move.
- **The route boundary cannot tell a page that failed to build from a Server Action whose
  acknowledgement was lost, so it never says nothing was changed.** After a committed flag
  "Couldn't load this page. Nothing was changed." was false. Its words are in
  `apps/web/src/design/route-boundary-words.ts` (approved by the owner on 2026-09-26; the
  Run sentence is the owner's candidate, pinned against epics.md Story 10.8 on disk), and its
  one control is a plain `<a href>` to the page: a GET that works without script and never
  resubmits. Never `reset()` there: it re-renders the router cache, the page as it was
  BEFORE the action, which is the view that invites a second submission.
- **The deployed harness matches the boundary's HEADING**, which heads the boundary on every
  path and which both banner sentences start with; `acceptance-sentences.test.ts` pins it
  to the words module. An Evidence link also fails on a status of 400 or more, on the
  not-found page's heading (a page that calls `notFound()` after streaming starts answers
  200) and on `RunDenied`'s shape (heading "Run" over a danger banner).
- **"Nothing changed" has one pattern, `NOTHING_CHANGED_CLAIM`** (`design/nothing-changed.ts`,
  React-free so specs import it). Four retyped regexes each missed a different phrasing
  ("Nothing changed.", "No changes were made.", "unchanged", …); `nothing-changed.test.ts`
  lists every phrasing it must catch and every real unknown-outcome sentence it must not.
- **The boundary's link is built from `usePathname()` + `useSearchParams()`**, which the
  server renders too. A `window.location` store gave the no-JavaScript render a link without
  the query, and every test rendered only that server snapshot. EXPERIENCE.md now has one row
  for the route boundary (the five approved sentences) beside "Action failed", which stays
  for refusals; `route-boundary-words.test.ts` pins all five to that row on disk.
- **Wait for `data-client-ready` before touching a native `<details>`, and never count
  `/__nextjs*` requests.** Clicking a disclosure before React attaches leaves an `open` the
  server never rendered; React reports the hydration mismatch and `next dev`'s overlay POSTs
  `/__nextjs_original-stack-frames` to symbolicate it. The full browser suite failed
  `flag-run.spec.ts:185` on exactly that POST, counted as a resubmission (`1ee6a204`).
- **Screenshots read as a reader would found four things no test could.** A withdrawn
  control's reason was only its visually hidden description, so a `lost` Live View showed
  greyed Pause and Cancel and said why nowhere unless the flag disclosure was opened:
  `LiveGateNote` now states the stream's reason in the header of Live View and the Workspace.
  Every link drawn as a button was underlined (`.ls-button` sets `text-decoration: none`).
  The flag opener had no size class and sat shorter than its neighbours. And Run Detail's
  toolbar laid Pause out in a centred column: a rule that sets `display: flex` on an
  `.ls-stack` keeps the stack's `flex-direction: column` unless it says `row`. Two harness
  rules came with them: `toBeVisible` passes a 1px clipped element, so "a sighted reader sees
  it" is asserted as a painted size outside `.ls-visually-hidden`; and a second `goBack`
  waits for the first one's address.
- `[NAMED, NOT FIXED]` **The same class, on surfaces this story does not own.** The
  Administration controls' client catch branches (`RoleControl`, `UserForm`, `BindingForm`,
  `RegistrationForm`) and the administration actions' `UNAVAILABLE` still say "Nothing was
  changed." when a Server Action throws or its response is lost. And without JavaScript a
  flag's result page is the answer to a POST, so the browser's own Reload offers to
  resubmit it; the boundary's link does not. **A Builder Submit renders the not-found page
  ("… Nothing was changed.") in its own action response**: any `revalidatePath` makes Next
  re-render the CURRENT page (`skipPageRendering` in its action handler), and the Builder
  calls `notFound()` for a version that is no longer a Draft, before `VersionActions` pushes
  to the version page. Found by reading, not reproduced.
- `[NAMED, NOT FIXED]` **A full document load starts a fresh clock.** The browser's Reload,
  the boundary's "Reload this page" and the `ended` sentence's "Refresh to continue" all load
  a new document, which reads `connecting`, then `stale` — neither a gate reason — so while
  the stream is still down its live controls stay enabled until that page has itself counted
  60 s. Deferred by the review as a follow-up; the command still refuses a stale action.

## 2026-09-26 — Review continuation keeps exact reads exact (Story 10.6)

- Adapter Evidence readers accept at most 64 IDs. Batch distinct IDs at the caller; an
  exact read must not silently drop the 65th artifact. A later batch failure keeps the
  existing unreadable result for the whole read.
- A pause while revisiting an acquired adapter reference holds the next unfinished unit.
  Preserve cancellation checks at their original boundaries. If no unit remains, leave
  the pause request for the next stage or terminal transition.
- A metadata link beyond a bounded overview carries an exact selector. Resolve it only
  after Run authorization, through the Run-bound reader, and deduplicate its anchor.
- Keep record keys such as `E-000102` in the existing `ls-nowrap` span; Chromium breaks at
  their hyphens. Keep the KEY only (`recordKeyText`), never the whole label: a long unmasked
  name that cannot wrap pushes a 239 px rail past the page edge at 1024 px.
- The caller makes a Run's terminal transition; `completeRun` then seals the Result, and moves
  the Run state itself only for §E's COMPLETED → INCONCLUSIVE row (`complete-run.ts:202`).
- Handover sheet 1 is approved. `[EXTENDED 2026-09-29]` Sheet 2, version 2 (A1–A11, B1–B15,
  D1 yes, D2 b) was approved by the owner on 2026-09-29; 10.6 removed its marks and built A11
  and D2 b, and 10.10 removes its own marks for B1–B15. Before that it was pending; a
  successful test is not owner approval. Check every sentence a module shows
  against the approved sheet before marking the module approved: five pause forms were in
  no sheet and were marked approved anyway (review of the continuation, 2026-09-27).

## 2026-09-26 — A fact the records do not link is linked on new events, and read by identity (Story 10.6)

Story 10.6 meets five compiler-1 visibility legs the closure register found on the retained
surfaces (4.7, 5.2, 5.3, 5.4, 5.6); 4.7 and 5.2 stay open until Story 14-11a's export legs.
No event type, column or migration was added; each missing link rides on a key of
an event that already exists, written on NEW events only, and every surface reads it by
identity and says what an older record does not hold. Contracts: `run-pause-v1.md`,
`durable-escalation-v1.md` (35a, 35b), `observation-registration-v1.md`, `replay-v1.md`,
`replay-asset-set-v1.md`, `live-view-v1.md`.

- **A conditional payload key is the no-migration way to add a link, and it must be absent,
  not empty, when it does not apply.** `humanMatchDecisions` on
  `execution.observations-registered` (4.7) and `planStepId`/`heldWorkItemId` on
  `lifecycle.run-paused` (5.4) follow the `absenceDigests` precedent: an event without the
  case is byte for byte what it was, and the Observation digest does not move. The existing
  `workItemId` key on a pause keeps its meaning, because the interaction receipt guard
  (generations 55 to 59) compares it.
- **A resume cannot name the attempt it starts, because none exists yet; the attempt names
  the resume.** The stage that starts the held step writes `resumedWaitId` on the attempt's
  own start event. `RunPauseContext.readPendingResume` is REQUIRED, which is what found every
  stage context; `resumeLinker` reads it once per stage invocation and links only the FIRST
  attempt at the held plan step (and Work Item). A per-attempt read would scan the chain once
  per attempt.
- **`PauseHold` is REQUIRED on `performPause` and `hold` is REQUIRED on `PauseBanners`.** An
  optional parameter that changes what a record says is one a call site can forget — the
  lesson of the mid-item boundary that once passed no in-flight pair.
- **"Not linked" and "not recorded" are said, never shown as a blank.** A human-matched record
  whose link does not establish an answered candidate choice keeps its flag and says the
  decision is not linked; a pause whose event named no step says its step was not recorded;
  a hold the banner cannot read says so. Nothing pairs a wait with a record, or a resume with
  an attempt, by time.
- **A pause fixture sits where a stage really holds one.** The sign-in and adapter stages
  pause only BETWEEN units; only the Work Item stage supersedes an attempt in flight, and it
  gives the attempt back, so the restarted attempt carries the SAME number and only its Step
  Execution tells the two apart. The first browser journey superseded a sign-in attempt and
  restarted it as attempt 2 — a shape no Run produces — and passed. `pause-resume.spec.ts`
  now holds the first pause before the sign-in and the second mid-attempt at the page's
  inspection (a P-4 Work Item, subject key NULL).
- **A human-selected match exists only in a P-1 Run.** The P-4 page path refuses a
  choose-candidate decision (`human-decision-refused`); only P-1's name search offers two
  accounts. The first `human-match.spec.ts` fixture recorded a human match in a P-4 Run and
  passed. It is a P-1 Run now — LoanCore from the catalogue, one Work Item per record, the
  leavers binding's own mask on `full_name` — and it asserts no surface beside the decision
  note shows a masked name (proven by removing the mask: the Exceptions list and the record
  review then fail).
- **A selection a read cannot answer whole is refused, never cut.**
  `MATCH_DECISION_SELECTOR_LIMIT` is sized from the callers' own page limits; a dropped entry
  would render a human match as a platform one.
- **One predicate per fact, shared by the writer and the surface.** `frameMissingPredicate`
  serves the terminal transition's count and Replay's gaps; `readAdapterLog` serves Live View
  and Replay, reading Evidence EXACTLY by the ids the steps name rather than the bounded
  overview (the fifth appearance of "a limit belongs to the cardinality of the read").
- `[EXTENDED 2026-09-29: approved — sheet 1 on 2026-09-26, sheet 2 v2 on 2026-09-29]`
  **Every new sentence lives in a words module** (`match-words.ts`,
  `pause-words.ts`, `replay.ts`'s `REPLAY_GAP_WORDS`, `live-view.ts`'s
  `ADAPTER_ARTIFACT_WORDS.unavailable`), read back by the unit and browser tests; each was
  proposed first and is now owner-approved. The export legs of 4.7 and 5.2 are Story 14-11a's.

Two mechanical notes:

- **`node_modules/.bin/tsc` is a shell shim, not JavaScript.** `node --max-old-space-size=…
  node_modules/.bin/tsc` fails with `SyntaxError: Invalid or unexpected token` before
  checking anything; run `NODE_OPTIONS=--max-old-space-size=2048 pnpm exec tsc …` instead.
- **A page test whose `vi.mock` factory lists a module's exports needs the page's NEW import
  mocked too**, even when the new call returns early: `live/page.adapter-log.test.ts` now
  mocks `pause-read` (`readPauseHold`), which reads the database on a PAUSED Run.

## 2026-09-29 — A 200 from the preview route can still carry no image

- **A served read is not a served image.** When the sample moves between the broker's reply
  and the proxy's re-read, `WorkspacePreviewProxy.read` keeps the metadata and withholds the
  image (the `after.sequence` check in `workspace-preview-transport.ts`), and the route answers
  200. `settledSample` took the first 200, so the SIGKILL test's `expect(oldSample.digest)
  .toBeTruthy()` met `null`: CI on `477b6f7` (Story 10.10, which touches neither this spec nor
  the preview code). A test that expects a public image re-reads until one is served
  (`settledSample(page, runId, true)`); the private-mode reads keep the plain read, because
  waiting for an image there would hide the suppression they prove.

## 2026-09-26 — Every append to a Run's chain wakes the channel, and a burst keeps its last re-read (Story 10.7)

- **The wake-up belongs to the append, not to its writers.** `appendAuditEvent` issues
  `pg_notify('run_timeline', {runId, sequence})` for every append whose aggregate is a Run, in
  the appending transaction and before anything below it can return early. Three families had
  none (`evidence-access.*`, `notification.*-delivery`, the evaluation review's
  `security.denied`), and the conversation narration's own notify sat after an early return
  (a conversation at 1,000,000 messages). The writers' `notifyTimeline` ports stay: PostgreSQL
  folds identical payloads of one transaction into one. No migration, trigger or event type.
- **So the payload is spelled exactly as the writers spell it, `JSON.stringify({ runId,
  sequence })`, key order included.** Another spelling is a second, unfolded notification, and
  the list stream (one frame per wake-up, no cursor) forwards the event twice. Proven by
  mutation: swapping the two keys fails the list-stream case with `[2, 2, 3, 4]`. The spelling
  is pinned at EVERY site, not only the ones a test drives: `run-timeline-channel.test.ts`
  walks the package and requires each `pg_notify('run_timeline', …)` to stringify an object
  literal whose keys are `runId` then `sequence`, and names each offender by file and line.
- **Only a Run's chain wakes it.** A Procedure's chain, or a UUID-shaped aggregate that names
  no Run, must not: the list stream reads the row a notification names and would forward it as
  a Run's event. Mutation: dropping the `if (run)` guard fails the any-writer case.
- **A Run surface does not re-read on the reads of its own evidence.** Once every append woke
  the channel, the Evidence inspector's own grant read (two `evidence-access.*` events on the
  Run's own chain per render) woke the inspector again, and on an active Run it re-read itself
  about once a second: two permanent chain events and one worker grant job each time.
  `refreshesSurface` (`apps/web/src/runs/refresh-events.ts`) skips `evidence-access.*`,
  `notification.*` and `security.denied`, which no Run surface renders. It is an exclusion
  list, so a family added later still re-reads. Run Detail and the Runs list mount it through
  `SurfaceLiveBanner` (a server component cannot pass a function to a client one); `LiveGate`
  asks it before `refresh()` and keeps the Run-ending latch unconditional; and
  `refresh-events.test.ts` refuses any other direct `<LiveBanner` mount. `BellLive` keeps its
  own filter. The stream still carries every family; only the re-read skips three.
  `surface-refresh.spec.ts` proves both paths with the real worker's grants: the inspector is
  re-read once for a Run event and then holds at four `evidence-access.*` events past a
  heartbeat (without the filter: 28), and Live View loads its frame with no re-read (without
  the filter: 2). Its trigger is a `failure.retry` append, not a flag: the bell re-reads on a
  flag too, so a flag's re-read count would depend on timing.
- **Prove a WAKE-UP, not a heartbeat or a replay.** Open the per-Run stream one event behind
  the head, wait for that replayed frame, keep the heartbeat a minute away and the delivery
  deadline far below it. Count raw wake-ups on a second LISTEN and flush with a probe NOTIFY
  (they arrive in commit order). A rolled-back append is a unit of work that throws AFTER its
  work, under a 50 ms heartbeat, so a row committed with no wake-up would still be found. To
  commit into the window between LISTEN and replay, hook the `listen` promise
  (`countedSql(onListening)` in `run-timeline-channel.test.ts`).
- **A throttle may delay the final re-read; it may never drop it.** `BellLive` was
  leading-edge only, so a second qualifying event inside one second of the last re-read was
  dropped and the bell and the Overview ended a burst one change short. It composes
  `useThrottledRefresh` (trailing) now, the throttle Run Detail, the Runs list and Live View
  already use. That is one rule, not one budget: the bell and a page's own banner are two
  instances of it, each with its own one-second window. The Overview opens no stream of its
  own, so the bell's re-read is its only live refresh, and it fires only on the bell's own
  events (an Escalation raised, answered or timed out, a Run flagged, a Run ending). Recent
  Runs, the versions awaiting approval and the Drafts stay as read until the reader navigates
  or the next of those events arrives.
- **A browser burst test freezes the page's clock** (`page.clock.setFixedTime`). With a real
  clock a slow `next dev` round trip stretches the gap past the one-second window, and the
  leading-edge throttle passes by accident; timers still run, so a trailing re-read still
  fires. The list stream has no replay, so wait for its first HEARTBEAT (sent only once its
  LISTEN is armed) before committing anything the page must see. Proven by mutation: the old
  `BellLive` fails `bell-burst.spec.ts` with the bell still at "1 unread".
- **Compare a flaky test at two commits in BOTH orders.** `agent-isolation.test.ts` failed 3 of
  16 loaded runs at this story's head and 0 of 16 at the baseline `429e08c` while the baseline
  always ran first in each pair; with the order swapped the baseline failed the same case at
  the same line (1 of 16). All four failures were the second run of a pair, none of the 32
  first runs failed it, and it passed 4 of 4 at both commits with no added load. The test's
  module graph holds no file the story changed. A pair run in one fixed order confounds the
  commit with the position, and read alone it would have named a regression that is not one.

## 2026-09-25 — A single read of a moving preview sample is a race the broker refuses on purpose

- **The preview route answers 503 for a read that meets a new sample, and that is the product
  working.** `startWorkspacePreviewBroker` refuses a read whose identity or sample sequence changed
  while it was served (404/409), `WorkspacePreviewProxy.read` turns that into `null`, and the
  route answers 503. `workspace-preview-worker.spec.ts:265` read the sample ONCE and asserted its
  digest; CI on `33310a4` (documentation-only PR #53, application code identical to `c18ad36`)
  met exactly one such 503 while the page's own polls around it answered 200. A test that expects
  a sample re-reads until one is served (`settledSample`); a test that expects NO sample keeps its
  single, unretried read, because polling there would hide the refusal it exists to prove.

## 2026-09-23 — The UI cleanup on the live branch, and what that branch was already failing

The owner approved putting the cleanup on `feat/auditor-workspace-v1-1`, the branch production
runs: PR #52 merged in (`655a0c4`, `81d9653`), then UX-22..26 on the surfaces only this branch
has (`ed12dfd` record review, `857b08b` workspace, Live View and chat).

- **Read the deployed commit's own CI before blaming a merge.** `ec673a0` was deployed with
  6 browser failures and 2 preview-job failures. Five were spec drift: `1dd337d` stopped
  saying "Action-linked captures" and five specs kept asserting it. A failure present at the
  base is not the merge's, and it is still ours to fix before the next push.
- **"Action-linked captures" (AW-060) is now "Latest saved screen".** UX-24 is the later owner
  decision. The truth AW-060 asks for is kept: the live preview ("a few seconds behind, not
  saved as evidence") and the saved screen ("saved as evidence from {system}") are named as
  two different things, in `workspace-words.ts`, which the specs import.
- **One record label rule: `record-words.ts`.** The key is the Template's first frozen lookup
  column, the name its second (P-1 `full_name`). Masking comes from the version's FROZEN
  `sensitive_fields`, never from today's binding. `readRecordNames` answers only for a key
  that is unique in the Run's population: a duplicated key names no single person. A masked
  key stays the row's identity but leaves the search haystack, so a search cannot probe it.
- **Order a snapshot when it is written, not when it is read.** The record queue lists
  Exceptions, then pending reviews, each in source order, decided before the presentation
  snapshot is stored, so a cursor can never repeat or skip a record.
- **A "current step" taken from a bounded page is a guess.** Live View and the workspace used
  the newest row of the Timeline's page, which holds the OLDEST fifty Step Executions.
  `readLatestStepExecution` reads it exactly. Fourth appearance of "a limit belongs to the
  cardinality of the read".
- **A page test whose `vi.mock` factory lists exports breaks when the page imports one
  more**: "No `readRecordNames` export is defined on the mock". Add it to the factory with a
  neutral default, then add a case that proves the new behaviour.
- **A wait armed before an action must be observed before the next `await`.** Sign-in
  armed `page.waitForResponse` before the click and awaited it only after; a click that
  failed left it unobserved, and its later rejection was unhandled, which under Node's
  default policy stops the worker. The search path already observed both of its armed
  waits; the sign-in path did not. It was the CI preview failure "a real decoded image
  cannot enter the stage after private changes", on the deployed commit as well.
- **A helper agent with a file allowlist reports what is outside it.** The workspace helper
  had no git writes, no shared-database suites, and a list of files. It named four defects it
  was not allowed to fix (a stale spec, raw chat times, the bounded current step, an
  unmasked key). All four were real and fixed here.
- **A React key built from the read time remounts the component on every re-read, and
  the shell re-reads every page whenever ANY Run ends** (`BellLive`). The Replay viewer's
  key carried `readAt`, so a reader stepping through frames was thrown back to the first
  one whenever some other Run ended. `replayViewerKey` keys by the Run and the REQUEST.
  Found because `selected-replay.spec.ts` failed "Frame 606" after End, ArrowLeft; a
  throwaway spec that logged each RSC request and the viewer node's identity showed the
  re-read and the new node in one trace. Proven by mutation in a unit test (the page's
  element key) and in the browser (a real cancel of another Run, then the same node).
- **The re-read in that spec came from the spec's own fixture.** Its extra QUEUED Run had
  no held checkpoint, so the spec's own worker picked it up and ended it mid-walk. Seed a
  fixture Run WITH its checkpoint, in one transaction, and end it on purpose when the
  test is about a Run ending. `cancelRun` on a RUNNING Run only records a request; on a
  QUEUED or PAUSED one the command ends it at once.
- **A spec only this branch has was never updated by the packages.** `.ls-session__caption`
  was removed by the cleanup (UX-28) and `selected-replay.spec.ts` still asserted it; no
  run had reached that line, because the test failed earlier. After fixing an early
  failure, run the test to its end before calling it fixed. All 68 `ls-` classes the specs
  use were then checked against the app.
- **A page that holds Run control writes events on a clock.** It renews every 30 seconds,
  and each renewal is an event on the Run's chain that cannot be deleted while the Run
  exists. So an exact event list sets renewals apart (`expectRunEvents` in
  `tests/e2e/run-control.ts`), and a teardown deletes the Run's events and the Run in ONE
  transaction, Run locked first. The rule was written on 2026-09-21 and two siblings did
  not follow it: `live-escalation.spec.ts`, whose refused cleanup CI met (the
  `procedures.spec.ts` empty-list failure was its shadow), and
  `prodconsole-agent-journey.spec.ts`, which holds control while its worker finishes.
- **Click Acquire and Resume through `acquireControl` and `resumeWithControl`.** Every
  control read (first load, a live event, a renewal, the read after Release) makes the
  controls `aria-disabled` for a moment, and a click then is refused by design. CI met it
  three times in one run: a Resume opener, a Resume confirm, and an Acquire right after
  Release that reached no server action at all. The helpers click only enabled controls,
  and again only while the click has not taken effect; a repeated acquire is refused by
  the server (`stale-epoch` or `held`), so a retry cannot move the lease twice.
- **A spec the main suite skips is still a spec, and the class sweep missed one.**
  `workspace-preview-worker.spec.ts` runs only in the preview job, so the sweep that moved
  every Acquire click onto `acquireControl` did not see its own acquire loop or its single
  Resume click. CI on `96c7f51` failed there (the Resume dialog never opened in 240 s);
  `bf06297` passed it by chance. When a class is fixed, grep `tests/` for the control's
  name, not the list of files the main job runs.
- **A test that holds the worker lets it go only after the command it waits on is saved.**
  The same spec clicked "Stop Run" and released its held model turn in the same breath.
  The worker answered the turn, acted, and began ANOTHER held turn before the cancellation
  committed, so no boundary saw the Stop and the Run stayed `RUNNING`: two cold local runs
  failed there. The Pause had the same race and won it only because its commit landed while
  the worker was mid-action. `awaitRunRequest` now waits for the Run's saved marker first,
  as `prodconsole-agent-journey.spec.ts` already did before releasing its barrier. A
  throwaway copy that held every command POST for two seconds passed with the wait and
  failed at the Stop without it, with the same "Received: RUNNING".
- `[EXTENDED by the note below]` **A route handler still running when its test ends fails
  the NEXT test**, as `route.fetch: Test ended`. `run-controller-lease.spec.ts:397` failed
  for a read test 369 held and never released; a test that holds a request releases it and
  awaits `page.unrouteAll` in its `finally`, as the sibling at line 366 already did.
- **`page.unrouteAll({ behavior: 'wait' })` is not a wait for held requests.** Playwright
  1.62 empties the route list FIRST and waits after, and the first handler that finishes
  then finds the list empty and removes the page's interceptor itself (`Page._onRoute`).
  The browser side passes every other request still inside a handler to the network, and
  that handler's own `fulfill` then fails "Route is already handled!". CI's re-run on
  `d0b4c15` failed `run-controller-lease.spec.ts:368` that way: it holds EVERY control read,
  and two were still inside `route.fetch()` when its `finally` released them.
  `tests/e2e/held-routes.ts` closes the gate first (a later request falls back at once),
  releases, waits for every started handler, and only then unroutes; the six held-request
  tests in that spec use it. A throwaway script with two held requests, one still fetching
  at release, failed 5 of 5 with the old cleanup and 0 of 5 with `settle`. A handler that
  answers with no network wait before it (the readiness specs' script holds) cannot lose
  this race; one that awaits `route.fetch()` or a hold released at cleanup can.
- **A dev server can stop answering ONE route for a whole CI run.** The first attempt on
  `d0b4c15` failed 7 frame tests: `next dev` never answered `/api/runs/<id>/frames/<id>`
  from its first request, while the evidence inspector's reads through the same
  worker-signed grant passed at the same time. The re-run served that route 39 times. The
  quick test: diff the set of route patterns the server logged in a green and a red CI log
  (UUIDs normalized); here exactly one pattern was missing.
- **A poll that reads a count and then a text can wait for ever.** `run-controller-lease
  .spec.ts:606` polled "the dialog is gone, or it offers the retry" as `count() === 0 ||
  textContent()`. The receipt reconciliation closed the dialog between the two reads, and
  `textContent()` auto-waits (this config sets no `actionTimeout`) for a dialog that never
  came back, so the poll's deadline won and it reported the PREVIOUS answer: "Received:
  false" after "Timeout 10000ms exceeded while waiting on the predicate", CI on `fdf499e`.
  The product was right: one resume event, receipt applied, dialog closed. Read every fact
  of a poll in ONE page read (`evaluateAll` never waits). A throwaway spec that closed the
  dialog between the reads failed 5 of 5 with the same message, and 0 of 5 with one read.
- **The abuse harness threw away the web server's own words.** CI on `d1a3f30` (attempt 1)
  failed "Agent abuse mutations" in case 5 with only "Timed out waiting 180000ms from
  config.webServer.": no test ran, and nothing said why. `verify-agent-abuse-e2e-mutations.mjs`
  read only Playwright's JSON report, which keeps nothing that belongs to no test, so every
  `[WebServer]` line was lost. A server can be up and never ready: on a transient error
  `runStartupChecks` logs "Startup checks deferred" and stays up, `/api/health` answers 503,
  and Playwright waits its full 180 s. The harness now adds the `line` reporter and, ONLY for
  a run that failed outside its tests, keeps a tail of the child's stdout and stderr
  (`scripts/playwright-output-tail.mjs`): escapes stripped, the worktree path named, the value
  of every variable whose NAME marks it secret replaced by that name, same-shape lines (the
  503 polls) folded to first, count and last, and only then cut to 80 lines of 400 characters.
  Two forced local runs named their causes: "Refusing to start" with `configKeys:
  BETTER_AUTH_SECRET`, and "Startup checks deferred" with `ECONNREFUSED`. The `d1a3f30` re-run
  passed, so that failure's own cause is still unknown; the next one will say it.
- **When you want the END of a child's output, send it to a file, not to a pipe
  `spawnSync` buffers.** Past `maxBuffer` (16 MiB here) `spawnSync` kills the run and keeps
  the FIRST bytes, so its tail is not where the run stopped. The harness's child writes to
  files in its scratch directory, and `readTail` reads back at most the last 8 MiB, whole
  lines only: a window that starts inside a line can start inside a secret, and half a secret
  is a value the redaction cannot recognize. Each run of a full local harness printed 10–45
  KB, far below the limit. **`/proc/<pid>/io` `wchar` is not a process's stdout**: it counts
  every write, it read 3–22 MB for these same runs, and it first sent this change after a
  limit it was nowhere near. Measure the file the output lands in.
- **`live-escalation.spec.ts` still waited to SEE "Pause requested." and "Run resumed."**
  after UX-49 made both transitional; `pause-resume.spec.ts` had already moved to the
  settled banner. When a sentence becomes transitional, grep every spec for it — this
  one was found only on the second pass.
- **A push to this branch deploys nothing.** Railway's `web` and `worker` build from it,
  but none of the thirteen commits pushed after `ec673a0` reached production until
  `bf06297` was deployed by name (the Railway agent's deploy with `commitSha`, both
  services). Then read each deployment's status and commit, `/api/health` (`schema`), the
  web's "Startup checks passed" and the worker's startup lines. The web switches first;
  the worker, which installs its browser, finishes minutes later, so for that time the
  two run different commits.

## 2026-09-23 — The UI cleanup landed as five packages, and what integrating them found

The owner's 21 September walkthrough (49 findings, 17 P1) is implemented on
`codex/epic-2-procedure-builder`: package 1's shared layer, then packages 2–6 in their own
worktrees, merged with no text conflict. Findings, one report per package and the release
checks: `_bmad-output/implementation-artifacts/ui-cleanup-2026-09-22/`. UX-22..26 name
surfaces only PR #51's branch has; `p5-report.md` states the rule each one needs there.

- **Chromium gives a date or time input a keyboard stop for its own calendar or clock
  button, and at that stop the input matches only `:focus-within`.** The product's one
  ring is `:focus-visible`, so it was never drawn there — on the Run period, the Draft
  period and the Schedule's start time. `globals.css` draws it on `:focus-within` for those
  inputs. Found by the release checks' keyboard walk; axe cannot see a missing ring.
- **A keyboard walk under `next dev` reaches `nextjs-portal`**, the dev overlay appended
  after the page. It is not the product, so the walk ends there.
- **Packages that each pass their own specs can still break each other: a spec one
  package owns can drive another package's surface.** `version-review.spec.ts` creates its
  Procedure through the form package 3 renamed ("Procedure name", one-click creation,
  `?created=1`, the Builder's words for a missing source). No text conflict, red on the
  first run. At a merge, grep every spec for the words each package renamed.
- **A package can move a line a mutation harness pins, and no local gate runs the harnesses.**
  Package 5 gave the Escalation question `policy={false}` (UX-27); the agent-guard harness
  anchors on that exact line, so the integrated branch's first CI run stopped with
  "Mutation anchor drift" after every test had passed. Before pushing a merge of UI work,
  run the three harnesses CI runs (`verify-agent-guard-mutations.mjs --browser`,
  `verify-prodconsole-…`, `verify-escalation-review-…`) in a detached worktree of HEAD.
- **A report is only as true as the tests it names.** Checking each "proven by" against the
  test file found two findings nothing pinned (a stop-reason sentence, the Review tab).
- **Fifty green layout checks did not find three false sentences; reading the screenshots
  did.** An Active version said "Not yet submitted for approval." (it had no submission
  RECORD, which is a different fact), saved dates were raw ISO, and a frequency read as a
  schedule. A layout or axe check cannot judge whether a sentence is true: read every
  screenshot as the reader would. And when a record can be missing for more than one
  reason, say what the absence means, never the likeliest cause (`missingSubmissionWords`).
- **Usage limits stop subagents mid-edit; commit early.** Package agents died four times;
  the worktrees kept everything, but a resumed agent had to rebuild intent from a diff.
  Commit each coherent piece at once, and brief a resumed agent with the file list and the
  previous agent's last words.
- **This machine restarts, and a restart stops the scratch PostgreSQL.** The data survives:
  `rm -f /tmp/pgdata18/postmaster.pid`, then `pg_ctl -D /tmp/pgdata18 -o '-p 5434' start`.
- **Test databases hold the Auditor and the Administrator only, as CI's do.** A seeded
  Audit Manager fails `run-waits` and `flag-run` (they count every manager), and three new
  specs that REQUIRED one would have thrown in CI, which seeds none. A spec that needs a
  manager calls `mintAuditManager` (`tests/e2e/accounts.ts`) and removes it in its teardown.
- **A 4.4 GB `.next` cache that lived through several restarts made Turbopack panic**
  (`aggregation_update.rs`, "Aborting.") at test 23 of 238; the other 195 failures were
  `ERR_CONNECTION_REFUSED`. Delete `apps/web/.next` and run with `INTELLIFIN_LOW_DISK=1`
  (no on-disk cache); the next full run finished.
- **A streamed table is in the DOM before it has a box.** React holds a streamed Suspense
  segment in a `hidden` block until it reveals it, so `toHaveText` passes there while
  `boundingBox()` answers `null` and a page-width check measures the skeleton. CI's first
  run on `2a31831` failed `runs.spec.ts` on exactly this. Measure only after `toBeVisible()`.
- **A transitional confirmation goes when the state it announced settles (UX-49), so a
  spec must not race it.** `flag-run.spec.ts` asserted the settled banner and the absent
  transitional sentence; `runs.spec.ts` still raced "Run canceled." twice and lost on a
  fast machine. When a package makes a sentence transitional, grep every spec for it.
- **Playwright empties `test-results/` at the start of every run.** Read a failure's
  `error-context.md` and attachments before starting the next run, or they are gone. When a
  context has no page snapshot, a throwaway copy of the spec that prints `innerText()` at
  the failing line is the quickest look at what the page really said — delete it after.
- **React's server rendering writes `dateTime`, not `datetime`.** An SSR test that pins a
  `<time>` by its attribute must spell it the way `renderToStaticMarkup` emits it.
- **`[FIXED]` "Escalation answered." vanished before anyone could read it.** The banner
  lived inside the panel that the refresh after the answer removes, so it lasted about
  300 ms and `live-escalation.spec.ts` could miss it under full-suite load. It now lives in
  `EscalationOutcomeHost`, which `OpenEscalationSection` renders in EVERY state, so React
  keeps its state through `router.refresh()`; it steps aside when a different question
  opens. **A confirmation must live in a component that outlives the thing it confirms**,
  and the spec that proves it asserts the confirmation AFTER the panel is gone — the
  old assertion ran before the refresh and could never see the defect.

What the packages learned (each report has the full list):

- **A link's `href` asserted as a string proves nothing about the route.** Both "Open the
  Result" links went to a route that does not exist and three tests agreed. Pin a link
  helper to the route folders on disk, and have one browser test follow the link.
- **A teardown deletes `notification` rows before the versions they name**, or it throws,
  leaves the Procedure, and fails `procedures.spec.ts`'s empty-list test.
- **A first version's stored diff flags EVERY section `changed`.** Ask for the baseline
  before rendering the flag; a section changed only in its frozen contract is counted,
  never dropped.
- **`findProcedureTemplate` throws on an unknown id, and the id comes from a stored frozen
  review.** A surface that names a Template falls back to the stored id.
- **A dated scope is read from the auditor's words, never from the model's.** A period the
  model wrote is a period nobody named.
- **`aria-disabled` on a `<select>` never depends on the value chosen in that select.** A
  choice-dependent reason belongs on the button that commits.
- **A mutation that moves a shared summary's counts revalidates the summary's path too.**
- **A count over a bounded detail page under-reports a long Run.** The logical step
  counter is an exact SQL aggregate, held to the unit rule by an integration test.
- **`<details>` can never sit inside `<p>`**: the parser closes the `<p>` early, a
  hydration mismatch `renderToStaticMarkup` cannot show.

## 2026-09-22 — Production follows a draft branch, and `main` cannot start against it

The owner's 21 September UI/UX walkthrough (49 findings, 17 P1) was made against the DEPLOYED
product, and the deployed product is not `main`: Railway's `web` and `worker` services are
connected to `feat/auditor-workspace-v1-1` (PR #51, a 44-commit draft) at `ec673a0`, deployed
outside the Release workflow, and the production database is at schema generation **61**.
`main` supports 50..50, so a `main` image REFUSES to start there — its 21 September redeploy
failed twice on exactly that guard. Read `describe-service` (source branch and commit) and
`/api/health` (`schema`) before assuming a screenshot, a finding or a failed deploy is about
`main`.

- **A finding can name a surface `main` does not have.** The walkthrough's record queue and
  inspector (UX-22..26) are PR #51's `RecordReview`/`RunWorkspaceShell`; the rule each one
  needs is written down in the cleanup reports so it can be applied on top of that branch
  rather than rebuilt on `main` and thrown away at the merge.
- **The UI cleanup is based on `main`, in one shared layer plus five packages.** `design/time`,
  `Timestamp`, `references`, `Reference`, `TechnicalDetails`, `status-words`, `PageHeader`,
  `words` and `procedures/condition-words` are the one place a readable instant, a short
  reference, a technical disclosure, a status meaning or a condition sentence comes from;
  a raw UUID, a raw ISO instant or a `1 Observations` on an ordinary surface is a defect
  against EXPERIENCE.md's revised Formats row. The contract was revised in place and the
  walkthrough's decisions appended as their own section, BEFORE the packages were built, so
  five parallel agents never touched the contract or `CLAUDE.md`.
- **Five worktrees, five databases, five port pairs.** Each package agent got its own
  worktree (`.claude/worktrees/ui-pN`), its own install and build, its own migrated database
  (`ui_pN_test`, a name the throwaway guard accepts) and `PLAYWRIGHT_PORT`/`NORTHSTAR_PORT`,
  because two browser suites on one database is the trap recorded on 2026-09-10, and one
  `next dev` port is one suite. `globals.css` carries one labelled region per package so
  five branches append CSS without merging into one another's hunks.
- **A gate run beside two worktree builds fails on load, not on the code.** The package 1
  unit gate reported 2 failures in 1 file while two `pnpm build`s ran; alone it passed
  4610/4610. Read a red gate's failing file before believing it, and never run the gate while
  a build is going on the same four cores.

## 2026-09-20 — Selected Replay needs exact bounded context

A selected inspection uses its own bounded frame page with global ordinals and full-history
observation totals. Resolve ownership through the Step first, then the action, and bind every
join to the Run. Use Evidence ID as the final tie key: UUIDv7 generation within one millisecond
does not establish insertion order. Protected-image refusal keeps metadata and retries only
that Evidence ID. Browser-only network telemetry cannot establish server/worker zero calls.
Adversarial cross-Run fixtures must delete all owned capture/action children before either
Run's Steps, in one transaction; preserve the production guards during cleanup.

## 2026-09-20 — Bound record-query admission before acquiring its snapshot

Cursorless review reads use a transaction-scoped try-lock before context/projection. Busy
attempts release the transaction and connection before backoff; pool queuing is bounded
by a monotonic admission deadline. Fence late callbacks before SQL and after try-lock,
observe abandoned-promise failures, and stop the timer once admission succeeds so the
accepted transaction is awaited through commit. Cursor paging bypasses creation admission.
Do not use blocking advisory acquisition after a Serializable snapshot has been fixed: it
repeatedly materializes stale snapshots and causes serialization retry storms. Retain the
separate serialization retry budget, fresh authorization and two-snapshot bound.

## 2026-09-19 — Preserve fixture role timestamps as PostgreSQL text

Driver/test environments do not consistently return role timestamps as JavaScript Date
objects. Read `assigned_at::text` and restore it with an explicit `::timestamptz` cast.
This preserves the value without relying on either raw Date binding or `.toISOString()`.
An integration cleanup failure revoked the shared actor and invalidated later tests;
all four sibling workspace/review/controller fixtures now use the same text contract.

## 2026-09-19 — Exact receipt identity includes JSON value types

PostgreSQL JSON text extraction (`->>`) coerces a numeric value and a numeric-looking
string to the same text. Deferred receipt guards and read projections use JSONB equality
for anchor values and `to_jsonb` for typed command fields, so employee key `"123"` cannot
be replaced by JSON number `123` in a supposedly exact worker fact. The regression uses
a valid frozen P1 inspection and requires forged receipt insertion to fail.

## 2026-09-19 — An inspection pause is an immutable proposal and a sticky worker latch

The browser captures the current Run-owned Work Item when composition starts, independently
of a historical selected record. The persisted proposal binds that item, frozen plan digest,
Run revision and controller epoch. Confirmation accepts only Run ID + command ID, rechecks
role/current work/lease with PostgreSQL time, and requires readable governed intake AND
proposal content. A removed child proposal cannot be confirmed from an already-open modal.
After acceptance the safety latch survives role/lease changes; only the existing worker
boundary applies it after the named logical item settles. Check this before EVERY next
item, including one settled in the same invocation, not only already-terminal initial rows.
Immediate pause/cancellation supersedes it, and final-unit completion never creates an empty
pause. Receipts must match exact source events, including explicit null page subject keys.
The retained marker Work Item FK is deferred: fixture aggregate cleanup must delete children
and their Run in one transaction. Do not disable retention guards for test cleanup.

## 2026-09-19 — Disabled browser controls and failure cleanup

Playwright click waits for aria-disabled controls to become enabled. Negative tests must
use keyboard activation of the focusable control and assert persisted state remains
unchanged; waiting for a forbidden action to become enabled proves nothing. Restore
shared test roles before browser-context cleanup, because a timed-out context may already
be closed. The record-review revocation phase permits only Chromium's exact HTTP 403
resource message for that same Run, while page errors and all earlier console errors fail.
Workspace decision height must share space with the actual composer and a 120px history
floor: a fixed rem subtraction clipped the first answer at 1280×800.

## 2026-09-17 — The Work Item label, on all four surfaces this time

The Timeline was repaired so a Work Item row names the RECORD rather than the Target System,
whose `display_name` is IDENTICAL on every Work Item of a Run. The finding was closed there,
and an agent sweep then found the same line on **three** more surfaces — which is the Epic 5
review's rule, unlearned: *when a review lands a rule on one component, grep for its siblings
before closing the finding.*

- **Replay's jump list** labelled a Work Item pill `item.displayName`, so a three-leaver Run
  offered three pills reading "LoanCore" — beside an **Exception** pill that already named its
  record, so two kinds of target on one list disagreed about what a target is.
- **Replay's frame rail** said `Work Item: LoanCore` under every frame, and resolved its owner
  from the RAW nullable `run_tool_action.work_item_id` while the system name two lines above
  resolved it through the Step Execution — the PR 36 finding, still live on the next line.
- **Live View's rail hard-coded `subjectKey: null`**, so Watch — the surface a person uses to
  follow the Agent record by record — read "LoanCore · RUNNING · 1 Observations" whichever
  leaver was being inspected. `LiveViewer` had the branch and the page starved it, so the
  component's own test could not see it.
- **The narration could not name the record at all.** UX-DR37 makes the frame's `alt` the Step
  narration and Replay labels each scrubber pill with it, so a sentence naming only the system
  gave a screen-reader user three indistinguishable "…on LoanCore…" pills while the sighted
  reader saw the record on the jump list beside them. `stepNarration` and `frameNarration` take
  a `subject` and say "for E-000103 on LoanCore"; a Work Item with no record of its own (P-4
  inspects a page, not a population) says only where, never a dangling "for".

**`workItemLabel` lives in `labels.ts`**, not in `replay.ts`, because three surfaces say it and
`labels.ts` is already the one place a stored value becomes a word. The Timeline keeps its
two-span layout — title and detail — and implements the same rule, which is why the shared
function returns a STRING rather than being forced onto a surface whose layout differs.

- **`subjectKey` is REQUIRED on `ReplayWorkItem`**, which is what found both Replay call sites.
  An optional field would have let the page pass `undefined` for ever.
- **The replay browser fixture gave each Work Item its OWN `display_name`**, a row no Run can
  produce — that column is the Target System's name and both items named `loancore`. That is
  why the suite could not see the defect. Both are `LoanCore` now, and the spec asserts two
  distinct pills.
- **`[NAMED]` No browser fixture seeds a Work Item on Live View**, so the rail's Work Item line
  is covered by nothing in CI: `live-view.spec.ts` seeds neither `run_work_item` nor
  `run_agent_work`, and the page reads the second for the position. The deployed acceptance
  requires `watchNamesTheRecord` instead, which is a real check on the real surface and not a
  substitute for the fixture a later story should add.

## 2026-09-17 — Replay was the sibling nobody grepped for `[EXTENDED by the note above]`

The Execution Timeline was repaired the same day so a Work Item row names the RECORD it
inspected rather than the Target System, whose name is identical on every Work Item of a Run.
The finding was closed there. **Replay had the identical line twice and it was not looked at**
— which is exactly the rule this file already carries from the Epic 5 review: *when a review
lands a rule on one component, grep for its siblings before closing the finding.*

- **`replayJumpTargets` labelled a Work Item pill `item.displayName`**, so a three-leaver Run
  offered three pills reading "LoanCore" — on the one surface whose job is to let a reader
  follow a single record from the screen that was captured to the conclusion drawn from it.
  The **Exception** pill beside them already named its record, so the two kinds of target on
  one list disagreed about what a target is.
- **`workItemLabel` on every frame had it too**, so the rail said `Work Item: LoanCore` under
  each frame, and it resolved the owner from the RAW `run_tool_action.work_item_id` while the
  system name two lines above resolved it through the Step Execution — the PR 36 finding,
  still live on the neighbouring line. A frame whose Work Item is known only through its Step
  Execution therefore reported no Work Item at all.
- **`replayWorkItemLabel` is the one rule** and `subjectKey` is REQUIRED on `ReplayWorkItem`,
  which is what found both call sites: an optional field would have left the page silently
  passing `undefined` for ever. A Work Item with no subject (P-4 inspects a page, not a
  population) keeps the system name rather than gaining a separator with nothing before it.
- **Proven by mutation**: restore `label: item.displayName` and the jump-list test fails.
  The acceptance requires `replayNamesEveryRecord` beside `timelineNamesEveryRecord`, because
  an audit trail a reader cannot follow by record is not an audit trail.

## 2026-09-17 — A Result that waits for a person is not a conclusion

The acceptance stopped at `expectedPendingReview` — outcome `PENDING_CONFIRMATION`, `sealed`
false — and called the journey proven. It is not: C2 is Agent-Judged, so Story 4.9 holds the
Result open until a person confirms or rejects each machine proposal, and the owner's gate asks
for "a sensible overall control conclusion". A Run that produced findings and no conclusion had
completed the agent's half of the journey and none of the auditor's.

- **`confirmAgentJudged()` walks the real control.** One row per page load, because the
  component calls `router.refresh()` and the list re-renders under the button that was just
  used. A control with a reason is `aria-disabled` and never `disabled` — it has to stay
  focusable so its reason is reachable — so "can this be used" is read off the ATTRIBUTE, not
  from Playwright's enabled check, which would click a guard that is doing its job.
- **The decision is queued to the WORKER, so the banner is not the outcome.** "Review
  submitted." means the command was accepted; the Result seals a moment later. Every assertion
  is against the stored `run_result`, and the expected value is the oracle's own
  `expected_outcome_after_required_human_confirmation` rather than a literal typed beside it.
- **The conclusions are compared with the truth AGAIN after sealing.** Confirming a proposal
  is a WRITE. An acceptance that compared only the pre-confirmation rows would have checked
  values the sealed Result does not necessarily stand on.
- **It runs only when the Run really is waiting on a person.** Guarded on
  `expectedPendingReview`; on any other Result it would spend five minutes proving nothing,
  and the two new checks stay absent, which leaves `accepted` false — the honest answer for a
  journey that did not get there.

## 2026-09-17 — Driving the acceptance journey end to end, and the checks that could not fail

The owner's remaining gate is one unbroken journey: create a Procedure in the browser,
configure it, submit it, have a SECOND person approve it, activate it, start the Run, watch
it inspect records. Driving that journey locally against the real build — a copy of
`scripts/verify-deployed-loancore.mjs` pointed at a local web server — found two defects no
suite had. Neither is in the domain; both are in the surface, and both stop the journey dead.

- **A controlled input discards what was typed before React attached, and the one place that
  costs a CREDENTIAL is the sign-in form.** `7efb284` fixed this for the Procedure form and
  the same shape was still live one page earlier: fill the fields while the bundle is still
  loading, and React's initial empty state replaces them on hydrate — so the POST carries
  `{"email":"","password":""}`, Better Auth answers **400**, and the person is told **"Check
  your email address and password."** about a credential they typed correctly. It is
  intermittent by construction: it depends on whether the person types faster than the bundle
  loads, which is exactly the case a fast operator and a cold deploy both reach. The repair is
  the Procedure form's: a native `<fieldset disabled>` (the only guard that holds BEFORE
  handlers exist), `data-signin-ready`, and the two sentences in ordinary markup — never
  `<noscript>`, for the reason the note below this one gives.
- **The decisive assertion is what was SENT, not that the submit worked.**
  `tests/e2e/sign-in-readiness.spec.ts` blocks the scripts, types, releases them, submits, and
  then reads the request body: `sent.email` and `sent.password` must be what was typed. An
  assertion that the sign-in succeeded passes on a build with no guard at all, because the
  browser that is quick enough to be tested is usually quick enough to hydrate first.
- **A normalising compiler and a section machine that records the raw edit declare a conflict
  after a save that SUCCEEDED.** `compileComplianceDraft` trims, deduplicates and SORTS a
  role-privilege policy's lists; `useSection.begin()` recorded the edit as typed, so the next
  server snapshot differed from it and `observe()` flagged `conflict`. Every "Mark reviewed"
  control then refused with **"Resolve the saved-value conflict in Compliance Rule before
  submitting."** — naming a conflict with nothing on screen to resolve — and submission was
  blocked until the page was reloaded. `storedComplianceInput` ASKS the compiler what will be
  stored rather than restating its rules, and feeds it to both `useSection`'s
  `normalizeBaseline` (which already existed, for `EvidenceScheduleForm`) and `begin`.
  **A second copy of a normalisation diverges on the first edge nobody tried**, which is why
  this is a call into the compiler and not a `sort()` in the form.
- **An input the compiler REFUSES is returned unchanged, deliberately.** The command refuses
  that save too, so the section reports the refusal; normalising a refused input would compare
  the server's snapshot against something no save could ever produce.
- **The journey is the test that finds this class.** Six saves and six section reviews pass
  individually in `procedures.spec.ts`; what fails is saving one section and then reviewing
  ANOTHER, which only a journey does. Both defects were invisible to every unit, integration
  and browser suite in the repository and visible within one run of the acceptance harness.

**And the acceptance itself was checking the wrong things, in four places.** The harness is
what produces the proof, so a check that cannot fail is a proof that is not one:

- **An aggregate count of Exceptions is true of a build that flagged the WRONG leaver.**
  `expectedEvaluations` asserted six evaluations, one C1 Exception and three C2 Compliant —
  all of which hold if E-000102 were reported as retaining access and E-000103 as disabled.
  `scripts/acceptance-truth.mjs` compares PER RECORD and PER CONDITION against
  `p-1-live-acceptance.json` read off disk, and it has its own tests
  (`tests/unit/acceptance-truth.test.ts`) precisely because nothing inside
  `verify-deployed-loancore.mjs` can be tested: that file refuses to load without a live
  database and an explicit authorization. The swap case asserts the totals are IDENTICAL
  before asserting the comparison catches it.
- **`report.checks.providerHandleContained = true` was a literal.** The containment is real
  — `shot()` throws if any scanned page carries the provider's session identity — but the
  check could not fail, including for a Run whose identity nothing had ever seen. It now
  requires a known identity and a counted number of scans taken AFTER it became known.
- **The Execution Timeline could not say WHICH record a Work Item inspected.**
  `displayName` is the TARGET SYSTEM's name and is identical on every Work Item of a Run,
  so a three-leaver agent Run rendered as three rows called "LoanCore" — on the one surface
  an auditor follows from record to conclusion. The Runs list and Live View both name the
  subject; `RunTimelineWorkItem` carries `subjectKey` now and the row leads with it, with
  the system name beside the counts. A Work Item with no subject of its own (P-4 inspects a
  page, not a population) keeps the system name as its title rather than gaining a dash.
- **The acceptance workflow's `push` trigger RACED the release.** A push to `main` started
  it at once, while CI was still running and Release had therefore not deployed the commit
  — so it drove the PREVIOUS build, which is exactly how the 2026-09-17 run came to stop at
  `create-procedure` against a build without the fix it was testing. The trigger is gone;
  the workflow now refuses to start at all unless `/sign-in` server-renders the hydration
  marker, which one public request settles before any identity is created.
- **The workflow also patched the harness's source at run time** to add the cancellation
  repository — a second copy of the command shape that only the workflow could break, and
  that any edit to those exact lines would have broken silently. Folded into the script.
- **The negative case is the same journey, not a second copy of it.** The authoring flow is
  one function now, called with the clean population and (behind `negative_case`) with the
  defective 27-row export. It asserts the Run stopped, that no conclusion exists about any
  record, and that the Gate names E-000107 — a "the Run failed" assertion alone would pass
  for a Run that failed for any other reason.

**And the repair for one of those four was itself a check that could not fail.** The
Evidence-link check looked for `could not be read` and `no longer available` — phrases NO
page in this product renders. The evidence inspector states every one of its thirteen
`EvidenceSnapshotReadFailure` cases under one banner title, `Snapshot cell unavailable`, and
`[SUPERSEDED 2026-09-26 — see the Story 10.8 note at the top: the boundary no longer says it,
and the harness matches its heading]` the route boundary has EXPERIENCE.md's own `Couldn't load
this page. Nothing was changed.`
So a link showing the inspector's own failure banner was reported as OPENED. **A sentence a
checker looks for is pinned against nothing unless it is read back out of the page that
renders it** — `copy.test.ts`'s discipline, which had never been applied to the harness.
`tests/unit/acceptance-sentences.test.ts` reads both pages off disk, and its fourth case
proves every check the harness COMPUTES is in the list it REQUIRES before accepting: a check
computed and left out of `report.required` is a check whose failure nobody would ever see.
Proven by mutation — removing one name fails it and names the check.

Three mechanical notes:

- **The Builder polls only while a plan derivation is PENDING** (`ExecutablePlanPreview`:
  `if (draft.planStatus !== 'pending') return;`), so `procedures.spec.ts`'s *"a pending plan
  refresh preserves dirty Period edits"* needs the derivation still to be in flight when the
  second tab saves. A worker fast enough to settle it first leaves the edited tab with
  nothing to re-read, no conflict banner, and — because a failing Playwright test restarts
  the worker and runs `afterAll` early — a dozen later failures that are its shadow. It is
  green in CI and red on a fast machine. **Read the FIRST failure, and check whether a
  browser test's scene depends on something finishing SLOWLY.**
- **`seed-identity` never resets a password, so `E2E_PASSWORD` must match the accounts that
  are actually there.** A local database seeded in an earlier session answers a correct-
  looking sign-in with *"Sign-in failed. Check your email address and password."* — which is
  the product working, and reads exactly like the hydration defect above it. Seed fresh
  addresses (the rule is already recorded; it was met again here) and check the page snapshot
  in `test-results/**/error-context.md` before suspecting the code.
- **`deployed-loancore-evidence/` is now ignored.** The harness writes
screenshots and a report there; CI uploads it as an artifact and a local dry-run leaves it in
the tree, where a `git add -A` would sweep it in — the class `.claude/worktrees/` and
`**/__boundary_violation__/` are already ignored for.

## 2026-09-17 — `<noscript>` is invisible to the test that exists to read it

The procedure-form hydration repair (`7efb284`) put its requirement sentence inside
`<noscript>`, and `new-procedure-readiness.spec.ts` then asserted that sentence in a
`javaScriptEnabled: false` context. It failed with "element(s) not found", which held main's
CI red — so Release was SKIPPED and the repair never reached production, and the deployed
LoanCore acceptance stopped at `create-procedure` against the OLD build. One test, one job,
the whole delivery.

- **Chromium's `javaScriptEnabled: false` disables script EXECUTION and leaves the HTML
  parser's scripting flag ON.** So `<noscript>` children stay RAW TEXT — no elements, nothing
  a locator matches, and the user-agent rule hides them. The SSR unit test passed because
  `renderToStaticMarkup` really does emit `<noscript><p>…</p></noscript>`; the markup was
  never the problem. **A sentence only a real browser preference can reveal cannot be pinned
  by this suite, so it must not be the only place the product says it.**
- **`<noscript>` also answers the wrong question.** It covers exactly one failure — scripting
  off at parse time — and none of the ones that actually happen: a chunk that 404s after a
  deploy, a proxy that blocks the bundle, an exception during hydration. In every one of those
  the form sits for ever under "Preparing the form. Choices will be available when loading
  finishes." — a sentence that is then the opposite of true. `NEW_PROCEDURE_REQUIRES_JAVASCRIPT`
  is rendered by the server EVERY time and removed by hydration, so whatever stopped the
  handlers attaching, the reader is told what to do.
- **Both sentences live in `apps/web/src/procedures/new-procedure-words.ts`**, free of React
  and `next/navigation`, because the browser spec imports them — the `run-start-words.ts` rule:
  a sentence retyped in a test is a sentence pinned against nothing. Proven by mutation: put
  the sentence back inside `<noscript>` and the spec fails.
- **A killed background browser run leaves its rows behind**, and `procedures.spec.ts`'s
  empty-list test is what finds them. `afterAll` never ran, so the next foreground run met
  four leftover Procedures and failed an assertion that had nothing to do with the change.
  The database read `0` by the time it was checked, because that run's own teardown had since
  cleaned up — check the leftovers WHILE the failure is fresh, or re-run against a clean
  database before believing it.

## 2026-09-17 — Verify the public reference, not the provider capability

The Live View browser test still expected the provider handle after redaction.
Require the platform workspace reference, reject the handle anywhere in HTML/RSC,
and prove that the operational row still retains it for the worker. Never restore a
capability to satisfy an obsolete display assertion.

The separate three-record live acceptance population preserves canonical HR rows and
leaves the defective full export unchanged. Expected findings are test-only data,
never source CSV fields or agent prompts. A valid source is not an all-compliant source:
E-000103 deliberately retains Active access.

## 2026-09-17 — Provider workspace handles are capabilities, not display IDs

Solari's browser connection URLs use the signed session ID as their capability. Keep
`WorkspaceRef.workspaceId` only in operational worker state for reattach/release.
Public Timeline reads explicitly exclude that column and expose `workspace-<run-id>`;
Live and Replay receive only that platform reference. New workspace/access/recording
events carry the reference, and the append writer rejects capability-shaped payload
keys. This policy is append-only: canonicalization and historical chain verification
are unchanged. Do not rewrite old immutable events to hide an expired handle. Existing
public event reads project selected fields (the live channel sends sequence numbers),
not arbitrary historical payloads. Never enable a raw provider-control URL as a viewer.

## 2026-09-16 — The owner's workspace fix, validated by two live Runs on production

The owner widened `run_workspace_identity_shape` to 4,096 characters (generation 50, because a
Solari session id is longer than 200) and moved the workspace-state save inside the provider-error
handler, then asked for a real Run against the deployed product rather than a test. Two were started
through the live UI as a seeded auditor account.

- **The fix holds: a Solari workspace is created, SAVED and then USED.** The P-1 Run's Execution
  Timeline reads `Create the Agent Workspace — Managed remote browser · 1 attempts · Released` with
  its Step Execution `Succeeded · 2s`, then `LoanCore — Sign in to the Target System · Acquired`
  (`Succeeded · 3s`) carrying the Tool Action `navigate · POST · Performed · status 200 ·
  redirected · Capture suppressed — a credential was presented on this request` against
  `…/loancore`. Before the fix both of the owner's Runs died about five seconds in, `RUN_FAILED`,
  with "The Run stopped before it concluded, and no stage recorded why." and two `Fatal worker
  error` lines. Nothing else in this repository could have shown that: the local mode never produces
  an identity long enough to violate the CHECK.
- **A P-4 Procedure Version that freezes a SECOND Target System can never run, and the sentence does
  not say so.** `publicP4Target` requires `plan.inputs.targets.length === 1`, so the production P-4
  — ProdConsole (web) **and** ConfigRegistry (published file), the latter already bound as the
  Population Source — makes `publicContractInvalid` true at the AGENT CLAIM, before any Session Step
  row is written. The Run therefore shows two Session Steps, NO `sign-in` row, no Tool Action, and
  the banner "The public page is not the surface this Procedure Version froze." — which names a page
  the Run never opened. The guard is deliberate ("an extra target would make the public proof
  ambiguous"); what is missing is a diagnostic of its own and an authoring-time warning. P-4's
  `defaultTargets` names ProdConsole alone, so this Version was authored that way and not suggested.
- **Read the TIMELINE before the diagnostic.** Two hypotheses were wrong before the rows settled it:
  that the frozen origin was the deeper `/prodconsole/configuration` (it is `/prodconsole`, which
  serves exactly one in-scope link), and that a sorted origin set put the CSV first. An ABSENT
  Session Step row is the fact that located the failure at the claim rather than in the page proof.
- **P-1's remaining stop is the golden dataset working.** The full leavers export seeds a duplicate
  employee key, so the agent stage refuses the whole Run (`population-key-unresolved`) and §H reports
  `duplicate-primary-key · 1 affected` (E-000107) beside `record-uncovered · 19 affected`. Already
  recorded above; restated here because it is what a live P-1 Run against the full export looks like.

## 2026-09-16 — A provider success is not a committed workspace

The provider catch did not enclose the OPEN checkpoint transaction. A database CHECK
failure escaped after a browser existed, leaving PROVISIONING and no failed Step
Execution. Provisioning now seals a named workspace-persistence-failed stop in a fresh
transaction, retains the valid session identity for cleanup/reaping, and releases it
outside that transaction. Reconcile a lost COMMIT acknowledgement under the Run lock
before any release: never revoke a committed or newer claimant's session. When ownership
cannot be read, report workspace-persistence-unconfirmed; do not guess that COMMIT failed
or claim cleanup succeeded. Provider lifetime remains the backstop during database outage.

Diagnostics carry only Run/stage/closed codes. A bounded, getter-free cause walk admits
known SQLSTATE/transport codes, never messages, SQL parameters, provider identities, URLs
or arbitrary properties. Telemetry cannot break sealing. Invalid provider IDs fail explicitly.
Cleanup changes FAILED to RELEASED; the reader recovers the FIRST terminal workspace
failure from the immutable chain, so UI surfaces and Run-ended logs retain the cause.
Tests cover rollback, unavailable cleanup, lost acknowledgement, database outage, invalid
IDs and hostile diagnostics; PostgreSQL proves a real CHECK rollback and the retained
Step Execution/stop reason after release. This does not certify live Watch or Replay.

## 2026-09-16 — Solari workspace identities are opaque, not short IDs

Production Run 01a0abec-17dc-735c-a924-8cd077f31da9 reached the OPEN
checkpoint, but PostgreSQL rejected it with run_workspace_identity_shape.
The original CHECK capped provider identities at 200 characters. Solari had
already returned a browser; this was a persistence failure, not proof of a
provider outage. Generation 50 expands the bounded storage budget to 4096
characters without truncating, hashing or rewriting the identity. The full
value is needed to reattach and release the same session. Historical migrations
are unchanged. The PostgreSQL regression covers 201, 768 and 4096-character
synthetic identities through provision, reattach and terminal release.

Never put real provider identities, protocol URLs, database parameters or
exception messages into incident reports. Failed checkpoint persistence must
also have a named failure path and safe cleanup; the schema repair alone does
not prove live viewing, replay or an end-to-end audit execution.

## 2026-09-16 — A page that asserts an empty state without reading anything is not reporting

The owner's production walkthrough filed thirty findings, and the largest class was one
defect wearing three faces: **a Story 1.4 placeholder that renders a contract empty state
UNCONDITIONALLY and reads nothing at all.** The Overview said "Nothing needs attention",
"none is Inconclusive or Run Failed" and "No Runs yet" while the register two clicks away
held one Run Failed and two Inconclusive Runs — and said it again after every reload,
because there was nothing for a reload to change. The Procedures list said "No Runs yet"
and "No outcome" beside a Procedure with two Runs. The manager's Review page still says no
Result awaits a decision while a version waits for that manager. **An empty state is a
STATEMENT ABOUT THE ENVIRONMENT, and the one those pages made is the inference every empty
state in this product is worded to refuse.** Findings, repairs and what is left for a
decision: `_bmad-output/implementation-artifacts/owner-walkthrough-2026-09-16.md`.

- **Both contract sentences stay, for the case they were written for, and what decides
  between them is an EXACT COUNT.** Never `rows.length` of a bounded page: a summary that
  said "nothing needs attention" because three stopped Runs fell off the end would be the
  same defect with a database behind it. Each read answers a total beside its bounded list.
- **An unreadable read is not an absence, on the Overview as on Live View.** Story 5.6
  landed that rule on `OpenEscalationSection`; the Overview is the same read failure one
  surface along, so it renders a Banner and the "nothing needs attention" state becomes
  unreachable. `countOpenFor` throws separately from `openFor`, so an unreadable COUNT loses
  only the bounded note.
- **A surface that shows Run facts authorizes like the Runs register.** `/procedures` is not
  gated on `run.initiate` and `/runs` is, so putting Run outcomes on the Procedure card
  would have handed a PoC Administrator what `/runs` refuses them. The Run reads are SKIPPED
  for a role without that action and the cell says so — not reading is the control, never a
  hidden cell.
- **`apps/web/app/review/page.tsx` is the third face and is NOT fixed**, named in the report
  with the reader it should use. A defect class found in three places is fixed in three
  places or written down in the third.

**The other repairs, one line each.** The Result tab's execution-failure panel reads the
same stop facts the Runs list does (PR 39's `DrizzleRunStopReader`), so the header, the
list and the panel cannot disagree. Every Run stage has a WORD (`apps/web/src/runs/stage-words.ts`),
so "0 of 0 Step Executions" became a sentence naming the stage that stopped. Replay's
Observations link pointed at a route that does not exist and now points at the Evidence tab.
A Replay with no frames gets an empty-state sentence rather than one implying a frame. The
shell names the signed-in person and their role. The Builder's section review record and the
version review name the auditor through `ActorName` instead of printing a user id. The
Target System step no longer demands a desktop system four elements under a caption saying
to leave it out — `targetCoverageMissing` is narrowed at its SIGNATURE, which is what found
the other four callers. The frequency step is named for what it takes, with the compiler's
frozen handling facts shown read-only beside it.

- **`Object.hasOwn` for a lookup keyed by a person's typed words — ninth occurrence.**
  `preparationCommand`'s destination table is a plain object keyed by chat input, so "go to
  constructor" resolved to `Object.prototype.constructor`, the guide said "Opened undefined."
  and `setSelected` was handed a function. Found by an agent in passing, in a module its own
  brief told it not to change; it reported rather than fixed, which is why it got fixed.
- **A contradiction inside FROZEN compiler bytes is resolved by a sentence beside them, never
  by an edit.** `makePlan` writes "exact normalized employee_id" and "never trim, normalize"
  into canonical plan text every ACTIVE version has frozen; editing it would change what
  those versions say they were testing. `IDENTITY_KEYS_EXACT_SENTENCE` sits directly above
  the steps that carry both phrases, on the Builder and on the version review.
- **A new field on a result shape breaks every exact-shape assertion, and only the suite that
  RUNS can say where.** `ProvisionWorkspaceResult` gained `deferred`; the unit tests were
  updated with the fix and six `toEqual({ retry, provisioned })` assertions across two
  integration files were not, so nineteen tests failed on a change whose typecheck was green.
  The commit that added the field ran one integration FILE and called it verified. Run the
  suite the changed module is covered by, not the case you wrote.
- **A stale `audit-manager` row in the test database fails two files that never created
  one.** `runNotificationRecipients` reads every audit-manager in the database, so one
  account left behind by an aborted run made `flag-run` count 4 deliveries where it expects
  2 and `run-waits` count 3 recipients where it expects 2 — both reading as product defects
  in the notification path. Check `user_role` before believing a recipient count, and clean
  identity leftovers the way Run leftovers are already cleaned.
- **The golden P-1 population cannot demonstrate a clean pass, and that is the dataset
  working.** It seeds a duplicate employee key, an unnamed status value and a two-candidate
  name search; the first stops the agent stage before it makes a single Work Item, and the
  other two park the Run `AWAITING_AUDITOR` for thirty minutes. The owner journey therefore
  binds a declared single-record source and leaves the full export seeded but unbound, so
  the choice is visible rather than silent. **And the agent path and the adapter path
  disagree about a duplicate key** — the adapter deduplicates and reports
  `duplicate-record-keys`, the agent refuses the whole Run — which is named in the report
  rather than changed inside a test.
- **P-1's Template default for C1 does not match what LoanCore displays** (`[disabled]`
  against `Disabled`), and compiler-1 compares named values exactly, so an auditor who
  accepts the default escalates on every record. The journey types what the system shows and
  asserts the default first, so the mismatch is pinned.

Three mechanical notes, and the first is the one a whole batch of red tests hung on:

- **A teardown can only be wrong once the test in front of it starts passing.**
  `owner-walkthrough-p1.spec.ts` deleted `run_evidence_capture` with the other Tool Action
  rows, and generation 32 puts the same `run_evidence_frozen_after_seal` trigger on that
  table that generation 27 put on `run_evidence` and `population_evidence` — so the first
  time the journey reached a SEALED Run, the delete was refused, the whole `afterAll` threw,
  and every row the file created survived to fail an unrelated file's empty-list assertion.
  The seal and its three siblings (`run_gate_check`, `run_evidence_integrity`, `run_result`)
  reference only `audit_run`, so they go FIRST. **`pg_constraint` is not the whole answer**:
  the refusal came from a trigger, not a foreign key, so the search that found it was
  `pg_trigger` joined to `pg_proc`, and it named a third table nobody had listed.
- **A constant two of whose four members nothing renders is a pin on a product that no
  longer makes that claim.** RUN-05 filled the card's Next Run and Last outcome cells from
  facts and left `PROCEDURE_CARD_ABSENT.nextRun` and `.lastOutcome` behind, still asserted
  by `copy.test.ts`. Deleting the two pins would have moved the "never a dash" rule out of
  those cells' reach, so the rule is now asserted over all four sentences TOGETHER, with the
  moved pair imported from `last-run-words.ts`.
- **`getByText(word, { exact: true })` inside a region is a locator whose uniqueness a
  product change can take away.** `populationStatusWord` began rendering `POPULATION_READY`
  as "Acquired" — the word the Reference Source step already produced — so two Timeline rows
  matched and Playwright's strict mode refused. Both rows are correct; the assertion is
  scoped to its own `.ls-timeline__row`, filtered by the row's title.
- **Chromium does not read the system CA bundle; it reads NSS at `~/.pki/nssdb`.** Driving
  the DEPLOYED application from this environment goes through the agent proxy, whose CA
  Chromium rejected as `ERR_CERT_AUTHORITY_INVALID` although curl was fine. The repair is
  `certutil -A -t "C,,"` for each certificate in `/root/.ccr/ca-bundle.crt` (install
  `libnss3-tools` first), NEVER `ignoreHTTPSErrors` — a walkthrough of a production site
  with certificate verification switched off proves less than no walkthrough at all.

**Codex found six on PR 40, two of them in the workflow this batch added, and every one
reproduced.** The two P1s are one rule with two holes, and the rule is about a GitHub
Actions `run:` block:

- **`${{ }}` is substituted by GitHub BEFORE bash parses the script, so a dispatch input is
  part of the PROGRAM, not data.** An input containing a quote and a semicolon runs as a
  command — here in a job holding the production `DATABASE_URL`. Every input crosses as a
  quoted environment variable now, the pre-existing `confirm` check included: it had the
  same shape from the first version of that file and nobody had looked at it since.
- **A command that UPSERTS is not a command that refuses, and a comment claiming otherwise
  is worse than no comment.** `seed-identity` finds an existing user and upserts the role,
  so the "this cannot take an existing account over" note was false, and the path could
  name an existing auditor with `poc-administrator` — elevating an account whose password
  is already in an earlier run summary. `--create-only true` refuses BEFORE the role
  upsert. The three fixed demo addresses keep the upsert on purpose: re-asserting a
  CONSTANT address is what that path is for, and free text is what needs the flag.
- **A limit belongs to the cardinality of the READ — third appearance.** `readStops` sliced
  to `RUN_LIST_PAGE_SIZE + 1` while the Procedures list returns up to `PROCEDURE_LIST_LIMIT`
  (200), so every card past the twenty-sixth lost its stop reason silently — and a card with
  no reason reads as a Run that stopped for none. `RUN_STOP_READ_LIMIT` is the max of both
  callers' own limits, and the test asserts it against THOSE constants rather than a copy of
  the number, so raising either without raising this fails.
- **An ordering the contract states is not an ordering time produces.** EXPERIENCE.md lists
  the Overview's attention items "… Inconclusive · Run Failed …"; ordering by
  `initiated_at` alone interleaved them and then applied the ten-row bound to the mixture,
  so ten recent failures could hide every Inconclusive Run. The rank is built from
  `RUN_STOP_STATES`, which is already in that order, so the contract lives in one place.
- **Two claims in one sentence is one claim too many when only one of them is always true.**
  "…a desktop system is left out AND your selection is complete without it" rendered
  whenever a desktop default was unselected — beside "No Target System is selected yet".
  The release fact and the claim about THIS selection are two constants now, and the second
  renders only when `diagnostics` is empty.
- **"No Step Execution" has more than one cause, so the sentence may not name one.** Both
  zero-step sentences said the Run was creating its workspace and acquiring its population;
  a Run that signed in and then stopped has no Step Execution either, and the sentence then
  contradicted the stage rows directly above it. They say the one thing true of every such
  Run — it never reached a record — and point at the rows that know.

## 2026-09-16 — The owner's first Solari Run died five seconds in, and the worker's log said nothing

The owner walked P-1 through production end to end — created, approved by a second account,
activated, started by hand — and both Runs failed about five seconds after they started:
after acquiring the population, before any Step Execution, with the Result saying "The Run
failed before any Session Step recorded a diagnostic" and the worker's Railway log holding
four boot lines and nothing about either Run. Root-caused by READING, because nothing
observable said why. Findings, repairs and what the walkthrough report asked for:
`_bmad-output/implementation-artifacts/owner-walkthrough-2026-09-16.md`.

- **The population recovery sweep hands a live Run to a second handler.** `recoverableRunIds`
  selects a `RUNNING` Run with no `population_execution` row every five seconds — the Story
  5.3 note calls that abandoned, and it was, until Story 4.1 put the workspace stage BEFORE
  acquisition. A provider session takes seconds to create, so for those seconds a healthy
  Run IS "RUNNING with no population row". The queue's delivery held the workspace lease;
  the sweep's handler lost the claim, got the same `null` an adapter-only Run gets, carried
  on to acquire the population, and reached the agent claim — which found a workspace that
  was not `OPEN` and ended the Run `workspace-missing`, `RUN_FAILED`. The winner's `OPEN`
  commit was then lost (the Run was no longer `RUNNING`) and its provider session leaked. A
  local Chromium launches in under a second, so acquisition always finished after `OPEN` and
  no test could see it; Solari made the window five seconds wide, and the tick fell inside
  it twice out of two.
- **Three rules say one thing now, each proven by mutation.** `provisionWorkspace` returns
  `deferred: true` when another claimant holds a live lease and `handle`/`recover` stop
  there; the agent claim WAITS on a `PROVISIONING`/`RETRY` row (`workspacePending`) instead
  of failing it; and the sweep excludes a Run under a live provisioning lease.
  `workspace-missing` now means what its name says: no row, or a `FAILED`/`RELEASED` one
  under a `RUNNING` Run. **A `null` that means two things is the defect shape** — `null` was
  both "needs no workspace" and "somebody else is provisioning it", and only the first is
  safe to carry past. Say the second by name.
- **The worker logs `Run ended` for every Run that reaches a terminal state under it**, with
  the Run id, the state, the stage and the closed diagnostic — the same stop facts the Runs
  list reads, so the log and the surface cannot disagree. An operator with only the log had
  NOTHING to read. `runId`, `state`, `stage` and `diagnostic` joined `TELEMETRY_FIELD_KEYS`,
  and the test asserts the four survive sanitization.
- **Railway's log API answered an empty array for a window the stream had nothing in**, and
  the same for a filter naming the Run. Check the query against a window that provably has
  lines before concluding a service logged nothing — done here; the worker really had not.

Two mechanical notes:

- **`startup.test.ts` scans `main.ts` and anchors on `const handle = async (job` and
  `const recover = adapter === null`.** A wrapper that renames either breaks a test that is
  right to exist; wrap INSIDE the names instead (`handle` delegates to `pipeline` under a
  `finally`, and each arm of `recover` is `logged(...)`).
- **The provisioning claim is the Run's FIRST boundary, so a deferred claim leaves the Run
  `QUEUED`.** The first version of the deferred test asserted `RUNNING`.

## 2026-09-16 — A page of Runs must say why each one stopped, and who started it

The owner sent a screenshot of the production Runs list — *"all the runs failed, also whats
wrong with this picture?"* — and nothing on that page could answer either question. Every
Run had stopped at acquisition because the synthetic snapshot (generated 2026-09-01) was
older than the period the owner chose (to 2026-09-15): the `freshness` check, recorded by
the population stage as a code word and shown ONLY on the Execution Timeline tab, in
monospace, under a row nobody opened. The list said "Inconclusive · No conclusion issued",
the Initiator column printed UUIDs, and the Run id column had collapsed into a strip of
four-character lines. **A closed diagnostic is a fact the platform knows; a surface that
shows it as a code, or not at all, has not told the auditor anything.**

- **`DrizzleRunStopReader` reads the stop facts for a page of Runs in one statement**, and
  the same statement answers for one Run, so the list and the header cannot disagree. The
  first TERMINAL checkpoint in execution order wins (population, workspace, sign-in,
  extraction, inspection); `canceled` is never a stop (the cancellation banner names the
  person); and a Run this deployment could not run is read from the chain's
  `lifecycle.run-unexecutable` event, because `stopUnexecutableRun` writes NO checkpoint —
  without that read it would look like a Run nothing recorded anything about.
- **`apps/web/src/runs/stop-reason.ts` is the one place a diagnostic becomes a sentence**,
  typed against each stage's own union (`Record<AgentWorkDiagnostic, string>` and its
  siblings), so a diagnostic added to a stage without words here does not COMPILE. A value
  the tables do not hold still gets a sentence — the stage and the code, in quotes — never
  a blank. `freshness` reads `population_snapshot.generated_at` to say WHICH way the
  snapshot was unfit (before the period ended / after the Run started / undeclared) and
  what to do about it; generation 24 added that column for exactly this. A stage stop
  outranks the Gate on purpose: an agent Run at its time limit records every §H row before
  sealing (2026-09-08), so both exist and the limit is what ended it.
- **A wait whose deadline passed is a stop the wake records on the WAIT row, and nowhere
  else.** Codex found it on PR 39: `wakeEscalation` closes the `run_wait` with
  `closure_kind = 'timeout'` and ends the Run `INCONCLUSIVE` through `completeRun`, and no
  stage checkpoint turns terminal and no §H row is written — so the first version fell
  through to "no stage recorded why" for the one stop whose record is the most explicit of
  all. The reader joins the latest timed-out wait (`stage: 'wait'`, `pause-timeout` or
  `escalation-timeout`, the kind and the deadline beside it) after the stage checkpoints
  and before the chain's unexecutable event; an ANSWERED or RESUMED wait is not a stop.
  **A "no stage recorded why" fallback is a claim about every record the platform keeps,
  and it has to be checked against each of them, not only the checkpoint tables.**
- **The Initiator is a person.** `ActorName` renders `ActorNameReader`'s answer and the id
  in monospace only when no name is known; the cancellation and rerun banners are the
  siblings `PauseBanners` was repaired for in the Epic 5 review and had the same defect.
  Two browser specs PINNED the id (`Canceled by ${auditorId}`), the `pause-resume.spec.ts`
  shape again; both assert the name now and that the id is gone. `runCanceledBy` fills
  through `fillTemplate`: the actor is a NAME now and `String.prototype.replace` expands
  `$&` in a string replacement — the third template this has reached.
- **A hyphen followed by a digit is not a line-break opportunity in any browser** (UAX #14
  keeps `-7000` together), so "wrap the id at its hyphens" needs `<wbr>` after each one:
  `Identifier.tsx`, used by `DataTable` for every monospace first cell, plus a 20-character
  minimum on the span. `<wbr>` has no text content, so copy, accessible names and
  `getByText` still see the whole id. EXPERIENCE.md's "long identifiers wrap
  (`overflow-wrap: anywhere`)" is refined for UUIDs in a ten-column table, not replaced:
  `.ls-identifier` turns it off only inside that span, and a digest still wraps anywhere.
- **The live feed is clean in production mode, and the server is not what the owner saw.**
  `next start`'s standalone server, signed in with curl and asked for gzip: heartbeats at
  +10.04 s, +20.04 s and +30.04 s, no `content-encoding`, `cache-control: no-store,
  no-transform`, `x-accel-buffering: no`, chunked. Railway's docs say SSE is passed through
  unbuffered, and earlier production streams ran their full fourteen minutes. So "No update
  for 24 seconds" was a real gap on the owner's own connection, reported honestly by the
  banner, which reconnects by itself at sixty seconds. Nothing to change; the check is
  `scratchpad`-only and is described here so the next reader does not repeat it.

Two mechanical notes:

- **A test that says a code word must not appear has to allow the words that are English.**
  `not.toContain(name)` over every population check failed on `declaration`, because the
  sentence for it says "declaration". Only a hyphenated name is ever a code.
- **`freshness` fails on THREE legs, and only two are about the dates.** A snapshot dated
  after the period end and before the Run started can still fail it when the declaration
  and the response disagree about the time, so the "plain sentence" case needs dates the
  reconciler would have passed — the first version of that test built a date that was
  really the second leg and expected the third.

## 2026-09-15 — Ad hoc Runs exist, and the Schedule time starts nothing

The owner could not start a Run when they wanted one: *"i have to set a time scheduled to run
only at that specific time... i need to be able to run adhoc runs"*. Nothing was missing.
Initiate Run has been on the Procedure page since Story 3.1, takes only the dates the audit
covers, and queues at once; no scheduler exists, because that is Epic 8. What was wrong was the
surface: the Schedule step demanded a "Start time (UTC)" even for Once, which reads as "when it
will run"; nothing in the Builder named the box that starts a Run; and the box never said the
Run starts on confirmation. **Before building a "missing" capability, find the control that
already does it and read the words around it.**

- **Choosing Once fills an EMPTY start time with 00:00** (`scheduleEdit`, the value P-1's
  Template already pins). The domain shape is unchanged — `startTime` stays required and
  `HH:MM` — because a one-time Schedule's time is kept for the record and starts nothing, so
  the surface may supply it. Daily, weekly and monthly are left empty: there the time will
  mean something once a scheduler exists, and a default nobody chose would be the instant it
  fires at. A time the person typed is never replaced — and a GENERATED midnight leaves with
  Once: `scheduleEdit` carries a `generated` flag, typing clears it, a save makes the value
  the record, and switching to a recurring frequency clears a time the flag still marks.
  Codex found the first version letting Daily inherit the midnight Once had generated.
- **The words live in `apps/web/src/design/run-start-words.ts`, and four surfaces read them.**
  Not `copy.ts`: those are quotations from the UX contract, these are the platform's own
  sentences. `run-start-words.test.ts` refuses a retyped copy on any of the four and pins the
  `#initiate-run` anchor to the `id` the form renders, so a renamed box cannot leave every
  link to it landing at the top of the page with nothing saying so.
- **A one-time Active version's "Start a Run now" carries its saved Period as a QUERY, and a
  suggestion is not a resume.** `?from&to` WITHOUT a request token fills the fields and nothing
  else (it used to 404); with a token it is still the read-only retry of a lost acknowledgement.
  The card and the box share the Procedure page, so the box takes a `key` from the suggestion —
  a mounted client form keeps its state and its request token until a full navigation, and a
  link on the same page would otherwise change the URL and nothing else.
- **The Review step says "once this version is Active", not "after approval".** A
  configuration-changing revision is APPROVED pending a Regression Run, and Initiate Run
  selects the ACTIVE owner, so "after approval" would send an auditor to run the
  predecessor. Codex again; the sentence now names the card that offers the Run.
- **`immutable-versions.spec.ts` pins "No automatic Schedule boundary" on the once card**, so
  the rewritten sentence keeps that phrase rather than the spec learning new words for the
  same fact. And `getByRole('link')` excludes hidden elements: the guided outline hides
  unselected groups, so the Review-step link is asserted after `openReview`.

## 2026-09-15 — Twenty of twenty Epic 5 review layers, and a fix applied to one of two siblings

The Epic 5 code review had completed ten of its twenty layers before a rate limit stopped it;
the other ten ran now, and the report's whole Medium list — marked `[unverified]` since 2026-09-11
— was read against `main` before anything was fixed. Findings and repairs:
`_bmad-output/implementation-artifacts/review-epic-5-stories.md`.

- **A rule fixed in one sibling and not the other is the defect class this round found most.**
  `OpenEscalationSection` was repaired in Story 5.6 so an unreadable open wait renders a Banner and
  never an absence, with the rule in its own JSDoc; `PauseBanners`, twenty lines below in the same
  file, rendered NOTHING for a `PAUSED` Run whose wait could not be read — and `readOpenEscalation`
  answers all-nulls on an authorization refusal, so that is a state a reader reaches. Same shape
  twice more: the Escalation panel had a countdown and the Paused banner had two timestamps where
  EXPERIENCE.md asks for a countdown in three places; the Escalation note field was gated and the
  flag note was not. **When a review lands a rule on one component, grep for its siblings before
  closing the finding.**
- **A spec can pin the defect as the expected value.** `pause-resume.spec.ts` asserted
  `getByText(author)` where `author` was the auditor's UUID — so "Paused by 019a3c…" was REQUIRED
  by a green test, on the one surface whose job is to name the person accountable, while
  `ActorNameReader` existed for exactly this. `replay.spec.ts` did the same with `Escalation ·
  choose-candidate`, a stored key in a monospace span, the plain-words defect reintroduced on a new
  surface. Both now assert the words. `ESCALATION_KIND_WORDS` joins `plain-words.ts`; the stored
  kind arrives typed `string`, so the lookup is `Object.hasOwn`-guarded (seventh occurrence).
- **`String.prototype.replace` with a STRING pattern expands `$&` in the replacement.** A Procedure
  named `Fee $& review`, or a person named that way, rewrote the sentence around it in two
  templates. `fillTemplate` in `copy.ts` uses a replacer FUNCTION and fills in one pass, so a value
  containing a later placeholder cannot be substituted by the next call either.
- **A refusal must say only what it knows.** `resumeRun`'s `expired` arm said "the Run is
  Inconclusive" — a state the delayed wake writes, reachable before the wake runs, so a reload
  still showed PAUSED and still offered Resume. It says the deadline passed and to reload for the
  recorded outcome. The "second tab is told Inconclusive with somebody else's timestamp" scenario
  the reviewer described is NOT reachable: the guard refuses a closed wait as `not-paused` under
  the row lock before `closeWait` runs. **A finding that describes a path must be checked for
  reachability before its test is written** — the first two tests I wrote modelled the reviewer's
  path and both received `not-paused`.
- **`ConfirmDialog`'s gate guard had no test and refused silently.** It now states the reason
  (`role="alert"`), marks Confirm `aria-disabled`, and re-runs its auto-dismiss when `busy` clears
  — every Run dialog spells `onCancel` as `if (!busy)`, so a gate closing mid-flight dismissed
  nothing. It cannot be a unit test: the dialog portals into a container set in an effect, so under
  `renderToStaticMarkup` it renders nothing. `live-drop.spec.ts` opens the dialog, lets the stream
  go lost, and asserts dismissal and no commit; the mutation that proves it deletes the EFFECT. The
  `handleConfirm` refusal is same-tick defence a browser cannot deterministically reach and is
  stated as such rather than claimed.
- **The inbox bounded its merged list and the bell counted unbounded**, so 100 open Escalations
  hid every flag with nothing saying so. The ordering (Escalations first, because only they expire)
  was right and documented; the silence was the defect. The page now reads the same count the bell
  does and says "Showing the first N of M" when they disagree.
- **Replay said "no frame was captured here" for frames the database holds** past
  `REPLAY_FRAME_LIMIT`, printed `digest: null` under a sentence promising the digest, and matched
  Work Item jumps on nullable `run_tool_action.work_item_id` while the same page resolved the
  system name through the Step Execution. `resolveFrameWorkItems` is the one rule; the adapter
  digest comes from the Evidence read the page already had; a null-frame row says which of
  THREE things is true, decided by the resolver — see the PR 36 note below.
- **`docs/contracts/live-view-v1.md` said three gate reasons and that `runEnded` outranks the
  others; the code has four and `viewport` outranks everything.** A contract the story itself
  rewrote, out of date by the story's second commit. Corrected, with the priority stated.
- **Codex found two things on PR 36, both in code this round wrote, and both the same shape: a
  fix that stopped one line early.** The `matchMedia` guard that replaced a throw RETURNED before
  subscribing on a Safari 13 list (`addListener` only), so a rotation across the 1024px floor
  left the gate at its mount-time verdict; `subscribeViewport` in `live-status.ts` picks the API
  the list has and is unit-tested over all three shapes, because that branch is one no browser
  here can reach. And the Replay null-frame sentence INFERRED "beyond the frames shown" from the
  global frame count — false for a Work Item that captured nothing in a long Run, and for an
  Escalation raised before the first frame, which is decidable under any bound because the read
  holds the EARLIEST frames. The resolver carries the REASON now (`none-captured` /
  `none-before` / `not-read`) as a discriminated union, so a null index with no reason, or a
  reason beside a frame, does not compile; the bounded sentence claims neither that a frame
  exists nor that none was captured. **A sentence derived from a count is a guess wearing the
  count's confidence. Carry the reason from where it is known.**

Four mechanical notes:

- **`replay.spec.ts` seeded a bare `RUNNING` Run with its own worker up, and lost the race it
  had been warned about.** The spec spawns the worker because frame grants are worker-signed;
  the Story 5.3 note says a `RUNNING` Run with no `population_execution` row IS abandoned, and
  every five seconds `startPopulationRecovery` selects exactly that. Its claim landed five
  seconds after the insert, reserved a REQUIRED population artifact it could never acquire,
  and generation 21 then refused the seal with "a required artifact is not REGISTERED" — read
  at first as a defect the new adapter-digest assertion had found; the assertion never ran.
  Three of four tests in the same file passed because the tick fell elsewhere, which is what
  makes this the kind of race that ships. `live-view.spec.ts` already seeds the pair every
  sweep respects (`POPULATION_READY` plus an `EXECUTING` agent phase, both with live leases);
  the replay fixture does too now, in ONE transaction with the Run row, and its teardown
  deletes the population rows a lost race leaves so one failure cannot take the rest of the
  file's cleanup with it. **A spec that spawns the real worker copies the sibling's held-Run
  checkpoints, not only its columns.** PR #37 landed this same repair on `main` first, and
  added the rule for the one place this fixture REOPENS the Run: the live-state test sets
  `RUNNING` again on a Run whose agent phase is already `TERMINAL`, which is exactly the row
  the adapter sweep selects, so the held claim is reopened in the same transaction and
  closed again after — see "2026-09-15 — Replay fixtures with a running worker" at the end
  of this file.
- `[FIXED 2026-09-26 — see the Story 10.8 note at the top: a re-run and a remount no longer
  reset the clock; "no apps/web edit during a browser run" still stands]` **Editing a file Next
  watches while a Playwright test is inside its silence window remounts the
  page.** `useLiveTimeline` resets `lastMessageAt` on every effect run (line 72), so Fast Refresh
  made the status cycle `connecting → stale → connecting` and never reach `lost`. The failure
  read as the 5.7 edge finding about reconnects resetting the clock; it was my edit. Same run,
  untouched tree: green. **No `apps/web` edit during a browser run, and read the log before
  believing a status that will not settle.**
- **Parallel Bash calls share one shell, and `cd` in one wins the race in the other.** A read spelled
  `cd /repo && sed apps/web/...` failed with "No such file" because a sibling call had `cd
  packages/application` first. Absolute paths for every file and every `-p` config in a parallel
  batch; never rely on cwd there.
- **`seed-identity` needs `--name`, and never resets a password**, so an account seeded by an
  earlier session cannot be signed into with a new `E2E_PASSWORD`. Seed fresh addresses. A cluster
  whose password nobody has is reset through a temporary `local … trust` line in `pg_hba.conf`,
  restored to `scram-sha-256` in the same script: `migrate.test.ts` proves a driver error with a
  wrong password, and trust auth would accept it.

## 2026-09-13 — Explicit chat commands use existing preparation writers

The owner now authorises “record that”, named selection, section review and navigation
through chat. This supersedes the earlier rule that every reply only requests prose.
Only a direct human composer message enters the full-message command resolver; model
output and stored/source text cannot dispatch actions. Exact proposal acceptance uses
the same reserved receipt and human writer as the button. Bare assent, negations,
conditions, incomplete responses and ambiguous catalogue names are never consent.
Selection retains filters and existing targets; target additions retain their scope
confirmation. A saved-result message follows the writer acknowledgement, and unknown
outcomes retain the existing reconciliation guard. No new provider tool, model setting,
approval shortcut or Run path is introduced. See `conversational-preparation-actions.md`.

## 2026-09-11 — The complete plan opens in Review

## Guided dialogue correction (2026-09-11)

The owner's chat correction (2026-09-12) requires a scrolling message thread, a bottom composer and actual provider streaming. Display-only `AuthoringProgress` cannot enter acceptance; only a validated completed receipt can. The custom JSON POST route checks Origin against configured auth origin (never Host), authenticates before reading bounded input, and invokes the existing reserved-request use case. Disconnect stops delivery while bounded provider work finishes its receipt; retry the identical request. Keep the SDK Responses SSE fixture explicit, test incomplete output before completion, and never describe it as live-model evidence. See the chat addendum in the dialogue correction report.

AI SDK structured output validates JSON shape without requiring successful provider completion. The authoring adapter must also require `finishReason === 'stop'`: fixtures with valid JSON followed by EOF, `response.failed`, or a token cutoff otherwise resolve as proposals. Streamed tokens remain display-only until both completion and final validation pass. Reject foreign Origin before authorization can append a denial audit event; filter configured credential references in completed output as well as partials, and hold unfinished trailing tokens until they can be checked.

Confirm saved Template facts before opening a manual editor. Guide scope and evidence through focused questions while keeping each existing editor mounted once, with its save/conflict guard. A visible conversation carries the original answer, full working proposal and precise corrections; a reply never accepts or reviews content. New guided-dialogue-v3 provider responses ask one focused question; receipt parsing still accepts v1/v2 unchanged. Browser editor helpers may open named manual disclosures, but the default journey must test their actual closed state and navigate without unhide scripts. See `_bmad-output/implementation-artifacts/guided-dialogue-correction.md`.

The complete fresh-Template browser journey seeds only catalogue entries, then uses the real creation/forms/authoring actions through stored compiled-plan review. The owner journey has a real background worker: wait for the current preview attempt and the current Server Action response before asserting a save. A retained banner from an earlier section cannot acknowledge the next command. Keep intentional stale-row races in their dedicated concurrency tests.

Expanded registration disclosures need secondary-text definition labels: muted text on their sunken surface fails WCAG AA contrast. Exercise both closed guidance and expanded manual details. Header assertions must identify the page's level-one heading because the guide also names the selected control. In the legacy `procedures.spec.ts`, a failing test restarts the worker and its timestamp namespace; missing later cards can therefore cascade from an earlier assertion, rather than indicate lost product data.


The corrected Builder keeps the executable plan out of preparation panels and opens it in Review and submission. The hero browser journey must check that distinction plus manual collapse/reopen; its old collapsed-by-default assertion belongs to the superseded layout. Include the hero journey in the focused CI step so a review-surface change is checked before the full browser suite.

## 2026-09-11 — Closing Help releases the preparation column

Inspect actual browser captures: a closed disclosure still occupies a grid column unless the layout changes. Closed Help now gives that space to the working proposal and comparison. Its opener precedes the editor in DOM order; smaller screens stack the same controls. The browser journey checks that opening/closing Help changes the working width without losing draft state.

## 2026-09-11 — Preserve intent through failed revision attempts

A failed follow-up retains its original ready parent and the full edited proposal for a new attempt; do not accidentally fall back to rough notes alone. Explicit Help Me Write buttons claim focus once for their section's central assistant. Automatic section entry creates no focus request and no provider call.

## 2026-09-11 — Protect authoring receipts before persistence

The OpenAI adapter checks its configured key synchronously before the application persists revision content, then checks again before the provider call. Pattern-only credential checks cannot identify opaque configured values. Audit events retain the parent request ID for revision provenance, never the feedback or proposal body; the original notes travel with each request without a duplicate in receipt history.

## 2026-09-11 — Central preparation assistance

Open local assistant sessions on entering Scope or Audit steps without a paid request. Keep all manual editor panels mounted and preserve per-target conversation state. Generation uses saved context even while a manual editor is dirty; acceptance still uses the full submission guard. Test follow-up conversations under separate synthetic identities so earlier cases do not exhaust the real per-user rate budget.

## 2026-09-11 — Intent-driven authoring revisions

A follow-up carries the full human-edited proposal plus a same-author, same-section receipt reference. Resolve up to four prior turns inside the authorised transaction; stale/foreign/expired proposals cannot anchor a revision. Keep feedback out of immutable audit payloads. The bounded receipt may retain it; no credentials or source locations reach the provider. Parse legacy guided-prose-v1 receipts alongside guided-test-design-v2 without rewriting history. Test instructions refine registered read/inspection work; structured criteria and the compiler remain authoritative.

## 2026-09-11 — Synthetic ITGC Template context

The owner-supplied ACCA `IT General Controls.pdf` informs synthetic PoC controls in addendum §C. It is educational background, never Northstar policy or an invented criterion reference. P-2/P-4 now seed control statements; their execution contracts and historical versions are unchanged. The owner refinement is recorded in `guided-authoring-experience-correction.md`: select established controls and evidence, then guide and revise test design.

## Guided preparation state (2026-09-11)

Story 2.9 stores nullable `section_preparation` metadata separately from compiler inputs.
Only an explicit authorised acknowledgement creates Reviewed by auditor. Every content
save uses `queuePlanDerivation`, which advances authoring revision and invalidates review
against an explicit conservative section dependency projection. Plan-worker changes do
not invalidate review; content reversals cannot revive it. New versions reset reviews.
Historical NULL metadata stays unknown. Six section reviews guide preparation; full-version
submission remains auditor assent and retains all existing readiness gates. Explicit
Needs clarification blocks submission. Guided preparation supersedes only the Builder's
old 900px authoring floor. Narrow editor-contract browser tests expose all mounted panels;
the guided and owner journeys retain real navigation and accessibility checks.

## 2026-09-11 — Structured Template context preserves historical definitions

Story 2.15 appends Risk and Criterion reference to new section arrays while keeping the
original nine identifiers and order. Read exact legacy nine-section payloads without
upcasting their frozen content. An explicit context save promotes only a Draft, taking
unspecified values as null rather than consulting a newer Template. A successor copied
from a historical approved version keeps that historical content until explicitly edited.
Manager reviews use 14 rows for current inputs and retain the historical 12-row shape;
both the domain consistency check and repository parser must accept the appropriate shape.
Context edits use the same locked, revision-checked human authoring and plan-queue path.

## 2026-09-15 — A literal in the declared shape can undo a live setting that cannot be redone

`SOLARI_API_KEY` sat as a **STAGED** Railway change for two days, so the worker kept booting
in `local` mode while the key was, by every ordinary reading, "added". Railway holds a
variable edit in a pending patch until somebody deploys it; `list-variables` shows the LIVE
set and says nothing about what is staged. **Read `get-staged-changes` before concluding a
Railway variable is missing**, and before concluding one is present.

- **The key lives in two unrelated places and only one of them was set.** A GitHub Actions
  secret feeds `solari-acceptance.yml`; a Railway worker variable feeds the worker that runs
  real audits. The acceptance workflow had passed fourteen times, which is why it read as
  configured. Neither place implies the other.
- **`SOLARI_RECORDING` must stay OFF, and the first version of this note argued the opposite
  from a wrong premise.** It said a Run made without it "would have had no replay,
  permanently", which reads as though Replay depends on it. It does not: `replay-v1.md` says
  Replay is whole from the platform-owned asset set, and **nothing in this build reads a
  provider recording at all** — a supplementary link to one is a later story's. So the only
  thing turning it on buys today is an artifact no surface opens. **A provider recording is
  not Replay, and a note that conflates them turns a metered extra into a necessity.**
- **What it costs is an audit credential on a third party's servers, permanently.** Solari
  records input values BY DEFAULT — the repo's own verified vendor review says so, citing
  the provider's recording docs — the sign-in TYPES the credential into a form field
  (`enterCredential` → `field.fill`), and `copyRecording` only DOWNLOADS what the provider
  already holds: its scanner refuses the PLATFORM upload and cannot reach the provider's
  copy. The SDK exposes no masking and no retention control. So every recorded sign-in puts
  a working credential somewhere this platform cannot reach, for an unknown period. The whole
  credential-containment contract is "the value has nowhere to land"; this hands it a
  landing place outside the system. **Found by the Codex review on PR 35, after this session
  had recommended the change and the owner had deployed it** — the reasoning was checked
  against `browser-execution.ts`, `copy-recording.ts` and both contracts before it was
  accepted, and every leg held.
- **So the declaration is a literal `'false'`, and `preserve()` would be wrong.** `preserve()`
  would let a dashboard `true` survive an apply, and fail-closed is the direction this value
  needs until provider input masking and minimum retention are verified against the account.
  The general rule still stands and simply points the other way once the cost is read
  correctly: **a declared default whose cost is irreversible must agree with the live state**,
  and here the irreversible cost is on the ON side. For anything else, `preserve()` is what
  "the dashboard owns this" looks like.
- **The worker named its mode and said nothing about recording, so the deploy could not be
  checked.** `Agent Workspace mode selected` logged `mode` and `reason`; whether these Runs
  are being recorded by the provider — which decides whether a credential is leaving the
  platform — was in no stream at all, and the Railway API redacts variable values over an
  OAuth connection. It logs `recording` beside `mode` now, `false` for the local mode
  because a local browser really does record nothing. The allowlist's own note on `mode`
  already gave the reason ("the two modes are not the same guarantee"); recording is the
  stronger case, because a session already created with it on cannot be un-recorded. The
  regression test asserts a **`false`** survives sanitization: a sanitizer filtering on
  truthiness rather than on the key would keep `mode` and lose exactly this, and a dropped
  key is dropped SILENTLY.
- **`accept-deploy` timed out at 60 seconds, twice, and committed nothing either time.** A
  timeout is not an outcome: `get-staged-changes` still read `STAGED` with the same
  `updatedAt`, and the worker's latest deployment was unmoved. Check the patch and the
  deployment after any deploy call that does not return, and stop after two attempts rather
  than hammering a production commit — the same rule as reading a background wrapper's exit
  code instead of its log.

## 2026-09-11 — Guided preparation comes into v1, and ten of its rules are already the product

The owner reviewed LivePlan's documentation and adopted the pattern for the authoring surface —
*guide the auditor through the assignment, turn their inputs into a clear procedure, obtain their
approval, then obtain independent manager approval before allowing execution.* It is **v1**, as
**Epic 2 extension stories 2.9–2.15**, not v2 and not Epic 5. Whole direction, the reconciliation
and the story breakdown: `_bmad-output/implementation-artifacts/guided-procedure-preparation.md`.
`v2-conversational-authoring.md` is `[SUPERSEDED]` by it and kept for the reasoning.

**The governing document an institution already has IS the Template, and there is no new entity.**
A first version of this note proposed one, and the owner corrected it: every institution tracks
its risks and the controls that mitigate them in some document — the names and formats differ by
institution — and in production a Template would be shaped around whatever that institution uses.
So the work is to make the EXISTING Template more structured, framed around **risk, control,
objective and criterion reference**. `ProcedureTemplate` already carries `objective` for all four
and `controlStatement` for P-1 only; risk and criterion reference are what is missing. **Do not
introduce a separate entity for this, and do not use an institution-specific acronym for it in
code, copy or documents** — the product word is Template.

**Adding a Template field means editing addendum §C FIRST.** Templates are build constants pinned
to §C on disk, and `procedure-templates.test.ts` requires every stored string to appear verbatim
in that Template's block — deliberately, because "a stored default that appears nowhere in the
block could never be pinned". So most of that story is the addendum, and the code follows.
`initialDraftSections` already copies Template text into the version's `sections` at creation and
`sections` is part of `FrozenPlanInputs`, so a Template edited later **cannot** retroactively
change what an approved version says it was testing — risk and criterion ride that mechanism and
need no new freezing rule.

**The governance half was checked against the code and TEN requirements already hold**, several
more strongly than the direction assumed. The proposed chain `Draft → auditor approved / awaiting
manager review → manager approved → Active` IS `DRAFT → SUBMITTED → APPROVED → ACTIVE`, so
**`SUBMITTED` already means "the auditor approved this and sent it for manager review"** and no
new lifecycle state is needed. `authorApprovingOwnVersion` checks `humanAuthorIds` — EVERY human
author, not only the creator — and DENIES when the author is unknown, so "a different person must
approve" is identity-enforced rather than role-enforced. `createRun` refuses any period owner that
is not `ACTIVE` with a frozen review, and manual initiation and rerun share that one function.
**Read the code before scoping a governance ask**: most of this needed writing down, not building.

**The one execution gap is named rather than assumed: scheduled Runs are Epic 8 and do not exist**,
so "every path that can start work re-checks approval" is a rule to pin in Epic 8's spec.

**What else is genuinely new:** AI drafting per section; a section state that separates DRAFTED
from AUDITOR-REVIEWED, because today's `done | todo | attention | reference` cannot say "written
but not yet accepted" — until now a person typed everything and there was nothing to distinguish;
material proposals shown as UNAPPLIED changes carrying a basis; cross-section dependency flagging;
and reference documents (design inputs) kept distinct from Evidence (execution inputs).

**Prose has no compiler, so a rewrite is reviewed rather than checked.** `equivalentExecutablePlan`
can refuse a model answer whose PLAN semantics differ; there is no such test for a sentence. The
mechanism is therefore show-the-diff-and-require-acceptance, and the failure it prevents is
concrete — *"check ALL terminated employees"* becoming *"review a REPRESENTATIVE SAMPLE"* silently
narrows the test. **`scopeWideningWarnings` does not catch that**: it flags widening (a write verb,
an out-of-scope origin, an unregistered system) because until now only a person could narrow scope
and they knew they had. An assistant that rewrites prose makes narrowing reachable.

**The assistance must be ADDITIVE — the forms keep working with no model at all.** That is what
makes it safe in v1: help on top of a surface that already works, never a replacement for one. The
cost to know about is paid model calls on the authoring path, where today the only one is the plan
check, once per save.

## 2026-09-11 — v2 authors by conversation, and three of its four rules already hold

Owner direction, recorded and NOT built: in v2 an auditor builds a Procedure by talking to
the agent one question at a time rather than working down the Builder, the agent then frames
the whole plan, and the auditor confirms the framing is right. Whole shape, the constraints it
inherits and the one open design question:
`_bmad-output/implementation-artifacts/v2-conversational-authoring.md`.

**Checked rather than assumed, because three of the four rules are already the product.**
`PROCEDURE_VERSION_TRANSITIONS` is `DRAFT → SUBMITTED → APPROVED → ACTIVE` with no shortcut;
`procedure.version.approve` is an Audit Manager's alone and is denied to the version's own
author; and `createRun` refuses any period owner that is not `ACTIVE` with a frozen review, so
a Draft, a Submitted, a Rejected or an approved-but-not-activated version cannot be run —
manual initiation and rerun share that one function. So v2 changes HOW A DRAFT IS AUTHORED and
nothing about who approves, what activation means, or what a Run may execute. **Keep it that
cheap.**

**The one thing v2 must decide deliberately: the auditor has ONE act of assent today** —
Submit — and the owner's description has two, "you framed it right" and "send it to a
manager". Whether the first becomes its own recorded act is a question about what an auditor is
attesting to and it changes the immutable chain. It must not be settled inside a story about a
chat surface.

**The agent is a JUNIOR AUDITOR, not a typist, and a first reading of this that said "the
model collects the inputs" was corrected by the owner.** It takes intent rather than dictation,
puts it in its own words, understands why a control is tested this way, confirms before acting,
catches a slip ("you said X, did you mean Y?"), and — told the status is in column C when the
sheet has it in column B — reads the real source, reasons, asks, carries on and reports what it
found. A form with a chat skin on it is not what was asked for.

**What that does NOT change is WHEN the thinking stops being negotiable.** All of it lives
BEFORE the auditor confirms; after the confirmation the artifact is frozen and the compiler
writes the plan. The reason is not distrust of the model — an auditor SIGNS the work, and an
artifact that moved after they approved it makes them attest to something they never decided.
It is also why a correction is PROPOSED and accepted, never applied silently. The checkable
form: throw the conversation away, keep the confirmed inputs, re-run `makePlan`, and the plan
must come back byte for byte. **Epic 4's executing agent already has this posture** — it reasons,
and raises a typed Escalation rather than guessing — so v2 extends a stance the product has
rather than inventing one.

## 2026-09-11 — The plan is the platform's own sentence, and it is laid out to be found

The owner read the Builder's plan fold and asked one question — *"is this agent generated or
its hardcoded?"* — then said the presentation was still poor. The first has a short answer and
the second was a real defect.

- **Every word on that surface is the PLATFORM's, built from the auditor's own fields.**
  `makePlan` in `packages/domain/src/procedures/executable-plan.ts` writes each step's sentence
  from a fixed template with names, ids, dates and lists slotted in; `ACTION_LABELS` supplies
  the titles. The model IS called when a version freezes one, and its only power is to AGREE:
  `derive-plan.ts` stores `result.plan` — the compiler's bytes — and refuses the attempt when
  `equivalentExecutablePlan` says the candidate's semantics differ. The agent that will RUN the
  Procedure has not started; it READS this. Worth restating here because the surface itself
  never said so, and now its first line does.
- **The two components are one treatment at two altitudes, not two documents.** `AgentSummary`
  is the decision ("how many systems, how many steps, what is captured, when does it stop") and
  `ExecutablePlanPreview` is the contract. They now share `.ls-plan-groups`, `.ls-plan-steps`,
  `.ls-plan-facts`, `.ls-plan-panel` and `.ls-tag`, so a reader who learns one can read the
  other.
- **A Session Step happens ONCE and a plan step happens PER RECORD**, and the old summary said
  that in a prose sentence after an undifferentiated list. They are two labelled groups now.
  An auditor who cannot tell those apart cannot judge what a Run costs.
- **`plan-numbers.ts` says a frozen number the way a person reads it and never a different
  one.** `10000` → `10,000`, `3600` → `1 hour`. Grouping and unit words only: `durationWords`
  is tested at 3599 precisely because "59 minutes 59 seconds" must not round to an hour. The
  read-only contract preview prints the exact digits BESIDE the words, because that surface's
  job is to be checked rather than skimmed.
- **A label that is a NAME is not upper-cased.** `.ls-plan-facts--names` exists because the
  overline treatment would print `MAX_MANUAL_APPROVAL_AMOUNT` for a field the plan holds as
  `max_manual_approval_amount` — a value the plan does not contain, rendered as though it did.
- **The `AgentSummary` limits test now asserts the FORMATTED value and that a different plan
  says different numbers.** Importing the component's own formatter would have compared it with
  a copy of itself, so the test formats independently with `toLocaleString('en-US')`.

Three mechanical notes:

- **A grid row with three children and two columns puts the third in column ONE**, and an
  `auto` first column then sizes itself to that child. The step's long canonical text became
  the marker column and pushed every step title into a narrow strip on the right. It is
  `grid-column: 2` on the text, with `row-gap: 0`, so the marker column stays the width of the
  marker. Caught by looking at the rendered page, not by any test.
- **`plan.limits.retriesPerStep` is typed `3`, so `=== 1` does not compile.** The pluralisation
  reads the value through a `number` binding — which is also what keeps the sentence right if a
  later compiler version freezes a different bound.
- **`renderToStaticMarkup` plus the two real stylesheets is a one-second visual check.** A
  throwaway `*.test.ts` under `apps/web/src/procedures/` writes the page to the scratchpad and
  Chromium screenshots it, with no database, no server and no seed. Delete it in the same
  command that runs it; a preview generator left behind is a test that asserts nothing. Wrap
  it in the REAL surrounding markup — the fold's `.ls-card` + `.ls-disclosure` — or the check
  answers a question about a page nobody sees: the first screenshot showed white cards that
  are transparent in the place they actually appear.
- **`require-role.test.ts` had the module-warm-up gap its two siblings had already closed.**
  Only the FIRST `await import('./require-role')` pays the transform of this workspace's
  graph, and on a machine also running a browser suite that alone outran the 5-second case
  timeout — reported as a failed assertion about sessions. It has `session-route.test.ts`'s
  `beforeAll(..., 60_000)` now. Found by breaking the OTHER standing rule (two suites at once
  against one machine), which is the trap that keeps producing failures that are not
  product defects.

## 2026-09-11 — Four review findings, and three tests that could not fail

The Epic 5 code review (`_bmad-output/implementation-artifacts/review-epic-5-stories.md`)
named four High findings. All four are fixed, each with a test proven by MUTATION — run
against the code with the fix removed, and required to fail. Three of the four were tests
that could not fail for the reason they existed, which is the shape this file keeps finding.

- **The one mid-item boundary that passed no in-flight pair.**
  `execute-agent-work-item.ts`'s `lifecycleBoundary()` inside `finishObservation` was called
  bare, although `item` and `execution` were both in scope and its four siblings pass them.
  `lifecycleBoundary` guards its whole supersede-and-give-back arm behind
  `if (inFlight !== undefined)`, so a pause honoured there left the Step Execution `RUNNING`
  for ever — the state `run-pause-v1.md` says must never exist, because it makes an
  interrupted attempt indistinguishable from a live one — never gave the attempt back, never
  wrote `superseded_by`, and opened a pause wait naming no Step Execution to resume into.
  **An optional parameter that changes what a function DOES is a parameter a call site can
  forget**; the four that remembered are why this one looked normal.
- **A pause is not a lost commit, and `retry` is the difference.** `finishObservation`
  returned `'lost'` for both, and every caller maps `'lost'` to
  `{ retry: checkpoint.status === 'RETRY' }` — while the pause path writes `RETRY` for the
  RECOVERY SWEEP, not for the queue. So a pause asked for a redelivery of a Run the claim
  refuses (`run.state !== 'RUNNING'` → `null` → `{ retry: false }`), after `handle` had
  already provisioned and released a browser session for it. `'stopped'` is its own return
  value now, and the five call sites map it to `{ retry: false }` as the other four
  boundaries already did.
- **`RunFlagControl` never withdrew on a lost response**, unlike `RunCancelControl`
  extracted in the same change, and a flag carries no request token — so a retry writes a
  second `run_flag` and a second fan-out to every Audit Manager. `RUN_LOST_RESPONSE` moved
  into `copy.ts`: two components already declared the identical sentence and the fix would
  have made a third.
- **A live region's TEXT is invisible to every SSR test, and that is not a gap in one test.**
  `apps/web/src` renders with `renderToStaticMarkup` under `environment: 'node'`, so no
  effect runs; the Escalation panel's polite region is therefore always `''` there, and the
  one test naming the milestone sentences asserts their ABSENCE. Emptying the region
  entirely, and freezing it at its first rung, each left 1073/1073 passing. It is asserted
  in the BROWSER now, at two rungs — and the second rung needs a real deadline, so the
  near-expiry Escalation is OPENED with the clock set back (a wait's deadline is immutable
  since generation 34). Any state a component reaches only through an effect is a state the
  unit suite cannot see; assert it where the DOM is real, or say what the hook answered.
- **`not.toContain('role="timer" aria-live')` is an assertion about React's attribute
  ORDER.** Re-spelling the clock `<p aria-live="polite" aria-atomic="true" role="timer">`
  restored the exact Story 4.8 defect with the suite green — and the companion
  `toContain('aria-live="polite"')` was then satisfied by the clock itself, even with the
  real region deleted. The guard parses the opening tags and asserts on the ELEMENT.
- **`useActionState` returns its INITIAL state under SSR**, so the one render a lost-response
  withdrawal exists for is unreachable without saying what the hook answered. Mock that one
  export with `{ ...actual, useActionState }`; the rest of react stays the real module, so
  `react-dom/server` renders normally.

**`[FIXED 2026-09-26 — see the Story 10.8 note at the top]` A lost Server Action response tells
the auditor "Nothing was changed".** A flag form's action IS the Server Action — which is what makes it the one
control here that works without JavaScript, and what stops the component catching a dropped
RSC response. The error reaches the route boundary, which renders EXPERIENCE.md's own
"Couldn't load this page. Nothing was changed." over a flag that committed and notified. The
sentence is right for a surface that could not be built and wrong for an action whose
acknowledgement was lost; `app/error.tsx` cannot tell them apart. Bounded rather than
dangerous — the boundary takes the submit control with it, which is a stronger withdrawal
than a disabled button — and `flag-run.spec.ts` asserts exactly one `run_flag` row and one
notification after a dropped acknowledgement. The wording is a product decision, so it is
reported rather than edited.

## 2026-09-10 — Two accounts cannot walk the journey, and a suggestion is not a requirement

The owner could not test the product: *"there are procedures that refuse to be created… for
example the SOD procedure… i want to be able to test end to end… create the procedure, have
it approved, run it and what its output"*. Nothing refused creation. Two other things were
true, and the second is why the first read the way it did.

- **`procedure.version.approve` is an Audit Manager's alone AND is denied to the version's
  own author, and the deployment held neither a second auditor nor a manager.** So the
  auditor wrote it and was refused as its author, the administrator was refused by role,
  and the journey stopped one step in at a disabled Approve button whose reason was correct
  and whose remedy did not exist. `seed-demo-accounts.yml` seeds three accounts now.
  **A deployment that is already seeded needs no re-run**: a PoC Administrator can add an
  Audit Manager from Administration → Users, which is the same audited command.
- **No test could notice, and that is the lesson.** Every suite that approves a version
  mints its own `audit-manager` by raw SQL first — `version-review.spec.ts`,
  `immutable-versions.spec.ts`, `runs.spec.ts`, `version-decisions.test.ts` — and the
  browser suite's `ACCOUNTS` fixture holds exactly the two roles it signs in as. A green
  suite says nothing about what a deployed environment CONTAINS.
- **`tests/e2e/owner-walkthrough.spec.ts` is the journey nobody had joined up.**
  `hero-workflow` authors to Submit and stops (no worker); `version-review` drives submit →
  reject → edit → approve; `clean-source` runs a P-2 Procedure from a version it INSERTS.
  Each half was proven and the seam was not. It walks P-2 through the interface end to end
  — create, author four sections, wait for derivation, submit, approve as a manager,
  initiate, read the sealed Result — in about 20 seconds, and it reaches the golden
  Inconclusive on `duplicate-primary-keys`.
- **P-2 was the right Template to walk and P-1 was not**: AccessGate is an API, so the Run
  is the Adapter path and needs no browser, no Solari key and no model at execution time.
- **The Builder named systems the deployment does not have, and said nothing about it.**
  A Template offers its defaults BY NAME and a registration is never minted from one — that
  is correct, scope is the auditor's to declare — but P-1 suggests LedgerDesk, no deployment
  registers a desktop system because this release cannot execute one, and the caption listed
  it beside systems that ARE registered with nothing telling the two apart. `suggestedTargets`
  matches each suggestion against the real registrations and `suggestedTargetNote` says which
  of three things is true. The match is by display name and kind, which is a HEURISTIC, so
  the wording is "no system with this name is set up here" and never "this system does not
  exist".
- **`procedures.spec.ts`'s `getByText('LoanCore (web)')` was ambiguous the moment a
  deployment registers a system called LoanCore** — it also matches the picker's own
  `<option>` — and every seeded environment does. It failed identically with this change
  stashed, which is how it was established as pre-existing rather than a regression. It is
  scoped to the suggestion list now, which is what its own comment says it asserts.

Four mechanical notes:

- **A Draft's first save can be refused for a reason the auditor did not cause.** Creating
  a Procedure queues a derivation whose attempt record lands on the row a second or two
  later, so a save made before the Builder's own poll (first refresh at 1500ms) catches up
  is refused with "That procedure changed since this page was loaded". A person filling
  three fields rarely meets it; a browser filling them in 300ms meets it every time. The
  spec does what the sentence says — reload, redo, save — rather than the product growing a
  special case.
- **The model identity a version freezes comes from the WEB, not the worker.**
  `playwright.config.ts` gives its web server `anthropic` / `synthetic-http-fixture`, so a
  spec that spawns its own worker must hold the SAME identity and the fixture that answers
  for it. A hand-started `next dev` without those variables freezes no model, derivation
  goes deterministic, and `version-review.spec.ts` then fails on a line about the model
  fixture — which reads as a product defect and is a missing environment variable.
- **P-2 names no Schedule, so both of its fields start empty** and the save refuses until
  the start time is filled. P-1 arrives with 00:00 because its Template pins one. That is
  the one step on this Template a person has to discover from an error message.
- **`pkill -f` matched this shell for the third time** (exit 144), and everything after it
  in that command line never ran. Kill by PID.

## 2026-09-10 — Generation 47: a Run that ends withdraws the question it was holding

The first of the two findings the PR 29 round named and did not fix. It is fixed now, and the
reason it was worth a migration is that the row it left behind was BOTH permanently false and
quietly expensive.

**`RUN_CANCEL_TRANSITIONS` gives a `PAUSED` and an `AWAITING_AUDITOR` Run to the COMMAND**, so
cancelling one performed the terminal transition there and then — and left its wait `closed_at`
NULL for ever. Two consequences, and the second is the one that grows: a row asserting that a
question is open about a Run that is over, which nobody can answer and no later write can
correct; and `recoverableWaits` reads open waits in a BOUNDED page, so enough of them starve
the sweep whose whole job is finding waits whose wake was lost.

- **The inbox and the bell were never wrong, which is exactly why this could hide.** Their one
  visibility predicate requires `AWAITING_AUDITOR`, and a cancelled Run is `CANCELED`, so the
  STATE excluded it. Two surfaces looked right while the row underneath them lied.
- **`withdrawn` is its own closure kind, not a `timeout` and not an `answer`.** A timeout says
  a deadline passed and an answer says somebody decided; nobody did either. The question was
  WITHDRAWN because the Run it was about ended.
- **The actor is the SYSTEM (`run-terminal`), never whoever cancelled the Run** — the reading
  `lifecycle.cancellation-superseded` already takes. They asked for the Run to stop;
  withdrawing the question is what the platform did in consequence, and naming them would say
  they answered a question they never saw. Generation 47's CHECK pins the pair, exactly as the
  timeout arm pins `wait-wake`, so `withdrawOpenWait` writes both itself and takes neither as
  a parameter.
- **`audit_run_no_open_wait` is a DEFERRED constraint trigger beside generations 21 and 25**,
  so a path that ends a Run and forgets the wait fails to COMMIT rather than shipping the row.
  Three statements of one rule again: the producer cannot ask, the domain would not honour it,
  the database refuses to hold it.
- **It withdraws at every terminal transition, not on the cancellation path.** `completeRun` is
  where every one already goes, so one check covers both worker stages, the web command and
  whatever a later epic adds. On the ordinary path it finds nothing — a wake closes its own
  wait first — so this is a read that usually returns `null`.
- **`execution.wait-withdrawn` records WHICH question went**, by kind and identity and never
  its text. A wait disappearing silently is the defect shape this codebase keeps finding; the
  Run's cancellation event says the Run stopped, and this says the question stopped with it.
  `execution.` rather than `lifecycle.` because it happened to the WAIT, and
  `EVENT_TYPE_PATTERN` closes the family and not the suffix, so the name needs no migration.

**The round's other named finding was examined and is NOT a defect.** `parsePauseRequest`
takes no expected revision where `parseResumeRequest` does, and the asymmetry is the contract:
a pause RECORDS A MARKER and performs no transition, so AD-16's "at the next Tool Action
boundary, whenever that is" is its whole meaning and the revision the page was rendered at has
no bearing on it — refusing there would refuse a pause for a reason the person asking could not
act on. A resume PERFORMS `PAUSED → RUNNING` and must not run against a state nobody saw, which
is what its revision is for. The staleness that does matter is caught anyway under the pause
command's own row lock (`AWAITING_AUDITOR` by name, anything else by `runPauseTransition`), and
writing the marker bumps the revision through generation 34's trigger under that same lock, so
a worker's compare-and-set serialises rather than races. **It was accepted too readily in the
first round**; the reasoning now sits at the parser and in the contract so the next reader meets
it instead of re-filing it. A finding that reproduces is not the same as a finding that is
right — check what the contract already says before building the change it asks for.

**The backfill is structural and was proven against a database that really had the defect.** A
scratch database was migrated to generation 46 ONLY (a copy of `drizzle/` with 0047 and its
journal entry removed), seeded through the repo's own `activeRunVersion` fixture with a
`CANCELED` Run holding an open pause wait — which 46 permits, because that IS the defect — and
then upgraded with the real migrator. The wait came out `withdrawn`/`run-terminal` at the
Result's own `sealed_at`, and three waits on QUEUED Runs left by earlier failed seed attempts
were untouched, which is the negative control the test did not have to invent. Fresh install,
that upgrade and the working database all end at 539 columns, 769 constraints and 28 triggers.

Three mechanical notes:

- **Making the port REQUIRED is what found every caller.** Ten fake contexts failed to compile,
  each in a file whose Run never opens a wait; an optional seam would have left them silently
  answering `null` for ever. Nine say so in one line, and the four that drive a wait implement
  it.
- **A bounded read over the WHOLE table plus a post-filter is a test that other files can
  break.** `run-surfaces.test.ts`'s `mine()` took one `RUN_LIST_PAGE_SIZE` page of every Run in
  the database and then filtered to its own Procedure, so it passed at 24 rows and failed the
  moment this change added three — and the row it lost was the OLDEST, which reads as a broken
  ORDERING rather than as a full page. It walks the keyset now, which is what a real caller
  does, so the assertion is unchanged and no longer hostage to the other 43 files.
- **Read the FIRST failure, and clean the database before trusting the second run.** Both
  failures in that run were the one cause, and 24 leftover Runs from earlier failed runs in the
  same session were most of the page. `TRUNCATE TABLE audit_run CASCADE` is the way to clear
  the Run tree in a test database: row triggers do not fire, so the immutability guards that
  correctly refuse a piecemeal `DELETE` are not in the way.

## 2026-09-10 — PR 29 review findings: one rule with three holes, and one limit in four places

Codex reviewed the Epic 5 branch and left ten findings. Every one reproduced. Eight are
fixed here; two are named at the bottom because each needs a change wider than the finding
and neither belongs in a pull request that is otherwise ready.

**Three findings were one rule with three holes.** Story 5.7's gate withdrew the controls
that ASKED it — and the Escalation panel did not ask, a `ConfirmDialog` already open never
re-asked, and the sub-1024px rule only showed a sentence. So the gate moved DOWN, into
`ConfirmDialog` itself: every confirmation in the product goes through it, so a dialog now
dismisses itself and refuses its confirm when the gate closes, once, rather than in each
control that remembers to check. Outside a gated surface the gate is open, so administration
and authoring are untouched.

- **The viewport gate defaults to DESKTOP where none can be observed, and that is not the
  fail-safe direction — it is the correct one.** Withdrawing on the server would disable
  **Flag** permanently for a reader with no JavaScript, and Flag is the ONE control here
  designed to work without it (`flag-run.spec.ts` proves that with `javaScriptEnabled:
  false`). Closing a gate on a viewport nobody has measured breaks a guarantee that is real
  to close a hole that is not. A unit test caught the first attempt.

**A timed-out pause recorded an Escalation.** `wakeEscalation` hard-coded the event type,
the actor and `priorState: 'AWAITING_AUDITOR'` — so every pause that ran out its thirty
minutes wrote, into a row that can never be corrected, that an Escalation timed out from a
state the Run was never in. All three are DERIVED from the wait's own kind now, through the
same `waitRunState` the command, the insert, the closure and the recovery read already call.
`execution.pause-timeout` needs no migration: `EVENT_TYPE_PATTERN` closes the FAMILY and not
the suffix. It also keeps the bell right by construction — `BellLive` re-reads on
`execution.escalation-`, and a pause is not in the inbox.

**One limit in four places.** Replay renders up to `REPLAY_FRAME_LIMIT` frames and then
joins each one against the Tool Actions, the Step Executions, the waits, the Exceptions and
the Observation deltas — every one of which capped at `Math.min(limit, RUN_DETAIL_PAGE_SIZE)`,
so a caller could only ever NARROW. Past the fiftieth: `No Tool Action` over an action the
database held, jump targets missing with nothing saying so, and the Observation count frozen
at the fiftieth delta. `REPLAY_PAGE_SIZE` is the ceiling for exactly those reads and equals
the frame limit, because one lookup per rendered frame is the cardinality it must cover; the
defaults stay `RUN_DETAIL_PAGE_SIZE`, so Run Detail is unchanged. **Second appearance of
"a limit belongs to the cardinality of the READ, not to the table it starts from"** — the
PR 23 second pass wrote that rule about `readGateObservations`, in this same file.

**The inbox applied its limit twice and added the results.** `openFor(session, 100)` bounded
the wait query and the flag query independently and concatenated them, so it could return
200 — and `openFor(session, 1)` could return 2. One limit over the MERGED list, after a
deterministic order across both kinds.

Three mechanical lessons, and the first is the one that cost the most:

- `[SUPERSEDED 2026-09-26 — see the Story 10.8 note at the top: `lastSeqRef` is now
  `LiveStreamState.lastSeq`, seeded at mount and by `beginLiveSubscription`; the behaviour
  explained here is unchanged]` **A test whose fixture the server never sees cannot assert what
  the server does.**
  `live-drop.spec.ts` intercepted the events route with SYNTHETIC sequences and asserted the
  page resumed at them. CI failed it twice and this machine passed it every time. The second
  CI failure said why in one line — ten reconnects, every cursor `0`, never `42` — and the
  reason is not a race: `router.refresh()` re-reads a server cursor that never advances past
  the seeded head, `useLiveTimeline` seeds `lastSeqRef` from that cursor and re-runs on
  `[url, cursor]`, so a remount re-subscribes at the SERVER's number. Correct in production,
  where every frame the client holds came FROM the chain and the server is therefore never
  behind it; unobservable in a test whose frames did not. **The first diagnosis here was
  "a race", and it was wrong** — the fix that followed it made the assertion clearer, which
  is how the second CI run could say so plainly. Read the second failure too, and when a
  spec passes locally and fails in CI, suspect the FIXTURE's relationship to the server
  before suspecting the clock.
- **A test's NAME is a claim, and a name that promises more than the test can establish is
  the same defect as a label stating something untrue.** Renamed to what it proves; the
  resume rule itself stays proven deterministically in `live-status.test.ts`, which is why
  AD-17's comparison was put there rather than in a browser. **Second appearance, in the same
  round**: `live-view.spec.ts`'s "renders read-only below 1024px" asserted a SENTENCE and
  nothing else, which is exactly why the finding above it — that the narrow viewport
  withdrew nothing — could exist under a green test named for the rule it was not checking.
  It now asserts all three controls `aria-disabled` below the floor and live above it, and
  a `setDesktop(true)` mutation kills it.
- **A gate reason that reuses a contract sentence makes a text locator ambiguous, and
  hydration decides whether the test sees it.** `LIVE_GATE_REASONS.viewport` IS
  `LIVE_VIEW_DESKTOP_ONLY_SENTENCE` — deliberately, so a reader on a phone meets one
  sentence and it is EXPERIENCE.md's own — so below the floor it is the stage's `<p>` AND
  each withdrawn control's reason: four nodes, and `getByText` refuses that in strict mode.
  The reasons are attached only after hydration measures the viewport, so a machine that
  asserts before hydration sees ONE node and passes. That is the whole of "passes locally,
  fails in CI" here, and it is the same fixture-versus-server shape as `live-drop`, one
  layer along. Locate such an element by what the STYLESHEET acts on and pin its wording
  with `toHaveText`; `live-drop.spec.ts` had already reached for `.first()` on its own
  reasons for the same reason.
- **Copy the working sibling, third time in one session.** Three rounds went on
  `run_step_execution.action`, `run_tool_action`'s real column set and a teardown that
  deletes Tool Actions before the Step Executions they name — each already written correctly
  in `agent-execution.test.ts` or a few lines up in the same file. Every refusal was a
  constraint doing its job.

**`[NOT FIXED, NAMED]` Two findings are real and deliberately not in this PR.** A `PAUSED`
Run that is cancelled leaves its pause wait `closed_at` NULL for ever, and that row then
sits in `recoverableWaits`' bounded page permanently — but generation 45's `run_wait_closure`
says a pause closes by `resume` or `timeout`, and a cancellation is neither, so the honest
fix is a **new closure kind and therefore generation 47**. And `parsePauseRequest` takes
`{runId}` alone while `parseResumeRequest` takes the revision, so a stale Live View can pause
a Run the worker has advanced — but `RunRecord` carries no `revision` to compare against, so
the fix touches every reader of that record. Both are on PR 29 with the patch each needs.

## 2026-09-10 — Replay reaches nothing, and a jump that lands nowhere says so

Story 5.8, the last of Epic 5. `/runs/<id>/replay` replays any terminal Run from the assets
Story 5.2 froze, with the Workspace Provider unreachable. Whole rule:
`docs/contracts/replay-v1.md`. No migration — every row it reads already existed.

- **"It reaches nothing outside this platform" is a property of what the path can reach.**
  Every prop is a row PostgreSQL holds, every frame comes through the Run's own protected
  route (a worker-signed grant consumed on the server), and `replay.ts` takes rows and
  returns indices. `tests/e2e/replay.spec.ts` makes it literal: every destination but the
  application's own origin is ABORTED at the network and COUNTED, and the surface must
  render whole with the count at zero. A later change that reached for a provider fails
  there rather than in a deployment whose provider happened to answer.
- **Nothing is re-executed, for the same reason.** There is no action, no command and no
  port on this path. A Replay that could re-run a Tool Action could change what it shows.
- **Where a jump lands is the one thing a reader cannot check.** A Work Item opens at its
  FIRST frame (jumping to it means starting at it); an Exception at the first frame of the
  Work Item it was raised against; an Escalation at the LAST frame captured at or BEFORE it
  was raised — a frame after it belongs to whatever happened next, and jumping there shows
  a screen the question was not about. A target with no frame is listed and SAYS SO: a pill
  that opens nothing looks exactly like one that opens the right screen. A PAUSE is not a
  jump target; EXPERIENCE.md names three kinds and a pause asks nothing.
- **`SessionChrome` and `SessionStage` were EXTRACTED from `LiveViewer`, not copied.**
  UX-DR24's "one session viewer for Live View and Replay" is met by sharing the parts that
  are literally the same markup; two copies would have diverged first on a Replay whose dot
  said one thing and whose word said another. `readFrames` is `readLatestFrame`'s join with
  its order reversed, so Live View's newest frame and Replay's last are the same row by
  construction.
- **Space belongs to whatever has focus.** Pills and jump rows are real `<button>`s, so the
  browser already activates them on Space and Enter; the viewer takes Space only when the
  viewer ITSELF has focus. Otherwise one keystroke would jump AND toggle playback.
- **It starts paused at the first frame (UX-DR26), and playing STOPS at the last.** A loop
  would make a finished session look like one still going. SSR is exactly that state, so
  `ReplayViewer.test.ts` asserts the contract rather than a convenience.
- **`REPLAY_FRAME_LIMIT` is 500 and says when it binds.** A scrubber over fifty pills is a
  scrubber over a fraction of the session, which misrepresents where a Step sits in it.
- **`session-viewer.scrubber-pill-height` came out of `tokens.test.ts`'s DEFERRED list**, a
  token deferred since Story 1.4 because Live View watches and does not scrub.

Three mechanical lessons:

- **The `aria-label` scanner is role-aware now, and it needed to be.** `<div role="group"
  aria-label>` is a labelled group and valid ARIA; the guard refused it because it read the
  TAG and not the role. Widening it exposed the older bug underneath: `[^>]*` ends an
  opening tag at the `>` of `onClick={() => …}`, so an attribute after a handler was never
  seen and the rest of the file was read as markup. It parses tags brace- and quote-aware
  now — and **it has its own tests**, including the two spellings it must keep failing on,
  because `form-method.test.ts` shipped asserting `/\bmethod=/` and passed `method="get"`.
- **A seed that fails halfway leaves rows its own teardown must still be able to remove,
  and a teardown that THROWS takes the rest of the file's cleanup with it.** Three rounds of
  fixing this fixture left three Procedures and three `AWAITING_AUDITOR` Runs behind,
  because `afterAll` hit `notification`'s foreign key to `run_wait` before reaching the
  Procedure delete — and `procedures.spec.ts`'s empty-list test then failed for a reason
  that was not its own. Read the FIRST failure, and clean the database before trusting the
  second run.
- **Copy the working sibling rather than guessing a fixture column by column.** Six rounds
  went on `run_workspace.released_at`, `run_session_step_acquired`, the Work Item state
  vocabulary, `run_work_item_run_step`'s subject key, `run_observation`'s real column set
  and `run_exception.fingerprint_key_id` — every one of which was already written correctly
  in `run-surfaces.spec.ts` or `live-view.spec.ts`. Each refusal was a constraint doing its
  job, which is the good news; reading the sibling first would have cost one round.

## 2026-09-10 — A clock is not a milestone, and an unreadable wait is not an absence

Story 5.6. The Escalation panel is answered on Live View without leaving it, which is the
last of the four session-viewer controls. Whole rule: `docs/contracts/live-view-v1.md`,
section "The Escalation, answered in place". No migration.

- **`OpenEscalationSection` is ONE mount and both surfaces use it**, the
  `RunPauseControls` / `RunCancelControl` discipline. Its branch table is the rule: the
  panel when the wait and revision read, a BANNER when either does not, nothing in a state
  that holds no question. **An open wait that cannot be read is never rendered as an
  absence** — `AWAITING_AUDITOR` means the Run is holding on a question, and showing
  nothing tells a reader it is simply busy. A pause reaches neither arm, because
  `readOpenEscalation` narrows at the READ.
- **The panel sits ABOVE the session viewer and is not a dialog.** EXPERIENCE.md's Live
  View / Awaiting Auditor row keeps the workspace screen visible; a modal over the viewer
  would answer a question about the screen by hiding the screen. Focus is NOT moved: the
  normative mechanism in UX-DR27 is a skip link plus a polite announcement, and "panel
  focused" in that row is the surface's emphasis. The panel appears while somebody is
  watching a Run rather than in response to anything they did, so taking focus would be an
  unrequested context change.
- **A clock in a live region announces itself every second, which is the opposite of a
  milestone.** The countdown carried `role="timer" aria-live="polite" aria-atomic="true"`
  from Story 4.8 — so a screen-reader user heard the time read out once a second for the
  whole wait. It is now `role="timer"` alone (implicit `aria-live="off"`), and one polite
  region beside it climbs `escalationMilestone`'s LADDER: `open` → `ten-minutes` →
  `one-minute` → `expired`. It never climbs back down, so each rung is announced once and
  an expired wait does not go back to saying an Escalation is open. An unreadable deadline
  is `open`, which is what is known — the visible clock says `Unknown` beside it.
- **A live region has to EXIST before it has text.** One that arrives with its text already
  in it is ordinary content as far as a screen reader is concerned and is announced by
  nothing. It renders empty on the server and is filled one tick after mount, which is also
  the moment the panel really did appear. Derived from state, never set from an effect: two
  effects racing to fill one region re-announce whichever wins.
- **The skip link said the wrong thing for two epics.** EXPERIENCE.md's Accessibility rules
  name it `("Go to open Escalation")`; the component said `Skip to open Escalation`, typed
  inline, pinned against nothing. It is in `copy.ts` now and `copy.test.ts` reads the
  artifact off disk — the standing rule, applied where it had not been.

Two mechanical notes, and the first cost a debugging round:

- **`{ ...activeRunVersion(...), controlName }` produces a version that can never own a
  period.** `controlName` is a plan AUTHORING input, so overriding it after the fixture has
  built `frozenReview` leaves the row disagreeing with its own frozen review;
  `findPeriodOwner` refuses such a version, and the surface says **"No executable Active
  version owns that period"** — a sentence about periods, for a defect that has nothing to
  do with periods. Three specs did it and all three passed, because each seeds `audit_run`
  directly and never initiates through the surface; only a journey that clicks Initiate Run
  can see it. All three now pass the name through `executablePlanInputs()`.
- **A journey that initiates a Run must delete its dispatch job before pretending a worker
  holds it.** Nothing here can execute a Run, so a concurrently running worker claims it and
  ends it `RUN_FAILED` for an unconfigured Evidence store — correct behaviour, which would
  destroy the subject under test.

## 2026-09-10 — A control is live only while the page is being told what the Run is doing

Story 5.7. Live View gains ONE gate over the four controls 5.4 and 5.5 put on it, and the
surface gains ONE `EventSource`. Whole rule: `docs/contracts/live-view-v1.md`, section "The
live controls, and the gate over them". No migration: the gate is a client-side verdict over
facts the page already had.

- **One subscription for the surface, because two would be two silence clocks.** The banner
  and every control need the same answer to "is this page still live", and two `EventSource`s
  would be two reconnects and two cursors — which is how a page ends up disagreeing with
  itself. So `LiveGate` subscribes, `LiveBannerView` became the markup it renders and
  `useThrottledRefresh` the throttle it shares, and the controls read the verdict through
  context. A second throttle would have been a second answer to "how often may this page
  re-read".
- **`useLiveGate` returns OPEN with no provider, and that is the TRUTH rather than a
  default.** Run Detail mounts the same `RunPauseControls`, `RunCancelControl` and
  `RunFlagControl` and makes no claim to be live, so it has nothing to withdraw. The gate is
  Live View's because UX-DR25's rule is Live View's — and it is why the three components
  spread `disabledReason` conditionally instead of taking a new required prop.
- **`runEnded` outranks `lost`, and it exists for a second.** It is latched on the first
  `lifecycle.result-sealed` or `lifecycle.run-canceled` and never cleared — a Run that has
  ended does not start again — and what it closes is the window between that event arriving
  and the server re-read that removes the controls entirely. Normally a fraction of a second;
  the browser test HOLDS the re-read to observe it, and holds rather than refuses it, because
  a refused RSC fetch can send the router to a full navigation, which would perform exactly
  the read being held back.
- **`stale` is deliberately NOT a gate reason.** UX-DR25 disables at SIXTY seconds, not
  fifteen. A quiet Run goes stale routinely, and a surface that locked itself every fifteen
  seconds would be unusable exactly when somebody most wants to pause it. `ended` IS one,
  although the contract names only `lost`, because it is the STRONGER case: a lost stream is
  reconnecting and an ended one is not, so gating the recoverable state and not the permanent
  one would have it backwards.
- **The gate is the surface being honest and never the guarantee.** With no JavaScript there
  is no channel to lose and no gate to close; what actually refuses the action is the command,
  which re-reads the Run under its own row lock (and, for Resume, compare-and-sets the
  revision the page was rendered at). A withdrawn control is a person not being invited to do
  something that would be refused.
- **`acceptsLiveSeq(lastSeq, seq)` is `seq > lastSeq`, and that one comparison is both halves
  of AD-17.** No gap, because the cursor is the last frame the page rendered and the route
  replays everything after it; no duplicate, because the frames a resume repeats are at or
  below it. It moved into `live-status.ts` so the property is tested without a browser.

Four mechanical notes:

- **A renamed surface leaves a `getByRole` that resolves to NOTHING, and nothing fails.**
  Story 5.5 renamed the inbox's open section from `Runs waiting for your answer` to `Runs
  that need you` (a flag asks no question) and the plain-words pass replaced the printed
  kind identifier `choose-candidate` with the question it means. `escalations.spec.ts` was
  not re-run by either story, and its region locator then matched no element — so
  `open.locator('li').count()` returned **0**, the expectation it computed became `0
  unread`, and the failure named the BELL. Two rules out of it: the region is named ONCE in
  that file now, and an expectation is never computed from a bare `count()` — both sides are
  re-read together, so a page still refreshing cannot fix the expected value at a number the
  bell has already left. It also asserts `choose-candidate` is NOT rendered, which is the
  plain-words rule stated in the place it was broken.
- **Playwright refuses to click an `aria-disabled` element**, and reports the guard working
  as `element is not enabled` after the full timeout. A test whose subject is that the
  handler refuses activation must click with `{ force: true }`; without it the assertion
  never runs and the failure names the wrong thing.
- **A terminal Run renders no live control at all**, so the `runEnded` sentence is not on the
  page after the re-read lands — every control removes itself on state, which is a STRONGER
  withdrawal than a closed one. Asserting the sentence there was asserting a state the
  product deliberately does not reach; the two facts are two tests.
- **An SSR unit test must not assert a combination the server cannot pass.** `LiveGate.test.ts`
  first rendered `cursor: null` (terminal) beside `flaggable: true`, which no server read
  produces. Its helper takes the same predicate the page does, so the fixture cannot drift
  from what is really rendered.

## 2026-09-10 — The Builder speaks the auditor's language, and asks one question at a time

The owner opened the deployed authoring screens and could not use them: *"im reading this as
an auditor and its giberish...i have no idea what this is, i cant understand a single word of
whats happening here and what im expected to do... so many whistles and bells..should be a few
clicks"*. Two separate defects, both ours and neither in the domain.

**One: the surface printed the platform at the reader.** Every label was the right name for
what the domain freezes and the wrong name for the question in an auditor's head — "Population
Source binding", "Declared-count mechanism", "Comparison type", "Applicability", "Declare
model-read (exempt from deterministic grounding)". The domain keeps its names; the surface
translates, in ONE place.

- **`apps/web/src/design/plain-words.ts` is that place**, and it is a PRESENTATION mapping
  only. `SECTION_WORDS` gives each `DRAFT_SECTION_HEADINGS` entry a title and the question it
  answers; `SOURCE_KIND_WORDS`, `COUNT_MECHANISM_WORDS` and `TARGET_KIND_WORDS` do the same for
  the three closed domain vocabularies; `FROZEN_FIELD_WORDS` covers the frozen contract keys
  the approval diff, the plan preview and the Target System card all print. Every map is typed
  against the domain's own union, so a value added there fails to COMPILE rather than rendering
  its identifier at a person, and `plain-words.test.ts` walks each vocabulary as well.
- **`DRAFT_SECTION_HEADINGS` cannot move and was not moved.** It is the stored `jsonb`
  payload's own key set, validated on read. What a reader sees above one can change; the key
  cannot.
- **The banned words have a test.** `plain-words.test.ts` scans every `.tsx` under
  `apps/web/src/procedures` and `apps/web/src/admin` for twenty phrases and fails on any that
  appears as rendered TEXT. It is deliberately not a scan for identifiers:
  `declaredCountMechanism` is a field name and must keep working; "Declared-count mechanism" on
  a `<label>` is the defect. A phrase flanked by identifier characters is part of a name and is
  left alone.
- **`FILTER_COMPARISONS` is one dropdown where there were two controls.** The domain splits an
  inclusion predicate across `kind` and, for decimals, `operator`, so the Builder asked for a
  "Comparison type" and then a "Decimal operator" — two controls for one thought. The list is
  every reachable combination, and `DECIMAL_OPERATORS` is now a runtime constant in
  `population-draft.ts` with the type derived from it, because the validator and the dropdown
  both have to enumerate them and a second spelling diverges on the first operator nobody tries.

**Two: nine forms open at once is nine questions asked simultaneously.** The Builder rendered
every section expanded, each read-only one repeating the same sentence.

- **A step is a native `<details>` and states what is set in it while closed.** `BuilderStep`
  plus `section-summary.ts`: "Records to test — LoanCore leavers export, testing records
  matching 1 filter". A collapsed step that said nothing would be hiding rather than
  simplifying, so the summary line is tested as hard as the toggle.
- **Whether a step starts open is decided ONCE, and after that the element belongs to the
  reader.** `useRef(initiallyOpen).current`, never state: a controlled `open` slams a section
  shut under somebody reading the banner of the save that just answered it, and — worse —
  closes a step opened before hydration the moment anything else re-renders. Native `<details>`
  also means the disclosure works before React arrives, which is the standing rule.
- **`sectionSummary` marks a step `todo`, `done`, `attention` or `reference`.** `reference` is
  Control and Objective, which nobody has to do; `attention` is set-but-advisory (a source
  whose record count nothing confirms), which is `procedureReadiness`'s distinction and never a
  refusal. Audit Instructions is optional, so an empty one is `done` — marking it `todo` would
  put a permanent red mark on a finished Draft.
- **Readiness came OUT of the fold and the compiled plan went into one.** "Before you run this"
  is what an auditor must meet before spending a Run; `AgentSummary` and
  `ExecutablePlanPreview` are the platform proving what it will execute, which is worth reading
  and is the wrong thing to meet first. `AgentSummary` gained `readiness={false}` for the
  Builder and keeps it on the version review page, which has nowhere else to put it.
- **The two Template sections are read once, together, under the pinned sentence** rather than
  as two cards each repeating it. `BUILDER_SECTION_TEMPLATE_ONLY_SENTENCE` is a contract
  sentence and is unchanged; only how often it is said changed.
- **`RenameDraftForm` stays at the end of the Builder**, because
  `BUILDER_CONTROL_NAME_EDITABLE_SENTENCE` says it is there and that sentence is pinned against
  EXPERIENCE.md on disk. The contract decided the placement, not taste.

Three mechanical notes:

- **Vitest includes `*.test.ts` and NOT `*.test.tsx`.** An SSR component test written as `.tsx`
  is collected by nothing and passes silently — the "a glob that cannot match is a promise of
  coverage that does not exist" trap, from the other side. `BuilderSections.render.test.ts`
  uses `React.createElement` for exactly this reason.
- **The browser specs open the steps rather than asserting through them.** `tests/e2e/builder.ts`
  exports `openStep` for a journey and `keepBuilderStepsOpen` for the five specs whose subject
  is what is INSIDE a step; the disclosure itself is proved by `builder-steps.spec.ts`, which
  runs without the helper and asserts the closed state, the summary line, the click and the
  keyboard. A hundred assertions clicking a disclosure open would test the disclosure a hundred
  times and the editors no better.
- **`Rule text C1` is a bad probe for "is this step open".** The simple editor hides that
  textarea whether the step is open or not, so a visibility assertion on it passes for the
  wrong reason; the step's own Save control is unambiguous.

- **`page.addInitScript` is per PAGE; the helper belongs on the CONTEXT.**
  `version-review.spec.ts` races a Draft against itself in a second tab opened with
  `page.context().newPage()`, and a page-level script never reached it — so that tab met a
  control whose label it could see and could not click.
- **A blanket rename hits surfaces the change was not about.** "Structural Snapshot" became
  plain words on the Builder's grounding CHECKBOX, where somebody chooses it; the Run
  surfaces still call the artifact a Structural Snapshot, which is its name in the Evidence
  contract. A `sed` over the specs rewrote a Run-page heading assertion too, and only
  `disablement-window-journey.spec.ts` could see it.
- **Read the FIRST failure, again.** Two of the four browser runs it took to get here ended
  with six or seven red tests of which ONE was real: a failing test restarts the Playwright
  worker, `afterAll` deletes the Procedures the file created, and every later test then
  fails on an empty list for a reason that is not its own.

**The Administration screens got the same pass**, because that is where a source and a
system are set up before anybody can build a procedure with them. `BindingForm` and
`RegistrationForm` are now one column somebody works down — name it, say how the records
arrive or what kind of system it is, give the address, list the fields, save — with one
short help line per field taken from the option's own `detail`, the rarely-needed fields
under **More options**, and the paragraph that used to sit above the form under a **Why
this matters** disclosure. The list panels read as tables an auditor can scan. Three
consequences worth knowing:

- **"More options" opens when CHANGING and stays closed when ADDING.** Adding is a path to
  follow; changing is a review, and hiding half the configuration from somebody who came to
  check it makes them check less.
- **A digest is a "fingerprint" on every surface that shows one**, with the sentence saying
  what it does beside it (`FINGERPRINT_WORD`, `FINGERPRINT_EXPLANATION`). The save messages
  say it too, and now say the consequence — "Every procedure that uses this needs approving
  again" — rather than printing a hex string and leaving the reader to work out why it
  matters. The SPOKEN form still says "digest", because `digest-text.ts` builds it and that
  module is shared with the Run surfaces.
- **`.ls-disclosure` is the one disclosure treatment.** Two arrived in the same change —
  `.ls-more` in the Builder and `.ls-disclosure` in Administration — which is how a design
  system ends up with two of everything. `.ls-more` was removed the same day it appeared.

## 2026-09-10 — A pause is a wait, and the worker is what performs it

Story 5.4. `run_wait` gains `kind = 'pause'` (generation 45), which is what buys four
mechanisms rather than copies of them: `run_wait_one_open` IS the reason "a Run waiting on
an answer cannot be paused" and a paused Run cannot raise an Escalation; the delayed wake
at `deadline` is what ends an abandoned pause `INCONCLUSIVE`; `audit_run.revision` is what
refuses a resume against a state nobody saw; and `recoverableWaits` is what finds a pause
whose wake was lost. Whole rule: `docs/contracts/run-pause-v1.md`.

- **A pause is a wait and is NOT an Escalation, and every reader says which.** No question,
  no Audit Manager notified. The inbox and the bell exclude it with NO kind filter, because
  their one visibility predicate requires `AWAITING_AUDITOR` and a pause holds the Run in
  `PAUSED` — the state IS the exclusion, which is stronger than a filter to remember.
  `EscalationWait` is a TYPE: the Escalation panel and `answerEscalation` take one, so a
  pause cannot reach either, and `readOpenEscalation` narrows at the READ. `resumeRun`
  refuses an Escalation and `answerEscalation` refuses a pause, and generation 45's
  kind-aware `run_wait_closure` refuses the contradictory row underneath both.
- **`RUN_PAUSE_TRANSITIONS` has ONE row and it says `worker`.** AD-16 makes a pause take
  effect at the next Tool Action boundary, which only a Run a worker is executing has. A
  `PAUSED` written from under a working stage would make its next guarded commit fail,
  silently discarding that unit's Evidence, Observations and Step Execution — so the
  command records a marker and the stage honours it where it already commits, exactly as
  `CancelRun` does for a `RUNNING` Run. **A cancellation wins at every boundary**: ending
  is stronger than holding, and a `PAUSED` Run's cancellation belongs to the COMMAND.
- **The marker means "requested and NOT yet honoured", so it is cleared by the boundary
  that honours it** — not by the resume. That gives it one meaning and two consequences
  free: `CompleteRun` appends `lifecycle.pause-superseded` by simply FINDING one at a
  terminal transition, with no state comparison; and a resume cannot leave a stale marker
  that re-pauses the Run at the very next boundary. Who paused a Run and when is on the
  WAIT row (`opened_by`, `opened_at`), which is what the Paused banner reads.
- **The interrupted attempt is `SUPERSEDED`, and the attempt is GIVEN BACK.** `FAILED`
  would be a lie and `RUNNING` would make it indistinguishable from a live attempt, so the
  state is its own and `superseded_by` is its own column with `diagnostic` left NULL. A
  person pausing is not the agent failing, so it must not spend one of the Work Item's
  bounded retry cycles — eight pauses would otherwise fail the item with a diagnostic
  naming nothing that went wrong. The Run-level `runStepExecutions` limit still counts the
  row, because a Step Execution really did start.
- **This follows epics.md over EXPERIENCE.md, deliberately.** EXPERIENCE.md line 292 says
  "on resume the agent continues from the next Tool Action"; Story 5.4 says the current
  Step Execution restarts from its FIRST Tool Action as a new attempt. The story spec is
  the acceptance criteria and is the safer of the two — a page held for thirty minutes is
  not the page the agent left. **Reported to the owner rather than edited away.**
- **`openPauseWait` is EXTENDED onto the three stage contexts, never injected**, so no
  composition root can move a Run to `PAUSED` and forget the deadline that ends it.
  Population acquisition deliberately has none: a single bounded fetch has no boundary
  inside it, and the request takes effect at the stage after it.

Four mechanical lessons, three of them about tests:

- **A CHECK arm built with `=` is NULL when its column is NULL, and a CHECK that evaluates
  to NULL PASSES.** The new `run_wait_closure` was written with `closure_kind='answer'`
  where generation 34 had `closure_kind IS NOT NULL AND closure_kind='answer'` — so a
  half-closed row made all four arms NULL and was ACCEPTED. `run-waits.test.ts`'s
  partial-closure case caught it. Every comparison in it is `IS [NOT] DISTINCT FROM` now,
  which is never NULL. Fourth appearance of this trap after `array_length`,
  `array_position` and `<@`.
- **An integration file that adds an `audit-manager` changes what a concurrently running
  file sees.** `escalationNotificationRecipients` reads every audit-manager in the
  database, so `run-waits.test.ts` counted three recipients where it expects two. A test
  file that needs a second person uses a second AUDITOR, and an inbox read uses the Run's
  own initiator, who needs no globally visible role.
- **A wait's `deadline` is immutable (generation 34), so an overdue wait is made by opening
  one in the PAST.** Backdating the row raises "Wait identity and question are immutable" —
  which is the guard working, and is also the honest shape: that is a pause somebody left
  an hour ago.
- **`Date` is not a bindable parameter on a client `createDb` has wrapped.** Same family as
  the `sql.json` note: ISO text with an explicit `::timestamptz` is right on both.
- **Regenerating an UNPUSHED migration moves its journal `when`, which makes the migrator
  re-apply it to a database that already has it.** `column ... already exists`, in
  `migrate.test.ts`, which is the guard working: the migrator applies what sorts after the
  last applied `created_at`. Folding a fix into an unreleased generation is right — a 46
  that fixes a 45 nobody ran is worse — but the LOCAL database that applied the old one has
  to be rebuilt afterwards, not patched. CLAUDE.md's "never let a PUSHED migration's `when`
  move" is unchanged and is the case this is not.

## 2026-09-10 — A flag is not a wait, and a notification row is identity only

Story 5.5 puts EXPERIENCE.md's full session-viewer control set on Live View — Pause /
Resume, Cancel, Flag to Audit Manager — and adds the flag. Whole rule:
`docs/contracts/run-flag-v1.md`. Generation 46.

- **`run_flag` is its OWN table, not a `run_wait` of kind `flag`.** Every mechanism
  `run_wait` gives a wait — the one-open unique index, the delayed wake, the revision
  compare-and-set, the recovery sweep — exists to END a Run that is being HELD. A flag
  holds nothing: no state, no deadline, no answer. All four would be machinery with no
  meaning, and `run_wait_one_open` would additionally make flagging a Run mutually
  exclusive with pausing it, which nothing asks for.
- **"A flag has no execution effect" is a property of the CONTEXT, not a rule to
  remember.** `RunFlagContext` deliberately does NOT extend `RunResultContext` the way
  `RunCancellationContext` does, so there is no Run-state writer, no seal and no Result
  seam a later branch could reach. The integration test asserts the WHOLE `audit_run` row
  is unchanged — revision included, because a flag that moved the revision would refuse the
  next resume against a state nobody changed.
- **The note is stored on the Run; only its LENGTH and DIGEST enter the chain.** The chain
  is immutable, so anything that reaches it can never be taken out, and a note is free text
  a person types — the same reason Story 2.3's payloads identify Audit Instructions by
  digest and length. An auditor who pastes a credential into a note has put it in a row
  that can be deleted with its Run. Proven by mutation: putting the note in `noteDigest`
  fails the unit case that scans the serialized payload.
- **A notification row names WHICH flag and nothing else.** No note, and no `flaggedBy` or
  `flaggedAt` either: those are columns on `run_flag`, and copying them onto the
  notification would be two places one fact lives with no way to tell a stale copy from the
  truth. `EscalationNotification` already said it in as many words about the question.
- **`escalationNotificationRecipients` became `runNotificationRecipients`, and the rename
  IS the change.** FR-28 gives ONE recipient rule for both of its triggers — the initiator,
  or the Procedure's author for a scheduled Run, and every Audit Manager — and a shared
  rule whose name claims one of its two callers is one a later reader duplicates rather
  than reuses. The delivery path is shared for the same reason: `recordNotificationDelivery`
  now takes `RunNotification` and uses the row's OWN kind in its `UPDATE` predicate. The
  literal `'escalation'` that was there is the mutation that proves it — restored, the flag
  delivery test fails.
- **A flag needs attention while its Run is ACTIVE, and there is no acknowledge control.**
  A flag has no deadline and no closure of its own, so what stops it needing attention is
  the Run ending; `isActiveRunState` is that predicate. EXPERIENCE.md's Notification row
  names no acknowledge action, and inventing one would be a product decision taken sideways
  inside a story about a button. The consequence is that the inbox shows a flag with NO
  countdown while an Escalation shows one — which is why `OpenNotification` became a UNION
  with `deadline` only on the arm that has one, rather than a nullable field every reader
  has to remember not to render.
- **The bell counts waits and flags as two counts ADDED, never a join.** A Run can carry an
  open wait and a flag at once, and a join would report their product.
- **`notification_escalation_context` became `notification_context`, with three arms.** One
  per kind the table now holds, so a flag cannot be dressed as an Escalation or the other
  way round. Generation 35's trigger reaches an Escalation-carrying-a-flag-id row FIRST, so
  the integration test asserts THAT message rather than the CHECK behind it — and then
  asserts the row does not exist, which is what the rule actually promises.
- **Flag is the ONE control on these surfaces with no confirmation dialog, so it is the one
  that can work without JavaScript.** EXPERIENCE.md's confirmation table enumerates the
  actions that get a dialog and flagging is not among them; pause and cancel are exempt
  from the "JavaScript may enhance a control, never be its only path" rule only because the
  dialog they must have cannot exist without script. The form's action IS the Server
  Action and `useActionState` renders the result on both paths. `flag-run.spec.ts` proves
  it with `javaScriptEnabled: false`.
- **`RunCancelControl` was extracted for the reason `RunPauseControls` was.** Both surfaces
  carry Cancel now, and two copies would agree on every case anybody tried and diverge on
  the first one nobody did. Rerun stays on Run Detail: a terminal Run's Live View is a
  Replay and has nothing to rerun from.
- **`ActorNameReader` is the one place a user id becomes a person's name.** A Run records
  its initiator, the auditor who paused it and the auditor who flagged it as IDs, because
  an address cannot enter the chain; printing one at a reader is the platform speaking its
  own language — the defect the plain-words pass removed from the authoring screens, met
  again on the Run surfaces. It returns names only, never addresses, and an id with no row
  comes back absent so the caller shows the id, which is honest about what it knows.

Three mechanical notes:

- **A React Server Action form cannot be asserted to POST in an SSR unit test.** With the
  action mocked, React renders `action="javascript:throw new Error('React form
  unexpectedly submitted.')"` instead of the endpoint Next's compiler emits, and it warns
  that it overrides `method` and `encType`. Keep `method="POST"` anyway — `form-method.test.ts`
  requires it of every form and React sets the same value — and prove the no-JavaScript
  path in the browser, which is the only place it is real.
- **`?? ` swallows an explicit `null` in a test harness.** A fake whose role came from
  `options.lockedRole ?? options.role ?? 'auditor'` could not express the one case it
  existed for — a role revoked between the outer check and the row lock — and the test
  passed against a build with no recheck at all. `Object.hasOwn` is the test.
- **A browser assertion that filters on a STATE counts other tests' rows.** The inbox
  locator matched "flagged for an Audit Manager" and found three, because two earlier cases
  in the same file had flagged Runs that are still active. Scope such a locator to the
  subject the test itself created, never to the state it is in.

## 2026-09-09 — Queue maintenance needs a connection of its own

`Plan derivation queue failed` every 60 seconds in production, since the Epic 2 era. The
cause is one word: `createProceduresQueue` left pg-boss's `supervise` at its DEFAULT
(`true`), so the built-in supervisor ran on the SHARED pool — and its monitor and maintain
passes issue a raw `BEGIN; SET LOCAL ...; SELECT pg_advisory_xact_lock(...)` block through
`plans.locked`, which postgres.js refuses on a pooled client with `UNSAFE_TRANSACTION`
because a pooled checkout cannot promise the whole block lands on one connection.

**What it actually cost.** Plan derivation itself was fine — proven by pushing a real job
through — so the visible symptom was only a log line. What was silently not happening is
DELETION: completed jobs past their queue's deletion window were never removed, so
`pgboss.job` grew without bound. And ONE PgBoss instance serves every queue this worker
runs — procedures, runs, waits, evaluation reviews, evidence read grants — so one broken
supervisor was all five.

- **Maintenance is a sweep with its own client, not the constructor's supervisor.**
  `startQueueMaintenance(databaseUrl, onError)` owns a `max: 1` client (where the raw block
  is legal), runs `supervise()` on its own timer, and returns a stop that closes both — the
  shape `startProceduresRecovery` beside it already uses. `createProceduresQueue` now says
  `supervise: false` explicitly, which makes it the twelfth of twelve `new PgBoss(...)`
  constructions in this package to say so rather than the one odd exception.
- **A dedicated connection is right for a second reason.** A reindex is DDL and can hold
  its connection for seconds; on the shared pool that would stall the job polling of every
  worker in the process.
- **The test that catches the regression asserts the DELETION.** `pgboss.queue.maintain_on`
  advances even on the broken build — it is set before the statement that fails — so a
  first version of the test that watched the timestamp alone PASSED against the pooled
  supervisor and proved nothing. It was deleted rather than kept: a test that cannot fail
  for the reason it exists is worse than no test, because it reads as coverage. Proven by
  mutation: putting maintenance back on the pool fails
  `tests/integration/queue-maintenance.test.ts`.
- **`supervise()` reaches the raw transaction only when a queue is actually DUE.** The
  negative test has to push BOTH `monitor_on` and `maintain_on` back, for every queue; with
  only `maintain_on` reset it resolved happily against the broken build. The failing
  statement is in the MONITOR pass, not the maintain pass.
- **The driver's reason is on `error.cause.code`, not the message.** pg-boss reports
  `Failed query: BEGIN; ...`, so matching that would pass on any failed statement and drift
  with its formatting. Assert `cause.code === 'UNSAFE_TRANSACTION'`.
- **The release migrator was never affected** and still installs pg-boss's schema on the
  pooled client: `migrateProceduresQueue` already sets `supervise: false`, and the install
  path does not use `plans.locked`. Verified on a fresh database, which reached generation
  41 with all twelve `pgboss` tables.

Two mechanical notes, both about running this suite locally:

- **`pnpm db:migrate` runs `pnpm install --prod` in its dependency-closure step**, which
  PRUNES dev dependencies and leaves the workspace unable to typecheck (`Cannot find type
  definition file for 'node'`). Run `node packages/infrastructure/dist/db/migrate.js`
  directly against a built tree, or reinstall afterwards.
- **The integration suite refuses a database whose NAME does not match
  `(^|[_-])(test|ci)([_-]|$)`.** A database called `qfix` fails eighteen files in their
  `beforeAll` with "require an isolated local or CI test database" — the Story 1.5
  throwaway-database guard doing its job, and nothing to do with the code under test.

## 2026-09-09 — The worker image carries its own browser, and only the half it can reach

The Agent Workspace's LOCAL mode calls `chromium.launch()` INSIDE the worker container, so
`node:24.20.0-bookworm-slim` with no browser meant every agent-driven Run (P-1, P-4) failed
at provisioning while every adapter Run (P-2, P-3) passed — the deployment looked healthy
and half the product did not work. Found by reading the Dockerfile against
`browser-execution.ts` while writing a test plan, not by a failing test, because nothing in
CI ever launched a browser inside the built image.

- **`chromium-headless-shell`, not `chromium`.** `browser-execution.ts` passes no
  `headless` option, so Playwright's default applies and the headless shell is what that
  default launches. Verified rather than assumed, against the real
  `PlaywrightBrowserExecution.create` on the real `pnpm deploy --prod` tree with only the
  shell present: create, `newContext`, `newPage`, `textContent`, `screenshot`, `release`
  and `close` all succeed. 262 MB against the full build's 389 MB. `ffmpeg` is removed too
  — it exists only to encode video and nothing here records any — and the same proof was
  re-run with it deleted.
- **`install-deps` still names `chromium`.** The system libraries are shared, and letting
  Playwright resolve them for the distribution beats pinning an apt list that goes stale at
  the next browser revision.
- **`PLAYWRIGHT_BROWSERS_PATH` is declared ONCE, on the runtime stage.** It has to cover
  both the install and the running process; set for only one, the browser is downloaded to
  root's home and the worker looks elsewhere.
- **The CLI path is RESOLVED, never written out.** `playwright-core` is transitive through
  `@intellifin/infrastructure`, so under pnpm it lives in `.pnpm/playwright-core@<version>/`
  and any literal path breaks on upgrade. It is also NOT resolvable from the deploy tree's
  root — only through the realpath of `node_modules/@intellifin/infrastructure`, which is
  how Node resolves it at runtime anyway.
- **A narrow choice needs the test that catches its regression.** `images` in `ci.yml` now
  runs `PlaywrightBrowserExecution.create` inside the BUILT image, so a later `headless:
  false`, a channel, or a dropped install fails there rather than in a Run against a live
  Target System. Testing raw `playwright-core` instead would have proved the binary present
  and said nothing about the options the product actually uses.
- **An empty `allowedOrigins` is the right policy for that smoke test**, not a placeholder:
  it denies every destination, which is exactly what a desktop-only plan really gets.
- **Solari mode needs none of this** and the image carries it anyway, because the mode is a
  boot-time choice — an image that worked in only one of them would make a configuration
  switch into a deployment trap.

`seed-northstar.yml` now DERIVES `CREDENTIAL_CAPABILITIES` from
`fixtures/northstar/datasets/systems.json` instead of naming one reference by hand. The
hand-written value named LoanCore's own reference and not the shared fallback the script
applies to the other nine, so the seed refused before writing anything — the fail-closed
manifest working exactly as designed, and a list that drifts from the data the moment a
system is added.

## 2026-09-09 — The Replay asset set: a frame that is missing, and the recording that arrives after the seal

Story 5.2 adds NO capture path. AD-17 already says a live frame is a Replay asset the moment
it is registered, so Live View and Replay read the same rows and a second path would give
two surfaces two answers about one session. What the story adds is the `role` (generation
43), the event that says the set is not whole, and the copy of the provider's own recording.
Whole rule: `docs/contracts/replay-asset-set-v1.md`, whose asset table
`tests/unit/replay-asset-set.test.ts` reads off disk and pins to the schema — a renamed
column that silently breaks Replay is what that catches, and it fails with a named message.

- **A screenshot bound to a Tool Action keeps `role = 'evidence'` and is still a frame.**
  The one judgement call. It serves both purposes — `required-evidence` reads it per
  Observation, Live View and Replay render it — and demoting it for the sake of the label
  would take it out of the seal's reach and out of `required-evidence`'s, weakening an
  audit to tidy a name. The role says what an artifact is FOR when the two purposes differ;
  where they coincide, the stronger one wins.
- **`failure.frame-missing` is derived from three stored facts and one absence**: the action
  `performed`, its `capture` is `PERMITTED`, and no `screenshot` is `REGISTERED` against its
  `run_evidence_capture` binding. A credential-entry action is excluded BY THE PREDICATE
  (`capture = 'SUPPRESSED'`, generation 29) and not by a rule the reader remembers —
  suppression and absence are different statements, and reporting the first as the second
  raises a finding against the guarantee that produced it. ONE event per Run with the exact
  total and a bounded sample; the count also goes on `publication.evidence.framesMissing`,
  because "flagged on export" needs a fact the document carries. **The seal is never
  blocked, and that is a property of WHERE the read sits** — after `sealPackage` has already
  returned. A `RESERVED` binding turned out to be unreachable (a published trigger refuses a
  capture bound to unregistered Evidence), so that is asserted rather than worked around.
- **The session recording is `run_replay_recording` (generation 44) and NOT a
  `run_evidence` row.** The copy happens at the terminal RELEASE, which is after
  `completeRun` has already sealed; generation 21 freezes a sealed Run's Evidence, so an
  Evidence row here would either be refused or would sit outside the seal that names what
  this Run froze — and the second is worse, because the Result would publish an artifact
  list that did not include it. It cascades from `audit_run` like `run_workspace`: it
  records no audit outcome, so no existing teardown has to learn a new table name.
- **The credential wall applies here hardest of all, so the resolver is REQUIRED.** A
  session recording is a transcript of a browser and a sign-in TYPES a credential into a
  form field. `copyRecording` builds its guard from the credential references the frozen
  plan names; a plan whose references NONE resolve is refused (`recording-unscannable`)
  rather than treated as clean. Upload and verification go through `freezeArtifact` — the
  same implementation every Evidence artifact uses — so the scan-before-upload rule has one
  home. Proven by two mutations: swapping in a permissive guard, and treating "nothing
  resolved" as clean.
- **`downloadRecording` returning `null` is the ORDINARY answer**, not an error: the local
  mode records nothing and `SOLARI_RECORDING` is off by default. Only a provider that fails
  throws. `REPLAY_RECORDING_DIAGNOSTICS` keeps the five reasons apart, because an operator
  acts on four of them and not on the first.
- **`[NOT BUILT, NAMED]` Provider retention is not set to minimum.**
  `@solarisdk/browser@0.1.3` exposes `create`, `release`, `releaseAndWait`, `getReplayUrl`
  and `downloadReplay` and no retention control at all. The 2026-09-01 decision asks for it;
  the SDK this build ships cannot express it, so it is an owner action against the provider
  account. **And the live leg is unproven here**: this environment holds no provider key and
  recording cannot be enabled for a session that already exists, so every case runs against
  a synthetic provider.

Two mechanical lessons, both about the migration chain:

- **A hand-written migration needs a GENERATED snapshot.** `0043_snapshot.json` was made by
  hand without the new column, so the next `db:generate` re-emitted generation 43's whole
  DDL into 0044 — and CI's drift check caught it as the one red job out of five. Regenerate
  the snapshot from the real schema (temporarily remove the NEXT change, generate, restore
  the hand-written SQL under its own tag), then generate the next one on top.
- **Never let a PUSHED migration's journal `when` move.** Regenerating 0043's snapshot
  rewrote its `when` to an earlier value, and the migrator applies what sorts AFTER the last
  applied `created_at` — so every database that had already applied 0043 silently skipped
  0044 and reported success at 43. Restore the original `when` and give the new migration a
  later one. A fresh install still reached 44, which is exactly what makes this the kind of
  defect that ships: only an UPGRADE can see it.

## 2026-09-09 — An Evidence artifact has a ROLE beside its kind, and replay never gates a seal

`EVIDENCE_ARTIFACT_ROLES` is `evidence` and `replay` (generation 43, `run_evidence.role`).
`evidence` is what a Run concluded FROM; `replay` is what it is WATCHED BY. It cannot be a
kind, because the same kind sits on both sides — the screenshot an Observation is grounded
in is Evidence, the screenshot taken after every Tool Action so a session can be replayed is
not — and it cannot be a naming convention, which is one anybody can satisfy by typing.
`sealPackageDecision` filters `required && role === 'evidence'`, so a producer that set the
flag wrongly, or a row an older build wrote, still cannot make a package INCOMPLETE for a
frame nobody concluded anything from; `reserveArtifact` forces `required: false` on a
`replay` reservation, and `run_evidence_replay_never_required` is the layer below both that
no raw writer can route around. Three statements of one rule, in the order this codebase
always uses: the producer cannot ASK for the contradiction, the domain would not honour it,
and the database refuses to hold it. `population_evidence` gains no column — a population is
Evidence by definition and has no other role to hold. The backfill is STRUCTURAL and not a
guess: every row the table has ever held was written by a producer freezing bytes a Run
concluded from. `role` is added with a DEFAULT and the default is then DROPPED, so the next
producer must say which role it means rather than inheriting one.

- **A new column on a reviewed table needs `tests/integration/schema-compat.test.ts` too.**
  That file asserts the EXACT column set of `run_evidence` and `population_evidence`, and it
  is the guard working: an unlisted column is a migration nobody reviewed. It was the one
  failure left out of 487 after generation 43, and it named itself.
- **A historical-schema upgrade test must NOT get the new column.** `absence-guard-upgrade`
  and `sealed-evidence-upgrade` build a generation-32/40 schema by hand and then run the real
  migrator over it; adding `role` to their seed inserts would have them seed a schema that
  did not exist. They assert the backfill separately and strip `role` before comparing rows.
  `absence-guard-upgrade`'s `seed()` reads `information_schema` because it seeds BOTH schemas.

## 2026-09-09 — Live View: a frame is a registered artifact, read through the grant that already exists

`/runs/<id>/live` is a SURFACE, not a sixth Run Detail tab (EXPERIENCE.md reaches it from the rail's **Watch** control and from a notification, breadcrumb `Runs / <run> / Live`), and it authorizes for itself through `openRun` like every tab. A frame is `run_evidence` of kind `screenshot` in state `REGISTERED` bound through `run_evidence_capture` to the `run_tool_action` that captured it — the BINDING is what makes it a frame, and a loose screenshot is not one. Its bytes reach the browser only through the Story 4.4 worker-signed grant, consumed on the web server: `FRAME_LOCATOR` is a third locator naming the KIND of read, issuance branches on it (a `frame` grant requires a `screenshot` of `image/png`; every other locator still requires a Structural Snapshot with an implemented substrate), and generation 42 widens the published binding trigger to admit both kinds and changes nothing else. `downloadWithGrant` was EXTRACTED from the snapshot reader rather than copied, so poll-verify-record has one implementation. **The web still never touches object storage** — `no-evidence-store-in-web` still fails the build — and the structural claim is asserted rather than searched for: every `src` on the surface is under `/api/runs/<id>/`, which a signed store URL fails. The route answers 304 on the digest ETag under a FRESH role check and with no grant; a store disagreement is 502, an unsigned grant a retryable 503. `liveViewChrome` is total over `RUN_STATES` and gives `QUEUED` NO word rather than stretching `LIVE` (the "Active version: Draft" rule); the four stage sentences say why a stage is empty, because an empty stage that says nothing reads as "fine". The Step counter's denominator is READ from the frozen plan. NFR-7 needed an event: `registerAgentCapture` now appends `execution.capture-registered` in the transaction that registers the capture and notifies the channel. Story 5.3 ships READ-ONLY — Pause is 5.4, Flag is 5.5, the scrubber is Replay's — and links to Run Detail for Cancel. Contract: `docs/contracts/live-view-v1.md`.

Three mechanical lessons from proving it:

- **Seeding a RUNNING Run while the real worker is up hands it to the worker.** A RUNNING Run with no `population_execution` row IS abandoned, so the population recovery sweep claimed the fixtures and executed them out from under the surface under test — one reached `RUN_FAILED`. Seed the checkpoints such a Run really has (`POPULATION_READY` plus a claim whose lease is still live) so all three sweeps see a live claim; that is also the truthful state of a Run whose worker is holding it.
- **Who performs a `CANCELED` transition decides what a browser test can assert.** `RUN_CANCEL_TRANSITIONS` gives a RUNNING Run to the WORKER, so `cancelRun` there only records the request and the page correctly does not flip. The "Run ended while open" journey uses a PAUSED Run, which the COMMAND transitions, so the flip really happens.
- **`vi.resetModules()` in a `beforeEach` re-transforms the whole workspace graph per case.** The frames-route test timed out at 5 seconds on its first case for that reason alone; the route holds no module state, so the reset was buying nothing.
- **Never point a second worktree at another worktree's `node_modules`.** A `ln -s` of the epic-5 `node_modules` into a scratch worktree, followed by `pnpm build` there, REWROTE the shared `node_modules/@intellifin/*` links to the scratch tree; removing that tree left them dangling. Two browser specs then failed with `does not provide an export named …` — a resolution failure that reads exactly like a missing export, on a branch where the export is present in both source and `dist`. Next resolves workspace packages its own way, so 172 tests still passed and only the two specs importing the package directly could see it. Give a second worktree its own install, and re-run the whole suite after repairing links: a contaminated green is worth nothing.

## 2026-09-09 — The live Timeline channel: a notification is a wake-up, never the data

`openRunTimelineStream` (`packages/infrastructure/src/runs/run-timeline-channel.ts`) LISTENs on `run_timeline` — the channel every writer already NOTIFYs, pinned by a source scan over the package rather than a list — arms the LISTEN BEFORE replaying `sequence > cursor` from `audit_events`, and on every wake-up and every heartbeat reads `sequence > lastSent` again, in order: a lost or coalesced notification cannot lose an event, and `lastSent` only grows, so nothing is sent twice. The stream carries the chain's ENVELOPE (seq, eventType, occurredAt, outcome, source) and never a payload; a surface re-reads what it renders from PostgreSQL through the reader it already has (`router.refresh()`, throttled to one a second). The heartbeat is an SSE EVENT every 10 seconds, not a comment: a comment is invisible to `EventSource`, and the 15-second stale rule (UX-DR25) needs a signal the page can observe. The cursor is `Last-Event-ID` first and `?after=` second, because a reconnect carries both and only the header is current. Lifetime 14 minutes ending with `event: end`; an aborted request tears its listener down, which the integration test proves by counting hand-overs through a `Proxy` on the real client. `sql.listen` needs the postgres.js client, so the engine lives in infrastructure and the two routes are thin; the list stream reads the row a notification names rather than forwarding the notification. Only the status WORD is `aria-live`; the counting sentence beside it is not. A terminal Run keeps the plain `Updated {time}. Refresh.` banner (UX-DR35), and the bell re-reads only on `execution.escalation-*`. Contract: `docs/contracts/live-timeline-channel-v1.md`.


## 2026-09-09 — The hero workflow: what the Builder now does, and the rules underneath it

Owner decision 2026-09-08: an ordinary Draft section save is DIRECT, with the visible saved / unsaved / refused state and the lost-response recovery it already had; the focus-trapping confirmation stays only where a person cannot take the action back from that page — submit, approve, reject, edit back to Draft, activation, cancel, rerun — and for SCOPE EXPANSION (a Target Systems save that ADDS a registration, which names the systems being added; removing, reordering or re-saving is direct). Recorded in EXPERIENCE.md and the UX memlog through `memlog.py`. The Draft is editable and says so: two sections stay read-only (`BUILDER_SECTION_TEMPLATE_ONLY_SENTENCE`) and the Control section names where its editable half is; `copy.test.ts` refuses the phrase "not editable yet" anywhere under `apps/web`. Simple and advanced Compliance editors operate on ONE authored string (`apps/web/src/procedures/simple-condition.ts` reads it into controls and writes controls back, verified by a round trip through the unchanged compiler); switching modes writes nothing, typing in the textarea pins a condition to advanced, values are compared EXACTLY and never case-folded. Readiness (`packages/domain/src/procedures/readiness.ts`) is a CLOSED vocabulary computed on read from the frozen-shaped authoring inputs, never stored, never a save refusal or submission blocker, always rendered beside `READINESS_NO_GUARANTEE`; `AgentSummary` restates the frozen plan and compiles nothing. P-1's 24-hour window is a THIRD condition (`C3`, or a fresh id when taken) added from the Timing controls beside C1 and never in its place — an Active account has no disablement instant, so C1 is what makes it an Exception; `disablementWindowCondition` attaches the frozen `termination_time` mapping only when the compiler this build ships accepts the key, and omits it (never null, never empty) otherwise. A path that THREW says the change may have been saved, never "Nothing was changed". `[hidden]` is `display: none !important` at the root because a class rule beat the user-agent one and a hidden textarea stayed focusable. Journey: `tests/e2e/hero-workflow.spec.ts` (keyboard, axe, one screenshot per proven state; screenshots default to `test-results/`, the curated set is `_bmad-output/implementation-artifacts/hero-ux-screenshots/` via `HERO_UX_SCREENSHOTS`). Named, not built: `createProcedure` carries no request token, so a retry after a lost creation response makes a second Procedure; the form blocks the retry and points at the list instead.

## 2026-09-09 — `sql.json` throws on any client `createDb` has wrapped

drizzle-orm's postgres-js driver rewrites the WRAPPED client's serializers for `json` (114) and `jsonb` (3802) to the identity, so on a postgres.js client that `createDb(sql)` has seen — every integration file's `sql` — `sql.json(obj)` hands the raw object to the wire encoder and throws `The "string" argument must be of type string…` before PostgreSQL sees a statement. On an unwrapped client the same call works and `${JSON.stringify(x)}::jsonb` double-encodes instead (the PR 21 note). `${JSON.stringify(x)}::text::jsonb` is right on both: a text parameter meets no JSON serializer and the server does the cast. Two things it hid, both repaired: `immutable-versions.test.ts` restored the `@current` pointer through `sql.json` and failed on any database that already held a published configuration, fresh or upgraded (CI never met it; the populated-upgrade proof did), and `procedures.test.ts` asserted a bare `rejects.toThrow()` on three raw-SQL Period cases, which the driver's TypeError satisfied before the CHECK was reached. A refusal that must be PostgreSQL's is asserted by SQLSTATE (`22008`, `23514`), never by a bare throw.

## 2026-09-09 — A guarded line's mutation anchors move with it

`scripts/verify-*-mutations.mjs` anchor each mutation on an EXACT source line (`before:`), and the hosted mutation gates stop with `Mutation anchor drift` before proving anything when that line changes. The C2 policy edit widened the worker's audited-retry guard and three anchors went stale for two pushes. When editing a line a harness anchors on, repoint the anchors in the same commit, keep the mutation and its killing test unchanged, check every `before:` occurs exactly once, and rerun the harness in a disposable detached worktree of the committed HEAD (it refuses a dirty tree).

## 2026-09-08 — D3: the 24-hour window's evidence path is explicit, frozen and proven

A compiler-1 time field the bound source stores under another name is supplied through an OPTIONAL per-condition `mapping` (time fields only, one column per field across the version, omitted when absent so legacy rows recompile byte for byte). `observationRuleValues` applies it after same-named columns and under grounded attributes; a column the source lacks is `missing or invalid Observation field termination_time`, and a date is never promoted to an instant. P-1's `disabled_time` is a VARIANT attribute (`variantAttributeLabels`, label `Disabled time` on LoanCore's page and in the catalogue) captured only when the version's Evidence Requirements name it, so default P-1 Runs are unchanged. E-000105 is the §D boundary case: exactly 24 hours is Compliant under the inclusive boundary. Fixtures: `canonicalLoanCoreCompliance({ disablementWindow: true })`, `startCanonicalLeaverSource(id, { terminationTime: true })`; journey: `tests/e2e/disablement-window-journey.spec.ts`. Contract: `docs/contracts/deterministic-evaluation-v1.md`. Not a universal mapping platform.

## 2026-09-08 — C2 role-privilege policy is a frozen condition binding

Privilege is never inferred from a role name, the system prompt, the runtime or an expectation fixture. `RolePrivilegePolicy` is an OPTIONAL `policy` key on an Agent-Judged condition over a Template's `roles` field, omitted (never `null`) when absent so legacy rows recompile byte for byte. The evaluator applies it before the proposal (unreadable roles = missing field; an unnamed role = §B unnamed value, escalated before any paid turn) and after it (a contradicting proposal is UNEVALUATED, never corrected; the producer retries it as a rejected model answer). A consistent privileged Exception is labelled `retained privileged assignment`. `agentJudgedNeedsProposal` is the one predicate the producer and registrar share. C2 stays Agent-Judged and pending human confirmation. `canonicalLoanCoreCompliance({ c2Policy: false })` keeps the original undefined-privilege negative case. Contract: `docs/contracts/deterministic-evaluation-v1.md`.

## 2026-09-08 — A refused Target System never disappears from the Result

Owner decision 4: explicitly selected systems define scope; an unselected Template default never blocks. `requiredTargetSystems` no longer returns an empty list for a refused plan; it keeps every selected non-reference system, so a Run refused for a selected desktop reports every record uninspected per system rather than "no coverage required". The Result publication gained an optional `targetSystems` list (`resultTargetSystems`): each selected system with `support`/`reason`, each unselected default out of scope by name; documents older than the key say so on the surface. Story 2.3's spec carries the superseding note.

## 2026-09-07 — Page-script write containment

The browser context enforces read-only HTTP methods as well as destination scope. An action gate alone cannot stop retrieved page scripts issuing same-origin writes. Only the real form login may arm one exact credential-bearing main-frame POST; redirects, fetch/XHR, repeats and credentialless bodies cannot use that exception. It is revoked in finally and page disposal. Local browser tests establish state isolation only, not Solari process/network isolation.

## 2026-09-07 — Agent evaluation model phase

Agent prompt version2 is independent of procedure derivation prompt version1. Evaluation requests bind a final frozen Observation identity and an allowed condition set; provider output cannot redirect that identity or invent conditions. Action-v1 requests remain supported. The Run token reservation includes the complete evaluation payload and condition text before I/O; omitting those fields would permit uncharged model work. Usage, fallback accounting and credential scanning use the existing durable turn path.

## 2026-09-07 — Evaluation review surface

Run Detail reads the fresh review revision and pending count under its explicit evaluation-review permission, renders machine rationale as untrusted text, and submits only fixed decision fields. Raw database exceptions may contain evidence/rationale parameters: telemetry receives a fixed error code and correlation id, never that exception. Browser injection checks scope executable-node absence to untrusted content containers; Next.js itself legitimately loads scripts outside them.

## 2026-09-07 — Human evaluation review storage

Generation36 preserves original machine evaluations and nullable original proposals, then appends human decisions to an immutable ledger. Effective counts/findings overlay that ledger. The Result has a frozen ten-key wire/storage contract and generation25 permits only its final sealing update; AD21's answer revision therefore lives in adjacent run_result_review under the same Run→Result→review locks. Result.version changes only on final sealing. This is an implementation reconciliation, not a new owner decision. Pending UI counts must query effective evaluations, not the unchanged pending publication. Historical proposal fields stay NULL rather than fabricated; no retroactive matched-only check invalidates historical evaluations. New human Compliant decisions require covered, matched evidence.

<!-- Escalation browser regression: scope the inert question body through its provenance container. A Run with candidate options intentionally has several pre elements, so a page-wide pre selector is ambiguous. -->
## 2026-09-07 — Preserve live search reads

An approved read-attribute captures the current page only when its full query-free authority/path matches the selected destination and frozen scope. It must not reload a search URL after sanitization removes its query. Response metadata remains in memory; a restart without that response requires a fresh approved action, never invented HTTP metadata. Deadline unit checks use a controlled clock to avoid native timer rounding.

## 2026-09-07 — Escalation checkpoint CI corrections

Closed escalation kind vocabulary lives in a dependency-free leaf shared by wait commands and notification ports; importing command modules from notification contracts creates an identity/notification cycle. Raw PostgreSQL test JSON arrays use explicit JSON.stringify plus jsonb casts, matching the test connection serialization. Untrusted question provenance assertions target the label element because the component appends platform safety guidance.

## 2026-09-07 — Escalation delivery and answer checkpoint

Generation35 expands existing notification tracking rather than creating another queue. Lock order is audit_run then run_wait then notification/audit chain, matching wait creation/answer. Open waits drive the inbox independently of delivery. No email transport is configured: audit outcome is unconfigured, never sent. Run Detail reads the current wait and revision with matching Step/Evidence references; agent question and candidate text remain inert. Fixed labels come from application vocabulary. Full local typecheck and focused tests pass; hosted new journey/migration verification is pending and Epic4 remains incomplete.

## 2026-09-07 — Agent execution checkpoint decisions

Provider-native worker keys compose the agent gateway independently of plan derivation MODEL_* settings. Missing keys do not authorize a script; absent deployment SHA is labelled unidentified-build. Browser actions share one absolute deadline across every phase. Search FormData inspection alone is insufficient: a page can mutate on submit, so an armed page route validates the first main-frame request before transmission and falls back to the existing workspace egress guard. Generation34 adds four explicitly inventoried operational tables; migration, populated upgrade and wait integrations passed CI34138046009, whose sole failure was the stale table inventory. These are incomplete Epic4 checkpoints, not release acceptance.

<!-- Story4.7 durable waits: release creates the waits queue; answers retain its original deadline job, whose closed-row delivery is superseded. Closed waits are immutable and SQL closure checks explicitly reject NULL discriminants. All producers reuse withRunExecutionContext for Observation, Evidence, Gate and Result writes. -->
<!-- Story4.6 gateway: real provider usage survives invalid/late responses and fallback; unaccounted attempts are explicit so the Run ledger retains a conservative reservation. Agent model code is a worker-only subpath, checked for source and built imports. -->
<!-- Story4.4 browser capture: logical search performs the real approved GET form with exact accessible labels. Capture requires an explicit CredentialGuard, refuses password/live secret surfaces, and binds semantic snapshot/PNG artifacts to the final sanitized location. It does not itself register an Observation. -->
<!-- Story4.4 storage checkpoint: generation33 admits structural-snapshot and screenshot Evidence kinds with distinct deterministic reservation keys. Existing artifact keys/digests and sealing guards are unchanged; capture producer wiring follows separately. -->
<!-- Story4.4 substrate checkpoint: web_tree now re-reads bounded grouped semantic nodes at $.nodes[i].value. Completion metadata is optional and target-specific; missing counts stay unknown. Python golden vectors independently pin extraction; desktop_tree remains unsupported. -->
<!-- Story4.4: identity and grounded declared attributes must name one Structural Snapshot. Registration refuses the entire batch on identity-grounding-split before corroboration or writes; the frozen13-key Observation schema is unchanged. -->
<!-- Authentication: require the exact approved target/account postcondition, bind redirects to the action's selected target, and discard secret-bearing pages after submission failure while preserving provider cleanup identity. -->
<!-- Workspace cleanup: a persisted Solari hard expiry is distinct from confirmed release; never discard an unexpired provider identity after a configuration mismatch or provider error. -->
<!-- Engineering continuation: raw postgres.js timestamp-without-time-zone values may be strings; normalize dates in migration assertions. Drizzle wraps server errors in cause; sealed guards use SQLSTATE 23514. -->
## Live acceptance report retention

Playwright's list reporter keeps body attachments in memory; upload-artifact cannot find them. Secret-scan the selected acceptance facts before writing a named outputPath JSON file and attaching that path. Emit the same scanned facts for connector-readable diagnostics; never emit raw worker/model/provider logs. Preserve failed acceptance and workspace cleanup references as carefully as successful reports.

## Live model failure classification

Keep invalid-response retry/wait behavior stable, but retain a runtime-validated closed suffix on failed turn diagnostics to distinguish output budget, empty response, JSON, shape and selection failures. Never retain rejected model text, parser errors or reasoning. Provider usage remains charged. Live acceptance must recognize AWAITING_AUDITOR, the actual Run vocabulary, and stop for an authorized decision rather than wait out the audit deadline.

# CLAUDE.md

## Engineering continuation — transport and verification

The temporary snapshot and branch-writing delivery workflows are removed. Commit source changes directly through normal Git/GitHub operations. CI success on a delivery-payload commit does not verify the later commit produced by that workflow: require checks on the actual candidate. The generated populated-upgrade regression at `94978c9` contained a literal newline inside a regex and failed root TypeScript checking before any database test could run.

## Engineering continuation — populated migration proof

Generation 32 enriches historical evidence metadata under a release-only transaction with exclusive table locks and two named triggers temporarily suspended and restored. No runtime bypass exists. The upgrade regression uses the real generation-31 schema and sealed Runs, proves the unguarded backfill fails, proves rollback restores protection, and verifies old evidence/outcomes are unchanged after the real migrator succeeds.

## Engineering continuation — authentication proof

Cookies are transport state, not authentication proof. The bounded synthetic sign-in contract requires a successful response, no password form, and the visible named signed-in account. Unknown UI is unconfirmed. The real-browser regression covers stale/unrelated cookies and a server issuing a cookie while still serving its login form.

## Engineering continuation — workspace identity

An existing workspace is identified by provider mode plus provider session ID. Never overwrite its mode from current worker configuration. A provider change must preserve the old cleanup reference and refuse continuation; a new Run can use the new provider. The regression covers both Solari-to-local and local-to-Solari restarts.

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

# Working rules

Repository guidelines, layout, and project policy live in `AGENTS.md`. Read that too.

## This is a living document

This file is the one shared place for decisions that affect how anyone — agent or developer — works with this codebase. When we hit a gotcha and agree on a workflow, record it here (see "Codebase decisions and gotchas" at the bottom) so a later agent does not re-decide it differently. Keep entries short: the decision, the reason, one line each. Update this file in the same commit as the work that produced the decision.

## Done means done

Not half done. Not done except for the part you decided to skip. And not a report about how it will be done.

Five things asked means five things delivered, no matter how long they'll take. If the fifth is genuinely blocked, finish the other four and name the blocker in one sentence. The specific blocker. Not "this needs more investigation."

## Act. Don't ask

Reversible and cheap? Do it, then tell me. Research, data pulls, analysis, drafts, refactors inside the scope I gave you, testing an API. A question costs me more than a re-run costs you.

Ask first only for: anything reaching an audience, anything we cannot undo, anything expensive.

Something is broken? Fix it. Reporting an issue you could have fixed turns your work into my to-do list.

## A question is a question

When I ask a question, answer it. Do not implement it.

"Should we use X?" is not "migrate everything to X." "What would it take to add Y?" is not "add Y."

When in doubt, assume it's a question. Answer first. Act when I say go.

## Speed and model routing

The model families named below describe Claude environments. Other agents use the
platform-specific adaptation in `AGENTS.md` after its managed context block; active
runtime instructions and available capabilities take precedence.

When running as a frontier-tier model (Fable, Opus, or their successors): optimize for wall-clock speed. Finish tasks quickly.

Route work to the cheapest model family that does it well. Never burn top-tier intelligence on routine work. The tiers, from cheapest to most capable — use whichever models from each tier are available:

- **Small/fast tier** (Haiku family): trivial mechanical work — file lookups, simple renames, formatting.
- **Mid tier** (Sonnet family): routine work — search, bulk edits, boilerplate, verification, running test suites.
- **Frontier tier** (Opus, Fable/Mythos family): hard reasoning that can run independently — architecture calls, tricky debugging, concurrency and correctness work. The top model (Fable) is costly; reserve it for work that actually needs it.

- Parallelize aggressively. Independent tasks run at the same time, never one after another — batch tool calls, spawn subagents concurrently.
- Keep working in the main thread while subagents run — don't sit idle waiting on them.
- Don't over-deliberate. Enough info to act = act. No long option surveys for decisions with an obvious default.
- Speed never trades away quality: same rigor, same verification, same "done means done". If parallelizing risks a worse result, slow down.
- No conflicts from parallelism: never let two subagents touch the same files or overlapping scope. Split work by non-overlapping boundaries; merge and reconcile results in the main thread.

## Short responses

It's been a long day and my brain is fried, talk to me like I'm 5.

Small words, short sentences, short paragraphs. If you have to use a big word, explain it right after. Only return what's actually necessary.

Just tell me what you did, did it work, what do I do now.

If I have to decide something: 2 options max, the context I need to pick fast, and which one you'd go with.

Keep paths and commands exact.

Always use ASD-STE100 Simplified Technical English when you talk to me.

# About this repository

## What it is

**IntelliFin Audit** is an audit-execution platform: an auditor defines an Audit Procedure once and delegates its repeated execution to an autonomous Audit Agent, whose work stays observable, replayable, evidence-backed, and subject to human review.

This repository is both a BMAD v6.11 planning workspace and, since Story 1.1, the application monorepo itself. Planning artifacts under `_bmad-output/` still lead the code: the product is specified before it is built. `AGENTS.md` holds the verified agent block; refresh it with `/bmad-project-context`.

## Layout

```
apps/web/               Next.js 16 UI and route handlers; composition root (src/bootstrap.ts)
apps/worker/            Node worker; composition root (src/main.ts), heartbeat loop
packages/domain/        Entities, value objects, state machines. Imports nothing outward
packages/application/   Commands, queries, owned ports. Imports only domain
packages/infrastructure/ Drizzle, postgres.js, config, migrations. Implements the ports
tests/fixtures/         Frozen golden and adversarial data
tests/integration/      Real PostgreSQL 18 contracts
tests/unit/             Cross-cutting unit tests (the AD-1 boundary check)
tests/e2e/              Playwright journeys
.github/workflows/      ci.yml (PR gate) and release.yml (the only migrator)
.railway/railway.ts     Declared Railway shape; validated only by `railway config plan`
_bmad/                  BMAD install: config, manifests, shared Python scripts (installer-managed, read-only)
_bmad-output/           Everything the planning workflow produces (the real work product)
  planning-artifacts/
    briefs/             Product brief
    prds/               PRD + addendum + reviews + .memlog.md
    ux-designs/         UX handoff
    architecture/       Architecture spine + reviews
  implementation-artifacts/  Epic context, per-story specs, sprint status
.claude/skills/         49 BMAD skills as rendered for Claude Code
.agents/skills/         Byte-identical copy of the same skills (IDE-neutral path)
.github/agents/         Thin GitHub Copilot stubs that forward into .agents/skills/
```

Each planning-artifact folder is named `<type>-IntelliFin Audit-<date>/` — **the name contains a space**. Quote every path.

## The planning chain and its state

```
brief → PRD (+addendum) → UX handoff → architecture spine → epics/stories → sprint → build
```

Each stage carries a `.memlog.md` (append-only decision log) and, when reviewed, `review-*.md` / `recheck-*.md` files. Check a document's frontmatter `status` (`draft` or `final`) and `revision` before trusting it. A downstream artifact derived from an earlier revision is stale until re-derived; the PRD's §0 says which ones.

The PRD is the source of truth for product decisions. `prd.md` holds requirements (FR-n, NFR-n, SM-n); `addendum.md` holds normative detail (state models, Evidence Quality Gate rules, Template contracts, golden-dataset seeds, FR migration map). Read both.

## Commands

BMAD scripts run with `uv` and need Python 3.11+. Run them from the repository root.

```bash
# Resolve a skill's customization (what a skill reads on activation)
uv run _bmad/scripts/resolve_customization.py --skill .claude/skills/bmad-prd --key workflow

# Resolve the central config layers
uv run _bmad/scripts/resolve_config.py

# Append to a workspace memlog (never edit .memlog.md by hand)
uv run _bmad/scripts/memlog.py append --workspace "<artifact folder>" --type <decision|change|override|assumption|event> --text "<one line, reason included>"

# Run one skill's Python tests (tests declare their own deps via PEP 723 headers)
uv run --with pytest --with ruamel.yaml pytest .claude/skills/bmad-sprint-planning/scripts/tests/test_sprint_plan.py

# Run a single test
uv run --with pytest --with ruamel.yaml pytest ".claude/skills/bmad-review/scripts/tests/test_word_metrics.py::test_name"

# All skill tests
uv run --with pytest --with ruamel.yaml pytest .claude/skills/*/scripts/tests
```

### Monorepo commands

Node 24.20.0 and pnpm 11.25.0 exactly. Run `nvm use` (reads `.nvmrc`) then `corepack enable` first; `engine-strict` is on, so another Node major fails the install.

```bash
pnpm install                 # workspace install (--frozen-lockfile in CI)
pnpm -r typecheck            # per-package tsc --noEmit
pnpm boundaries              # AD-1 dependency-cruiser check
pnpm test                    # Vitest unit tests, no database needed
pnpm test:integration        # needs DATABASE_URL and a migrated PostgreSQL 18
pnpm db:migrate              # needs DATABASE_URL; release/CI only, never at startup
pnpm db:generate             # writes a new Drizzle migration; needs DATABASE_URL
pnpm build                   # packages then worker
pnpm dev                     # builds packages, then Next.js dev for apps/web
```

There is no lint step yet.

## Working with BMAD skills

- Invoke skills by name (`/bmad-prd`, `/bmad-architecture`, `/bmad-review`, ...). Deprecated names (`bmad-create-prd`, `bmad-editorial-review`, ...) forward to the current skill.
- Skills spawn subagents for reviews and reconciliation. Each reviewer writes its full report to a file in the artifact folder and returns only a summary; the main thread never holds full review text.
- Every product decision made during a skill run is logged to the artifact's `.memlog.md` via the script above, in the same turn it is made.
- `_bmad/config.toml`, `_bmad/config.user.toml`, and `_bmad/_config/*` are installer-managed. Do not edit; override in `_bmad/custom/config.toml` instead.

## Codebase decisions and gotchas

- **Bash `cd` persists between calls.** Use absolute paths or `...`; a relative path after an earlier `cd` will miss.
- **Planning-artifact folders have a space in the name.** Always quote paths under `_bmad-output/`.
- **Memlog writes go through `memlog.py` only.** Hand edits break the append-only guarantee the resume logic depends on.
- **Reviews are files, not chat.** Reviewer subagents write `review-<slug>.md` / `recheck-<slug>.md` next to the artifact and return a summary; the parent reads the file only when drilling into a finding.
- **Revising an upstream artifact invalidates downstream ones.** After a PRD revision, the architecture spine and UX handoff must be re-derived; say so in the PRD §0 and in the PR.
- **`.claude/skills` and `.agents/skills` are copies, not symlinks.** A change to a skill must be made in both, or re-rendered by the installer.

### Monorepo (added with Story 1.1)

- **Node 24.20.0 and pnpm 11.25.0 are hard pins.** `.nvmrc` + `engine-strict=true`. Run `nvm use && corepack enable` before any `pnpm` command; Node 22 fails the install on purpose.
- **pnpm 11 blocks dependency build scripts.** The allowlist lives in `pnpm-workspace.yaml` under `allowBuilds:` (a name-to-boolean map). The pnpm 10 keys `pnpm.onlyBuiltDependencies` in `package.json` and `onlyBuiltDependencies:` in the workspace file are silently ignored.
- **Root pins `typescript@6.0.3`, packages pin `typescript@7.0.2`.** dependency-cruiser 18.2.0 cannot use the TypeScript 7 API; with 7 at the root it cruises zero modules and exits 0. Verified twice (2026-09-02): a first TS 7 test only looked green because pnpm had left the old 6.0.3 peer linked. `pnpm boundaries` now runs `scripts/check-boundaries.mjs`, which fails on a zero-module cruise. Drop the root pin only when dependency-cruiser supports TS 7.
- **Keep `node_modules` out of dependency-cruiser's `exclude`.** Excluded paths are not rule-checked, so excluding `node_modules`, a bare `dist/`, or a bare `\.d\.ts$` silently hides vendor imports whose entry point lives there and disables the AD-1 vendor rules. `doNotFollow` is the right knob; `exclude` is scoped to `^(apps|packages)/`.
- **Workspace packages export TypeScript source for types and `dist` for runtime.** Typecheck and Vitest work from a fresh clone with no build; anything that actually runs (`apps/worker`, Docker images) must run `pnpm build` first.
- **`pnpm db:migrate` runs `packages/infrastructure/src/db/migrate.ts` over postgres.js, not `drizzle-kit migrate`.** drizzle-kit connects with `pg`, which treats `sslmode=require` as `verify-full` and so rejects Railway's self-signed certificate with `SELF_SIGNED_CERT_IN_CHAIN`; its progress spinner also overwrites the driver's error, so the release log said only "Exit status 1". CI now runs the Railway `postgres-ssl:18` image with `sslmode=require` so this fails in CI, not in a release.
- **Migrations are release-only (AD-15).** Never call `drizzle-kit migrate` from app code or a startup path. `packages/infrastructure/drizzle/0001_worker_heartbeat.sql` also seeds `schema_meta.version = 1`; bump that with the next generation.
- **`packages/domain` and `packages/application` deliberately omit `types: ["node"]`.** Without the Node ambient types, `process.env` does not typecheck there at all — the AD-11 "no ambient env inward" rule is enforced by the compiler, not only by dependency-cruiser. Do not add `types: ["node"]` to either tsconfig to silence an error; move the code that needs the environment into a composition root or `packages/infrastructure/src/config.ts`.
- **dependency-cruiser rule patterns must not nest quantifiers.** It runs every `path` regex through a catastrophic-backtracking check and, on a hit, rejects the entire rule set — the cruise then exits non-zero with "Bailing out" and no rule is actually evaluated. Prefer several simple patterns in a `path` array over one clever combined regex.
- **Never `exclude` `node_modules` in `.dependency-cruiser.cjs`.** An excluded path is not rule-checked, so excluding it (or a bare `dist/` or `\.d\.ts$`) silently hides vendor imports whose entry point lives there and disables the AD-1 vendor rules. `doNotFollow` is the right knob; `exclude` stays scoped to `^(apps|packages)/`.
- **The supported schema range is a build constant, never an environment variable.** `SUPPORTED_SCHEMA_MIN`/`SUPPORTED_SCHEMA_MAX` in `packages/infrastructure/src/db/compat.ts`. As `SCHEMA_RANGE_MIN`/`SCHEMA_RANGE_MAX` it drifted: the Story 1.2 release migrated production to generation 2 while Railway still declared `1..1`, so web refused to start against a database its own release had just migrated, and the deploy failed its healthcheck. An image ships a fixed set of migrations, so only the image knows what it supports. **A new migration must raise `SUPPORTED_SCHEMA_MAX` in the same commit**; `db/schema-range.test.ts` reads the migrations and fails when the two disagree.
- **`.railway/railway.ts` declares the intended shape; it does not apply it.** Railway variables are live state, changed in the dashboard or through the connector. Anything that must not drift between them belongs in code, not in `env:`.
- **`.railway/railway.ts` is never compiled here.** `railway` is not a workspace dependency, so no typecheck, boundary check, or test touches that file. Its only validation is `railway config plan`.

### Audit events and telemetry (added with Story 1.2)

- **The audit hash input is `previous_hash_bytes || RFC 8785 canonical JSON`, hashed once with SHA-256.** The canonical envelope has exactly eleven keys (`actor`, `aggregateId`, `correlationId`, `eventId`, `eventType`, `occurredAt`, `outcome`, `payload`, `sequence`, `sessionId`, `source`) and deliberately excludes both hashes. Never feed a caller-shaped `JSON.stringify` to the hash; `canonicalizeAuditEvent` in `packages/domain/src/audit-event.ts` is the only canonicalizer. `tests/fixtures/audit-chain-golden.json` was produced independently with Python `rfc8785` + `hashlib`; re-verify against a non-TypeScript implementation if the envelope ever changes.
- **Sequences come from a locked `audit_event_heads` row, never from a sequence object.** The append does `INSERT ... ON CONFLICT DO NOTHING` then `SELECT ... FOR UPDATE`; PostgreSQL makes the conflicting insert wait for the in-flight transaction, so two first appends to one aggregate still get 1 then 2. Events with no natural aggregate chain under `platform`.
- **Do not add `pino` or `@sentry/node` to `serverExternalPackages` in `apps/web/next.config.ts`.** They are dependencies of `@intellifin/infrastructure`, not of `apps/web`. Under pnpm's isolated `node_modules` an externalized `require` from `.next/server` cannot resolve them. Next must keep bundling them through `transpilePackages`.
- **`drizzle-kit generate` needs `DATABASE_URL` set but never connects.** Any syntactically valid URL is enough to run the CI drift check locally.
- **Next's tracing root is a filesystem path, not a URL pathname.** Use `fileURLToPath(new URL('../../', import.meta.url))`; `.pathname` leaves `%20` and a leading slash before the Windows drive letter, which caused Turbopack's path-canonicalization failure in this workspace.

### Forms and controls (added with Story 1.5)

- **Every `<form>` names its `method`, and a control that mutates state never depends on JavaScript alone.** Three times now the same defect shipped: the sign-in form had no `method`, so a submission beating hydration would have put the password in the URL; the sign-out control was an `onClick` that fetched, so a click before hydration did nothing at all and looked like success; `UserForm` then repeated the sign-in mistake with a new user's initial password. A form with no method submits as a GET, and whatever was typed lands in history, the Referer header and every access log. `apps/web/src/form-method.test.ts` scans every `.tsx` and fails on a form without one. JavaScript may enhance a control; it may never be the only path.
- **A Server Action authorizes for itself.** It is a separate POST endpoint Next exposes by id, so reaching the page that renders it is not a precondition for invoking it. The page's `requireServerAction` protects the page; each action calls it again before reading input.
- **An object lookup keyed by request input needs `Object.hasOwn`.** `ACTION_RULES['constructor']` returned `Object.prototype.constructor` and threw where a denial belonged; `SECTION_LABELS['toString']` made a function into a breadcrumb label. A plain-object index is not a map.
- **Never assert a contract against a copy of itself.** Denial strings, ribbon copy and empty-state sentences are read from the UX artifacts on disk; badge treatments are checked against the stylesheet, not the module that lists them. A test comparing a file with itself proves only that the file agrees with itself.

### Identity and roles (added with Story 1.3)

- **The role never comes from Better Auth and is never cached.** Better Auth establishes identity and session only; the role lives in the application-owned `user_role` table and `DrizzleRoleRepository.findRole` reads it on every request. A role in a cookie, a JWT claim, or an in-memory map survives its own revocation, which AD-7 forbids. `GET /api/session` is the observable proof: delete the row and the next call reports `role: null` while the session row stays.
- **Route protection is default-deny with one explicit allowlist.** `apps/web/src/route-access.ts` is the only place a path becomes public (`/sign-in`, `/api/health`, `/api/auth/**`, Next static output, root files). `apps/web/middleware.ts` is the outer gate and can only see whether a session cookie exists; the real decision is `requireAction` in `apps/web/src/require-role.ts`, which resolves the session, reads the role, applies the domain policy, and audits the refusal. Adding a route family needs no change here — it is protected already.
- **The gating table lives in `packages/domain/src/identity/roles.ts` and nowhere else.** The five denial strings are copied character-for-character from EXPERIENCE.md "Roles and Action Gating"; every unspecified cell says `Your role does not permit this action.` `roles.test.ts` checks all 24 actions x 3 roles. FR-2's "cannot approve a version they authored" is scoped to `procedure.version.approve`; rejecting one's own version stays allowed.
- **An email address cannot be an audit `actor.id`.** `SAFE_ID_PATTERN` excludes `@`. A failed sign-in for an unknown address records `actor.id: 'unknown'` with `payload.subjectHash` = SHA-256 of the lower-cased address; a known address records that user's id. The address itself never enters the chain.
- **A sign-in that cannot be audited is undone.** `apps/web/src/sign-in-route.ts` appends `security.sign-in` before returning the cookie; if the append fails it deletes the session row and answers 503. Every failed attempt is rewritten to one 401 and one sentence, so an unknown address and a wrong password are indistinguishable; a 429 keeps its status and says so, because a rate limit tells nobody whether a user exists.
- **`instrumentation.ts` must stay edge-safe.** Adding `middleware.ts` made Next compile `instrumentation.ts` for the edge runtime as well. The Node-only work lives in `apps/web/src/boot.ts` behind a dynamic import inside the `NEXT_RUNTIME === 'nodejs'` branch; a top-level import of the infrastructure barrel there pulls postgres.js, Pino and `process.exit` into the edge bundle. Next 16 also warns that the `middleware` file convention is deprecated in favour of `proxy`; the spec names `middleware.ts`, so it stays until a story moves it.
- **`apps/web` uses extensionless relative imports.** Its tsconfig is `moduleResolution: bundler`; a `./telemetry.js` specifier typechecks but fails `next build` with "Module not found".
- **Users are created by `pnpm seed:identity` only.** Better Auth has `disableSignUp: true`, so the running application has no sign-up endpoint at all; `createSeedAuth` is the one instance that can create a user and only the operator script constructs it. The password comes from `SEED_PASSWORD` in the environment, never from an argument.
- **`next.config.ts` sets `agentRules: false`.** Without it `next dev` writes its own `AGENTS.md` and `CLAUDE.md` into `apps/web`; this repository already owns both names for the agent block and this decision log.
- **A production web build refuses a plain-http `BETTER_AUTH_URL`.** Better Auth marks the session cookie `Secure` only for an https origin, so `loadConfig` rejects http when `NODE_ENV` is production — which Next's standalone server sets for itself. `http://localhost` works under `pnpm dev` only; the CI smoke container passes a placeholder `https://` origin it never has to resolve.
- **Sign-in rate limiting is declared explicitly and stored in PostgreSQL.** Better Auth's default limiter is off outside production and counts in process memory; `/api/auth/**` is the only publicly allowlisted surface and the deployment can run more than one container, so `auth_rate_limit` (generation 3) holds the counters and the rules are stated in `identity/auth.ts`.
- **The middleware matcher is `/(.*)` and decides nothing.** A negative lookahead there is a second allowlist in another language that nothing tests, and it fails exactly as a slash-less prefix does — `(?!_next/image)` also skips `/_next/imagery`. `isPublicPath` is the only allowlist.
- **The root `package.json` links `@intellifin/domain` and `@intellifin/infrastructure` as devDependencies.** Without them `scripts/*.mts` cannot resolve the workspace packages under pnpm's isolated `node_modules`.

### Application shell and Ledger Signal tokens (added with Story 1.4)

- **The design system is built here, under the parent's names.** DESIGN.md inherits the IntelliFin Design System bundle, which lives in the Business Suite repository and is not in this one, so it restates every token value it needs. `apps/web/src/design/` therefore implements Sidebar, Button, StatusBadge, Banner, EnvironmentRibbon, EmptyState, Tabs and Icon locally under exactly those names, which keeps a later swap to the real bundle an import change rather than a rewrite.
- **`ux-designs/.../DESIGN.md` is the token source; `ux-designs/.../claude/DESIGN.md` is superseded.** The `claude/` copy is the pre-revision-2 prototype contract — four state families, no `info-solid`, two dialog weights, two breakpoints. Never read it as a contract. Between the two live spines, behaviour and copy follow EXPERIENCE.md and visual values follow DESIGN.md; both beat the prototype mockup.
- **Token values live in `apps/web/app/tokens.css` and nowhere else.** Names are mechanical: `colors.<k>` → `--color-<k>`, `typography.<role>.<prop>` → `--type-<role>-<kebab>`, `rounded.<k>` → `--rounded-<k>`, `spacing.<k>` → `--spacing-<k>`. `src/design/tokens.test.ts` parses DESIGN.md's frontmatter and this file and fails on any drift; it also fails if `globals.css` restates a documented hex instead of referencing the token.
- **The status vocabulary is data, not markup.** `src/design/status.ts` holds all nine DESIGN.md rows; `StatusBadge` takes only a family and a state and derives the word, treatment and icon, so a badge without an icon or with an unknown state cannot be written. `status.test.ts` reads the markdown table off disk, so a transcription error fails rather than looking plausible.
- **Hiding a nav item is presentation; it is never the control.** The sidebar removes Administration for non-administrators via `authorizeAction`, and `app/administration/page.tsx` independently calls `requireAction` — the first production caller of the audited authorization path. Adding a privileged surface means adding the server-side call, not only hiding the link.
- **Server components reach the session through `apps/web/src/server-session.ts`.** `require-role.ts` takes a `Request` and must stay free of `next/headers` so its unit tests run under plain Node; `server-session.ts` builds a `Request` from the incoming headers and delegates. One decision path, two entry points.
- **A disabled action is `aria-disabled`, not `disabled`.** A `disabled` element cannot be focused, so its accessible description is unreachable by keyboard — which turns the required reason into the tooltip-only explanation DESIGN.md forbids. `Button` refuses activation in its handler instead, and `UnavailableActions` renders the same sentence visibly, sharing one DOM node through `disabledReasonId`.
- **The focus ring is declared once, in `globals.css`, and components have no stylesheet to suppress it in.** It is `#0F766E` everywhere, and the rule sets outline and offset only — a `border-radius` there changes every control's corner shape on focus. Inside the navy sidebar the offset is 0 and a 4px white shadow sits BEHIND the outline, so white shows at 2-4px, outside the ring: with the default 2px offset the ring is drawn at 2-4px and a white band at 0-2px sits between element and ring, leaving the ring's outer edge against navy at 2.7:1. For the same contrast reason the active nav marker on that one dark surface is `--color-teal-500`, not `--color-teal`.
- **Playwright runs `next dev`, never a production build.** A production build sets `NODE_ENV=production`, where `loadConfig` refuses the plain-http `BETTER_AUTH_URL` the suite serves on. Run `pnpm build` first: the dev server and `pnpm seed:identity` both resolve workspace packages through their `dist` output.
- **`pnpm test:e2e` needs a migrated PostgreSQL 18 and the two seeded accounts.** `E2E_AUDITOR_EMAIL`, `E2E_ADMIN_EMAIL` and `E2E_PASSWORD` name them; CI's `e2e` job migrates, seeds and installs Chromium before running. A WCAG 2.1 AA violation fails the pull request and there is no allowlist of accepted violations.
- **`text-muted` is for `surface-card` and `surface-page` only.** DESIGN.md scopes it, and the arithmetic agrees: on `surface-sunken` it is 4.39:1, under AA. An `aria-disabled` control is live text, so the disabled button writes in `text-secondary` (6.9:1).
- **`/badges` is unlinked on purpose.** It renders every badge in the vocabulary plus one live instance of each component, so axe has something to scan and the dialog specs have a dialog to open. It is protected by default-deny like every other route, and everything on it below the vocabulary is labelled illustrative.
- **Any object lookup keyed by request input needs `Object.hasOwn`.** A plain `MAP[key]` inherits from `Object.prototype`, so `key = 'toString'` or `'constructor'` returns a function and the code carries on with it. This has now bitten three times: `ACTION_RULES[action]` in the gating policy (Story 1.3), and `SECTION_LABELS[segment]` in the breadcrumbs (Story 1.4, where the segment comes straight from the URL bar). Guard the lookup, or use a `Map`.
- **`decodeURIComponent` throws on a malformed escape.** `/runs/%E0%A4%A` is a URL anybody can type; unguarded, the URIError takes down every page under the shell. Wrap it and fall back to the raw text — `readableSegment` in `apps/web/src/shell/breadcrumb-rules.ts`.
- **Copy quoted from the UX contract lives in `apps/web/src/design/copy.ts`.** A sentence typed inline in a component is pinned against nothing: the component and its test get retyped together and both drift from DESIGN.md. `copy.test.ts` reads DESIGN.md and EXPERIENCE.md off disk and requires each string character for character, the way `tests/unit/denial-strings.test.ts` does for the refusal strings.
- **A variant name needs a rule that paints it.** `status.test.ts` proves the vocabulary matches the contract and `tokens.test.ts` proves the values do; neither notices a missing class. Delete `.ls-badge--danger-outline` and four states render as plain text with the suite green. `stylesheet.test.ts` reads `globals.css` and requires a rule for every badge treatment, banner tone, button variant and shell class.
- **`aria-disabled`, never `disabled`, on an action with a reason.** A `disabled` element cannot be focused, so its `aria-describedby` reason is unreachable by keyboard — the tooltip-only explanation DESIGN.md forbids. `Button` refuses activation in its handler; `shell.spec.ts` clicks one to prove it.
- **`aria-modal` stops nothing on its own.** `ConfirmDialog` portals to `<body>`, sets `inert` on `#ls-app`, locks body scroll, and binds its key handler to `document` — a handler on the scrim element stops firing the moment a backdrop click moves focus to `<body>`, which silently breaks Escape.
- **Playwright specs sign in twice, in `auth.setup.ts`, and reuse the state.** `/sign-in/email` is rate limited to ten attempts a minute and the limiter is real production behaviour; a suite that signs in per test spends the budget and then fails on its own load. `E2E_PASSWORD` has no default, deliberately.
- **The suite must use `localhost`, never `127.0.0.1`.** Next's dev server blocks cross-origin requests to its own dev resources and does not treat the two spellings as one host: the browser is refused `/_next/hmr`, the client runtime never boots, and every page renders server-side only with no button working.
- **`pnpm -r typecheck` skips the workspace root.** `playwright.config.ts`, `scripts/` and everything under `tests/` live there, so the root `pnpm typecheck` script runs `tsc -p tsconfig.root-tests.json` after it, and CI calls the root script. That config was `tsconfig.e2e.json` and covered `tests/e2e/` alone, so `tests/unit/` and `tests/integration/` were typechecked by nothing at all — the root also has to link every workspace package those suites import, or the import resolves to nothing and the file is silently unchecked.

### Managing users and roles (added with Story 1.5)

- **A Server Action needs its own authorization check.** Next exposes each Server Action as its own POST endpoint addressed by an id that appears in the client bundle, so reaching the page it was written beside is not a precondition for invoking it. `app/administration/page.tsx` protects the page and nothing else; `app/administration/actions.ts` calls `requireServerAction` FIRST, before it reads any input, and `actions.test.ts` asserts the refusal against the action rather than the page. A validate-then-authorize action also tells a caller who may not act what the input contract is.
- **A user is created by an audited command, never by a public endpoint.** `disableSignUp: true` stays on the mounted Better Auth instance; `createSeedAuth` is the only instance that can create an account, and `BetterAuthUserCreator` builds it server-side behind `administration.users.manage`. `tests/integration/manage-users.test.ts` re-asserts that the mounted handler still refuses `POST /api/auth/sign-up/email`, because the seed instance is what every other test constructs.
- **Better Auth 1.7.2 answers a duplicate-address sign-up with a fabricated user.** No row is written, no error is raised, and `created.user.id` is a fresh id that exists nowhere — deliberate user-enumeration protection on a public endpoint, and a trap for an administrative one. `BetterAuthUserCreator` therefore checks the address before and re-reads the returned id after, and only a row that is really there counts as created. Never trust `signUpEmail`'s answer on its own.
- **A state change and its audit event share one transaction, through `PostgresIdentityUnitOfWork`.** It hands the command an `IdentityUnitOfWorkContext` in which the audit appender, `DrizzleRoleWriter`, `BetterAuthUserCreator` and `DrizzleSessionWriter` are all bound to the same handle, so there is no reachable writer outside the transaction. Better Auth joins it because the Drizzle adapter uses whatever handle it is given: `createSeedAuth(tx as unknown as Database, config)` puts the account rows inside the transaction and a rollback removes them.
- **A refusal returned from inside a unit of work COMMITS.** Everything written before it survives. `manage-users.ts` throws a private `CommandRefused` instead and converts it to a refusal outside the callback — the only way to say "this did not happen" to PostgreSQL as well as to the caller.
- **The prior role an event records is read inside the write's transaction.** A read through the pool can be answered by a snapshot the write is about to invalidate, so the chain would name a transition that never happened. `RoleWriter` carries `findRole` for exactly this.
- **Role events carry both `priorRole` and `newRole`, and `null` is a value.** A first assignment records `priorRole: null`; a revocation records `newRole: null`. The subject is a user id — an email address cannot enter the chain, and `SAFE_ID_PATTERN` has no `@`.
- **`user_role.assigned_by` is a real foreign key from generation 4, `ON DELETE SET NULL`.** `CASCADE` there would delete a role when the administrator who granted it is deleted, which is a silent privilege revocation nothing audited.
- **`DataTable`'s first-cell `href` is optional.** EXPERIENCE.md's rule is "every row's first cell is a link; no row-level click handlers", and its purpose is that a row must never be a click target a keyboard cannot reach. A table with no detail surface — the user list — satisfies it by having no target; inventing an `href` to a page that does not exist would satisfy the letter and send people to a 404. The structural guarantee is unchanged: there is no `onRowClick` prop.
- **One surface, one Banner.** `UsersPanel` owns the banner and both controls report into it. A banner per control is several live regions racing to announce the same kind of thing.
- **Sign-out revokes the session row itself, in the audit transaction.** Better Auth's own `/sign-out` commits on its own connection, so it cannot be atomic with the event. `apps/web/src/sign-out-route.ts` intercepts `POST /api/auth/sign-out`, runs `signOut` through the identity unit of work, and clears the cookies itself. If the event cannot be appended the session stays live and the caller gets a 503 — the only fail-closed direction a sign-out has.
- **A control that ends a session or mutates state must not depend on hydration.** Sign-out shipped first as a `fetch` inside an `onClick`: a click before React hydrated was swallowed — no request, no navigation, no message — so a person at a shared workstation walked away believing the session ended, and the browser test caught it only when it happened to click inside that window. It is now a real `<form method="post" action="/api/auth/sign-out">` the browser submits itself, answering a **303** to `/sign-in`; the route is idempotent, so a double submit, a resubmitted form or a second tab meets the same redirect rather than a 500. The remaining JavaScript is a double-submit guard that never prevents the first submission. `tests/e2e/administration.spec.ts` runs the journey in a context with `javaScriptEnabled: false` — the assertion that fails every time rather than sometimes.
- **A `<form>` with no `method` submits as a GET.** Any credential in it then lands in the URL, in browser history and in every access log. `sign-in-form.tsx` and `admin/UserForm.tsx` both carry `method="post"` for exactly this, even though both prevent the native submission once hydrated: the guard is for the submission that beats hydration. A POST to a page route has no handler and answers 405, which discloses nothing.
- **Sign-in and the administration mutations still require JavaScript, deliberately.** Both fail SAFE and visibly — a sign-in that does nothing leaves you on the sign-in page, and an administration mutation that does nothing shows no Banner and no changed row — which is the opposite of the sign-out defect, where nothing happening looked like success. The administration controls cannot be made to work without script at all: EXPERIENCE.md requires a focus-trapping confirmation dialog on every administration mutation. Sign-in could be made to work server-side and is worth a later story; it would mean a POST route reproducing the non-disclosure and rate-limit rules `handleAuthRequest` owns.
- **`auth.setup.ts` clears `auth_rate_limit` before the browser suite runs.** `/sign-in/email` allows ten attempts a minute and a full run spends six. CI gets a fresh database each time, but two local runs inside a minute make the second inherit the first's budget and fail on a real production rule — which reads as flakiness and is not. The limiter stays fully enabled during the run and `sign-in.spec.ts` still exercises it; only the spend carried between runs is removed.
- **Telemetry messages are an allowlist.** `TELEMETRY_MESSAGES` in `packages/infrastructure/src/telemetry/sentry.ts` is a closed union; a new `telemetry.info`/`captureError` message must be added there or it will not typecheck.
- **The unit suite now includes `apps/**/app/**/*.test.ts`.** Route handlers and Server Actions live under `app/`, not `src/`, and each is its own endpoint.

### Story 1.5 review findings (applied 2026-09-02)

- **A surface that grants roles must not be able to remove the last holder of one.** `setUserRole` refuses a self-role-change, and refuses any change that would leave zero `poc-administrator` rows. Both are enforced in the command; the disabled buttons are courtesy. The count is taken INSIDE the transaction and AFTER the write, behind a `SELECT ... FOR UPDATE` over the holders taken BEFORE it — because under READ COMMITTED two administrators demoting each other each see their own uncommitted write and count one remaining, and both commit into a deployment nobody can administer. Recovery would be shell access and `pnpm seed:identity`.
- **A lock that serializes must be taken in a deterministic order.** `DrizzleRoleWriter.lockHolders` orders by `user_id`; two callers locking the same set in different orders deadlock instead of queueing.
- **A concurrency test that starts two calls at once proves nothing.** They finish quickly enough that one commits before the other reads, and the test passes with the guard removed. `tests/integration/manage-users.test.ts` wraps the unit of work so the first transaction is held OPEN after its work and before its commit, and runs the second inside that window. Verified by removing the lock and watching it fail.
- **Never build a redirect `Location` from `request.url` or `request.nextUrl`.** Behind a proxy the host comes from the client's `Host` header, so a forged one redirects the browser to an attacker's origin — worst of all on the sign-out and sign-in-redirect paths, where the person arrives looking for somewhere to type a password. A relative `Location` is valid (RFC 9110 §10.2.2) and browsers resolve it against the origin they connected to. `middleware.ts` therefore does not use `NextResponse.redirect`, which requires an absolute URL.
- **`/api/auth/**` is an allowlist of three endpoints.** Better Auth mounts many more, and probing the real handler found `revoke-session`, `revoke-sessions`, `revoke-other-sessions`, `update-user`, `change-password`, `change-email`, `delete-user` and `reset-password` all live on the one publicly allowlisted path family, none audited — each ending a session or changing an identity with nothing in the chain. `SERVED_AUTH_ENDPOINTS` in `apps/web/src/sign-in-route.ts` names `sign-in/email`, `sign-out` and `get-session`; everything else answers 404 before the runtime is touched. An allowlist, not a denylist, so a dependency upgrade cannot mount a new endpoint into production unnoticed.
- **A Server Action's argument is untrusted, whatever its TypeScript type says.** `CreateUserFields` is a comment as far as a hand-made POST is concerned: `null`, a number or a missing field reaches `.trim()` and answers a framework 500 to the caller most likely to be probing. `actions.ts` checks shape and bounds length at the boundary — email 254, name 200, password 128, the last because scrypt cost is paid by this process and an unbounded password is unbounded cost bought with one request.
- **A refusal returned from inside a unit of work commits; a refusal thrown rolls back.** Already true of `CommandRefused`; the last-administrator and stale-role guards use the same mechanism because both fire after a write.
- **`Object.hasOwn` for any lookup keyed by request input — fourth occurrence.** `roles.ts` `roleLabelOfValue` took a `<select>` value straight into `ROLE_LABELS[...]`, where `'constructor'` returns an inherited function instead of the fallback. Previous three: `ACTION_RULES`, `SECTION_LABELS`, `ICON_GLYPHS`.
- **A guard needs its own tests, and mutation testing is how you get them.** `form-method.test.ts` asserted `/\bmethod=/`, so `method="get"` passed — the exact defect it existed to prevent — and its `<form\b[^>]*>` pattern truncated at the `=>` of a JSX handler. It now requires `post`, parses the tag brace- and quote-aware, scans `.ts` as well as `.tsx` (a route handler can emit raw HTML, and `sign-out-route.ts` does), and wraps `statSync` so a broken symlink cannot fail the suite.
- **Never assert a response equals the function that produced it.** `sign-out-route.test.ts` compared its cookies with `clearedSessionCookies()`, which proves only that the function was called. The attributes are checked one by one, `Path=/` included: `Path=/api/auth` would leave the session cookie in place on every page with every other assertion green.
- **Better Auth's session-cookie check comes before the database.** `handleSignOut` answers a caller with no session cookie from memory. `/api/auth/**` is publicly allowlisted and this handler intercepts before Better Auth's rate limiter sees the path, so sign-out is not rate limited; without the check every anonymous POST would cost a connection. An authenticated flood limits itself, because the first call deletes the session.
- **Do the risky work inside the route's own `try`.** `handleSignOut` acquired the runtime and resolved the session outside it, so a database outage threw through the route and the caller got a framework 500 instead of the fail-closed page written for that case.
- **The integration suite creates session rows directly instead of signing in.** `/sign-in/email` allows ten attempts a minute and that limiter is real production behaviour stored in PostgreSQL; six sign-ins from one file plus eight from another exceed it and the second file fails on a limiter doing its job. Only the one case that needs a signed Better Auth cookie signs in. Files clean up their own rows — scoped by an address prefix and a correlation-id prefix — and never `DELETE FROM audit_events` wholesale, which would leave `audit_event_heads` pointing past the rows that remain.
- **A test that writes to a database must refuse a database it does not recognize.** `assertThrowawayDatabase` in `tests/e2e/accounts.ts` allows loopback, a container hostname or CI; anything else refuses rather than wiping a real deployment's rate-limit counters.
- **The administrator sets every initial password, and nothing forces a change — an accepted risk.** There are no invite emails and no reset flow because this deployment sends no mail, so a PoC Administrator holds a working credential for every account they create. "PoC Administrator cannot author Procedures" is therefore a policy boundary, not a cryptographic one. Recorded in the spec's Design Notes rather than solved: a forced first-sign-in change needs a password-change command, its own event, and a gate on every surface. What is guaranteed is narrower — the password is never stored, logged, audited, echoed or placed in a URL, and the field is cleared as soon as it is used.
- **Better Auth's `signUpEmail` is not a constraint, and neither is a pre-check.** Generation 4 adds `auth_user_email_lower_uidx` on `lower(email)`, because the column's own unique index is case-sensitive and two concurrent creates of `Dana@x` and `dana@x` both pass any check. `BetterAuthUserCreator` maps SQLSTATE 23505 anywhere in the error's `cause` chain to the same "already has an account" refusal.
- **Build a privileged object only where it is used.** `PostgresIdentityUnitOfWork` constructed `createSeedAuth` — the one sign-up-capable instance — on every identity transaction, including every sign-out and every `security.denied` append. It is built lazily, only when a command actually creates a user.
- **A migration that adds a foreign key validates every existing row.** One non-matching value fails the whole migration and with it the release, so generation 4 runs a `UPDATE ... SET assigned_by = NULL WHERE ... NOT IN (SELECT id FROM auth_user)` first. It clears nothing today; it is there so data written before the column had a meaning cannot stop a release.
- **A branch nothing exercises is a branch that can be inverted silently.** `DataTable`'s first cell became a link-or-text ternary for the user list; `shell.spec.ts` now asserts the link arm on `/badges`, or inverting the ternary would turn every first cell in the product into plain text with a green suite.
- **One Banner, cleared on the next mutation and keyed by a counter.** A stale success sitting through the next attempt describes a change that is no longer in front of the person, and a live region whose text does not change is not re-announced — so two identical failures would be silent after the first. `sign-in-form.tsx` uses the same attempt counter for the same reason.
- **A glob that cannot match is a promise of coverage that does not exist.** `vitest.config.ts` briefly included `apps/**/app/**/*.test.tsx` in a `node` environment with no DOM and no such file.

### Target System registrations (added with Story 1.6)

- **There is one RFC 8785 canonicalizer, and it is `packages/domain/src/canonical-json.ts`.** `canonicalJson` was private inside `audit-event.ts` until the registration digest needed the same bytes. Both digests import it. Two copies would agree on every value anybody thought to try and diverge on the first one nobody did — an escaped lone surrogate, a `-0`, an integer past 2^53 — and each would look correct because each would be checked only against itself.
- `[EXTENDED 2026-09-07]` The envelope gained an OPTIONAL seventh key, `authentication_destination`, present only when a web registration configures one, so every pre-existing digest is unchanged; see "Epic 4 exact authentication destination" below. **`packages/domain/src/registrations/target-system.ts` is the only place the registration digest is computed (AD-2).** SHA-256 over the RFC 8785 canonical JSON of exactly six keys: `allowed_origins`, `attribute_label_patterns`, `credential_ref`, `kind`, `permitted_actions`, `secondary_key`. A `desktop` system's application identity occupies the `allowed_origins` slot, so the key set is the same for every kind. The projection is written key by key, never a spread: a spread would put the display name, the note and the id into a value a Procedure Version freezes. Nothing recomputes it on read — the adapter stores and returns the number the domain module produced.
- **Origins, label patterns and permitted actions are sets, not lists.** They are trimmed, deduplicated and sorted (UTF-16 code unit, which is what `Array.prototype.sort` does) before hashing, so retyping the same two origins in the other order does not move a digest and mint a platform-authored draft for every Procedure that references it.
- **`packages/domain` hand-rolls SHA-256 and UTF-8 (`sha256.ts`) because it has no `@types/node`.** That absence is the compiler-enforced half of AD-11 — `process.env` does not typecheck there — so `node:crypto` is unreachable and adding the types to get it would trade an invariant for a convenience. It is checked against two implementations that are not it: the Python-produced fixture, and `tests/unit/sha256.test.ts` against `node:crypto` at the block-boundary lengths (55, 56, 63, 64, 119, 120) where a padding mistake hides. `utf8Bytes` REFUSES a lone surrogate rather than substituting U+FFFD as `TextEncoder` does, because that substitution would make two different inputs hash the same.
- **`tests/fixtures/registration-digest-golden.json` is produced by `uv run scripts/make-registration-digest-golden.py`, not by TypeScript.** Python `rfc8785` + `hashlib`, the same precedent as `audit-chain-golden.json`. Its envelopes are written out by hand in the generator, so the projection is checked as well as the hash. The unit test asserts `producer` starts with `Python` — a fixture regenerated from the code under test would prove only that it equals itself.
- **A credential that cannot be proven read-only is refused exactly like one that reports write access**, with the verbatim `Audit credentials must be read-only.`, and the attempt is audited as `configuration.registration-refused`. A provider that throws is treated as `unknown` too: otherwise "the check was unavailable" becomes a path on which an unproven credential is stored.
- **The read-only refusal event is appended in its OWN unit of work, before the write transaction opens.** It must commit while nothing is stored, and those are opposite requirements for one transaction.
- **`CredentialCapabilityReport` has exactly two fields.** A reference and a verdict — there is nowhere a secret could travel, so no response, log or audit payload downstream can carry one by accident. The credential reference is deliberately absent from every audit payload as well: the chain is immutable, so anything credential-shaped that enters it can never be taken out.
- **`CREDENTIAL_CAPABILITIES` is a declaration, not a probe.** A JSON object mapping an opaque reference to `read-only` or `write-capable`, validated at boot. An absent value is an empty manifest, which refuses every registration rather than accepting every one. Reading the capability out of the reference's spelling would make the guarantee a naming convention anybody can satisfy by typing.
- **`configuration.registration-changed` (`RegistrationChanged`) is published only when one of the six moves; every other change is `configuration.registration-annotated`.** Epic 2 turns `RegistrationChanged` into a platform-authored draft, so a rename must not produce one. But the spec's first wording — a non-digest change "publishes nothing" — meant a rename, and worse a RETIREMENT, wrote a row with nothing at all in the chain, which FR-45 forbids. Two event types keep both properties: `registration-annotated` records the change and Epic 2 does not read it. A save that moves one of the six AND a display name carries both halves in the one event (`changedFields`, `annotatedFields`). A save that moves nothing appends nothing. The command asserts the converse too — if the digest moved with no field changed, it throws rather than committing.
- **`array_length(x, 1)` of an empty array is NULL, and a CHECK that evaluates to NULL PASSES.** `target_system_registration_actions_present` uses `cardinality`. Written the obvious way, the constraint accepted exactly the row it existed to refuse; the integration suite's raw-SQL insert is what caught it.
- **Generation 5's CHECK constraints are the layer nothing can route around.** `permitted_actions <@ ARRAY[...]` means no command, migration or psql session can store a write action; `digest ~ '^[0-9a-f]{64}$'` refuses anything that is not a digest. They are asserted with raw SQL in `tests/integration/registrations.test.ts`, because a constraint tested through the command proves nothing about the constraint.
- **The probe module is unreachable from `apps/` and that is a build failure, not a convention.** `packages/infrastructure/src/registrations/probe.ts` is outside every barrel, has its own `@intellifin/infrastructure/probe` subpath, and `no-target-system-probe-in-apps` fails `pnpm boundaries` on any import of it from `apps/` — the web because AD-10 forbids it an outbound call, the worker because Story 1.8 runs it as its own entry point the way the release migrator is invoked. `tests/unit/boundaries.test.ts` plants both violations. **A new subpath export needs a matching alias in `vitest.config.ts` AND `tests/integration/vitest.config.ts`**, or the import resolves to an unbuilt `dist`.
- **The connectivity column reads rows the worker writes and says "Never probed" in words.** A dash or an empty cell is something a reader takes for "fine". `target_system_probe` holds one row per registration — the present, not a history.
- **A registration is never deleted; retirement is a status.** A Run that froze a digest must still be able to resolve it.

### Story 1.6 review findings (applied 2026-09-02)

- **`JSON.stringify` escapes a lone surrogate, so a guard downstream of it can never fire.** `utf8Bytes` in `sha256.ts` refuses one and this file used to record that as the protection; on the registration path it was unreachable, because `canonicalJson` serialises strings with `JSON.stringify` first. What it cost was a row that permanently disagreed with its own digest: the digest covered the escaped form, while the driver encoded the same string for the wire with U+FFFD substitution and PostgreSQL stored that. **`canonicalJson` is now the refusal point** — for an unpaired surrogate and for a non-finite number, both of which Python `rfc8785` also refuses — and `validateRegistrationFields` turns the throw into a sentence, because it arrives through a Server Action anybody with the role can post to. A serializer that substitutes is the same defect as an encoder that substitutes.
- **What is hashed and what is stored must be the same value.** Origins and label patterns were stored trimmed but not deduplicated, while the digest hashed the deduplicated set. Removing a duplicated origin then changed the column without moving the digest, and the command published `RegistrationChanged` with `priorDigest === newDigest` — an immutable event asserting a transition that did not happen, from which Epic 2 mints a platform-authored draft for every Procedure Version. The command asserts BOTH directions now: six changed with no digest movement, and digest movement with none of the six changed.
- **An optimistic-concurrency token must cover every field the write replaces.** It was the digest, which covers six of the row's ten fields — so `displayName`, `note` and `status` were exactly the fields it could not protect. One administrator retires a registration (the digest does not move), a second saves a note from a tab opened before that, the guard passes, and the write silently sets `status` back to `active`. `registrationRowVersion` hashes all ten. Not `updated_at`: `now()` is a transaction timestamp and two concurrent transactions are not guaranteed to disagree about it.
- **A dependency-cruiser `exclude` disables every rule for the excluded path — including `dist`.** Both probe and migrator rules match `(src|dist)`, and the `dist` half was dead because built output sat in `exclude`, so an import spelled at `packages/infrastructure/dist/...` passed with a `no-orphans` warning as the only trace. Built output is now in `doNotFollow`, which keeps it in the graph. **The rule is broader than "never exclude `node_modules`": never `exclude` anything a rule's `to.path` mentions.** `tests/unit/boundaries.test.ts` plants the `dist` spelling for both rules, guarded on the file existing so a fresh clone skips rather than passes.
- **A port with no host types cannot own a timeout.** `packages/application` has no `setTimeout` — that absence is what stops `process.env` typechecking there (AD-11) — so the deadline on the credential capability check is a required `DeadlinePort` dependency: the command owns the policy, `TimerDeadline` in infrastructure owns the mechanism, and an implementer cannot leave it out.
- **A structural type does not contain anything.** `CredentialCapabilityReport` has two fields, but TypeScript's excess-property check fires only on a fresh literal assigned directly to an annotated type; a class declared `implements CredentialProvider` with an inferred return type can return a `secret` and compile. The containment is the CALL SITE destructuring the two fields it needs and never holding the report. The test that claimed otherwise built a two-key object and asserted it had two keys — a contract compared with a copy of itself. It is now a hostile provider that returns a secret anyway.
- **An answer about a different reference proves nothing.** The provider echoes the reference it was asked about and the command compares it. A real service that batches, caches by a normalized key or resolves an alias can otherwise prove a write-capable credential read-only.
- **An existence check in a separate statement prevents nothing.** `recordProbe` did `SELECT` then `INSERT`, which under a pool is not even one connection, so the row could vanish in between and raise the foreign-key error the check existed to prevent. One `INSERT ... SELECT ... WHERE EXISTS`. A raw statement has no column type to infer from, so the timestamp is sent as ISO text with an explicit `::timestamptz`.
- **`tests/unit/` and `tests/integration/` were outside every tsconfig.** `pnpm -r typecheck` covers workspace packages only, and the root's second half covered `tests/e2e/` alone. The config is now `tsconfig.root-tests.json` and covers `scripts/`, `tests/e2e/`, `tests/integration/` and `tests/unit/` — and the root has to link every workspace package those suites import, or an import resolves to nothing and the file is silently unchecked. Widening it caught four real errors immediately.
- **The constraint whose obvious spelling is wrong is the one that must be pinned.** `schema.test.ts` pinned the read-only and digest CHECKs to the migration and not the `cardinality` one — backwards, since that is where an edit that looks like a tidy-up silently removes the rule. The negative assertion strips comment lines first: the migration's own header names `array_length` to explain why it is not used.
- **A browser assertion against a page rendered before the action cannot fail.** "Nothing was stored" checked a table the server sent before the click. Every such assertion now reloads first — and a reload clears the form as well as the table, so what follows re-fills it. Likewise `'recorded in the audit chain'` matched both the published and the annotated message, so the origin-change test passed with the event never published; it asserts the sentence unique to the published path.
- **A `var(--x)` naming nothing falls back silently.** `.ls-definition dt` read `--font-size-sm`, defined nowhere, and lived on its fallback — the rule looked token-driven and was not. `stylesheet.test.ts` now requires every custom property `globals.css` reads to be defined in `tokens.css` or in `globals.css` itself.
- **A 64-character digest read aloud is unusable.** The visible text stays the full value, because that is what an auditor compares; `spokenDigest` supplies the `aria-label` — first four and last four characters, spaced — which is enough to tell two digests apart by ear.
- **`Object.hasOwn` for any lookup keyed by request input — fifth occurrence, and this time the guards got their own test.** `registrations.ts` had all four guards and nothing exercised them; inverting one now fails four cases.
- **Never `git add -A` while a reviewer subagent is planting and reverting violations.** One review's deliberate AD-10 plant was swept into a commit and pushed, and CI caught it. Stage explicit paths, or commit before the reviewers start.

### Population Source bindings (added with Story 1.7)

- **The binding digest is SHA-256 over the RFC 8785 canonical JSON of exactly `{declared_count_mechanism, declared_schema, kind, location, sensitive_fields}`**, computed by `packages/domain/src/sources/population-source.ts` and nowhere else. It uses the shared `canonical-json.ts` — the same one the audit chain and the registration digest use — and its vector, `tests/fixtures/binding-digest-golden.json`, is produced by `uv run scripts/make-binding-digest-golden.py` with Python `rfc8785` + `hashlib`, envelopes written out by hand. `tests/unit/binding-digest.test.ts` asserts `producer` starts with `Python`; a fixture regenerated from the code under test would prove only that it equals itself.
- **AD-2 names the registration digest and NOT this one.** The spine fixes the six-key registration envelope by name; for the Population Source it says only that approval freezes the binding. Story 1.7 therefore extends the mechanism by analogy — one domain function, an explicit key-by-key projection, an independently produced vector — and says so here so that a later story reconciles the two deliberately instead of discovering a second, differently shaped freezing mechanism by accident.
- **`declared_schema` is an ORDERED list; `sensitive_fields` is a SET.** They are the two opposite normalization rules in one envelope, and each has a golden vector that fails if they are swapped. A schema declares field POSITIONS — `[account, amount]` is not `[amount, account]`, and a parser told the second reads the wrong column — so reordering it moves the digest. Masking asks only whether a field is in the group, so reordering that does not, and a digest that moved would mint a platform-authored draft over nothing. Both are trimmed, blank-free and deduplicated; only the set is sorted.
- **`sensitive_fields <@ declared_schema` is a CHECK constraint, not only a command rule.** A mask over a field the schema does not declare hides nothing while reading, in a list view, exactly like protection (FR-41). The command refuses it and the database refuses it, and `tests/integration/sources.test.ts` asserts the constraint with raw SQL — a constraint tested through the command proves nothing about the constraint.
- **`cardinality`, never `array_length(x, 1)` — second occurrence.** `population_source_binding_schema_present` would otherwise accept exactly the row it forbids, because `array_length` of an empty array is NULL and a NULL CHECK PASSES.
- **`declared_count_mechanism: 'none'` is SAVEABLE and warns.** FR-6 requires the absence to be surfaced at authoring time, and a binding that cannot be saved cannot be surfaced: nobody can see what is missing on a binding that does not exist. The warning is EXPERIENCE.md's sentence — `DECLARED_COUNT_MISSING_SENTENCE` in `apps/web/src/design/copy.ts`, checked against the artifact on disk — and it appears on the form as the mechanism is chosen and in the list's Declared-count column. The label is "None declared" in words; a dash or an empty cell is something a reader takes for "fine".
- **A `manual-upload` binding has NO location, and the database enforces both directions.** The file arrives with the Run, so the form hides the field, the command clears it and the digest stores `null`. `population_source_binding_location_matches_kind` refuses a manual upload that names one AND a versioned file or API that does not: the first would put a value in the row that the frozen contract does not carry, the second points at nothing.
- **The action is `administration.bindings.manage`, not `administration.sources.manage`.** The spec names the latter; the gating table in `packages/domain/src/identity/roles.ts` is transcribed character for character from EXPERIENCE.md and already carries the former (UX-DR39). The contract wins — `roles.test.ts` asserts all 24 actions against all 3 roles, so a second name for one surface would break a completeness claim.
- **`bindingRowVersion` covers all nine stored fields and NOT the derived digest.** Same lesson as `registrationRowVersion`: the display name, the note and the status sit outside the digest, so they are exactly the fields a digest-shaped token cannot protect — a stale tab would silently un-retire a binding. The digest is omitted because it is derived from five of the nine, so including it adds nothing and re-couples the token to the digest function.
- **There is no file input on this surface, and no credential field.** This story registers a BINDING; acquiring, parsing and snapshotting the population belongs to Epic 2's Adapters. A `read-only-api` binding names a location only — the credential a Run uses comes from the Target System registration, which already proved it read-only, and a second place for that reference would mean a second place the proof has to be repeated. `sources.spec.ts` asserts `input[type="file"]` has count 0.
- **A stale-row test that starts two changes at once proves nothing.** They finish quickly enough that one commits before the other reads, and the test passes with `SELECT ... FOR UPDATE` removed. `tests/integration/sources.test.ts` holds the first transaction OPEN after its work and before its commit, and runs the second inside that window — the same shape `manage-users.test.ts` uses.
- **A new table means `tests/integration/schema-compat.test.ts` must list it.** That test asserts the EXACT set of public tables, so it fails on any migration until the new name is added — which is the point: an unlisted table is a migration nobody reviewed.

### Story 1.7 review findings (applied 2026-09-02)

- **`aria-label` on a `<span>` or a `<dd>` is never applied.** ARIA prohibits an accessible name on a generic element, so both digests' labels were silently dropped and the accessible name stayed the sixty-four hex characters — the exact thing the label was added to prevent. axe reports `aria-prohibited-attr` as **incomplete**, not as a violation, and the browser gate asserts only `results.violations`, so the accessibility check could not see it. `apps/web/src/design/Digest.tsx` is now the one way a digest is rendered: the full value with `aria-hidden`, beside a `.ls-visually-hidden` sentence. No ARIA role, so no role rule can drop it, and `Digest.test.ts` scans every `.tsx` under `apps/web` and refuses `aria-label` on any element that cannot carry one.
- **A NUL is valid JSON and unstorable.** `U+0000` canonicalizes and hashes cleanly, then PostgreSQL raises `22021 invalid byte sequence for encoding "UTF8": 0x00` at the driver and the caller meets a framework 500. `canonicalJson` refuses it, next to the lone-surrogate refusal, because a value with no storable form has no canonical form.
- **`cardinality(x) >= 1` counts ELEMENTS, not names.** `ARRAY[NULL]` and `ARRAY['']` both satisfy it, and a NULL element then leaves the repository typed `string[]`. The NULL test that works is `array_position(x, NULL) IS NULL`: `NULL <> ALL(x)` returns NULL, and a NULL CHECK PASSES — the same trap `array_length` sets, one operator along. `<@` is NULL for the same reason when its left array holds a NULL.
- **`SUPPORTED_SCHEMA_MIN` must be a range the build can actually serve, so it equals `SUPPORTED_SCHEMA_MAX`.** It read `1`, which claimed a generation-6 image could serve a generation-1 database; every generation since has added a table the build queries unconditionally, so the image passed the AD-15 guard and then failed per request on a missing relation. A range wider than the truth turns a startup guard into a delayed crash. The cost — a rollback to an older image refuses to start against a newer database — is the direction a fail-closed guard should fail.
- **A malformed id is absence, not a 500, and the guard belongs in the repository.** PostgreSQL raises `22P02` comparing a `uuid` column against text that is not one, and that id comes from a URL segment. `isUuidText` in `packages/infrastructure/src/db/identifier.ts` is checked by every lookup-by-id, because a guard each page must remember is one the next page forgets.
- **A save that changes nothing writes nothing.** The UPDATE was unconditional, so an idle submit moved `updated_at` and left a row whose "Last changed" said somebody changed it, with no event saying who or what.
- **A normalisation the digest performs must be pinned on the STORED column too.** With `setOf` no longer sorting, every unit test stayed green while retyping the same masked fields in another order rewrote the row, moved the row version and appended no event. The database CHECK is order-blind and is no backstop.
- **A form must not default to its most restricted option.** The kind vocabulary is ordered `manual-upload, versioned-file, read-only-api`, so `OPTIONS[0]` opened every create form on the restricted kind — showing a restriction banner to somebody who had chosen nothing, and making two browser assertions true before the selection they were testing.
- **Playwright restarts its worker after a test failure, which runs `afterAll` early.** A later test then sees a cleaned database and fails for a reason that has nothing to do with it. Read the FIRST failure in a run; the ones after it may be its shadow.
- **A story that repeats another's shape inherits its defects.** Four of Story 1.7's findings were Story 1.6 defects found only because the same code was written twice. Fix them in the story that finds them.
- **A manifest keyed by a NORMALIZED value must refuse duplicates, not take the last one.** `CREDENTIAL_CAPABILITIES` trimmed each key and then `Map.set` it, so `{"prod":"write-capable"," prod":"read-only"}` yielded `prod -> read-only` — a later entry silently replacing an explicit write-capable declaration, and registration input is trimmed too, so `prod` was then accepted as PROVEN read-only. Fail-open in the one guarantee the manifest exists to provide, and invisible: the two keys look different in the JSON. A deployment whose declaration is ambiguous has declared nothing, so the whole manifest is refused and the process does not start. Found by an automated reviewer on the Epic 1 pull request, after ten of my own review passes had not.

### Synthetic Northstar systems and golden populations (added with Story 1.8)

- **`fixtures/northstar/` is three folders and one generator.** `datasets/` holds the golden populations and the systems' own content, hand-written as DATA. `expectations/` holds what a Run SHOULD conclude, per addendum §D case, versioned separately so nothing that evaluates a rule validates a Result against the implementation that produced it (AD-12). `generated/` holds the cover sheets, the served file artifacts and the declared counts, and is NEVER hand-edited. `uv run fixtures/northstar/generate.py` writes it.
- **A declared count is generated, never typed.** A number typed beside the rows it counts is wrong the first time somebody edits the dataset, and a Gate reconciling against a stale declaration reports a truncation that never happened. `generate.py` derives every count and every digest in Python; `apps/northstar/src/fixtures.test.ts` recomputes both in TypeScript with `node:crypto`. Two implementations, so drift fails a test instead of an Epic 2 Adapter.
- **A cover sheet's digest is over the bytes actually served.** `apps/northstar` reads the artifact out of `generated/` and streams it unchanged. A digest over the dataset, or over a re-serialization, would be a digest of something nobody can fetch.
- **`generated/leavers-export-truncated.*` and `leavers-export-2026-07.*` are seeded failures, not mistakes.** The first is a cover sheet declaring the FULL export over a short file (addendum §D's incomplete population); the second is the previous generation, effective through July (the stale one). Both carry `seeded_case`, and the tests assert the mismatch rather than the match.
- **The read-only rule is applied ONCE, above routing, in `apps/northstar/src/server.ts`.** It refuses any operation a route has not DECLARED non-mutating, answering 405 with the route's own `Allow` and a body naming FR-3 — including on a path no route serves, because "there is nothing here" and "this system does not accept that" are different statements to a Run. It read "any method but `GET`/`HEAD`" until 2026-09-06, when the owner corrected the predicate: see "Read-only means no mutation of audited business data" at the bottom of this file. `read-only.test.ts` walks the exported `ROUTES` table and asserts BOTH directions, so a route added later is covered the moment it exists; every `Route` must declare a `probe` path, and `routes.test.ts` proves each probe matches its own pattern and is not shadowed by an earlier route.
- **Seeded prompt-like strings are served VERBATIM as data.** HTML entity-encoding is a transport encoding, never a redaction: `server.test.ts` decodes the page and compares byte for byte with the dataset value. Escaping one away at the fixture would delete the test.
- **LoanCore requires a credential, and since 2026-09-06 it takes it through a real sign-in FORM.** `[SUPERSEDED]` This note first said LoanCore had no form because a sign-in is a POST and `enforceReadOnly` refused every method but GET and HEAD; the owner overturned the rule that made that true. `/loancore` serves the form to a caller with no session, `POST /loancore/sign-in` is the ONE route on that process declaring a POST non-mutating, and the submission grants the session cookie. Every other `/loancore` path answers **401** with a `WWW-Authenticate` challenge NAMING THE FORM and a JSON body in the shape the 405 denial already uses. There is no header sign-in left: leaving one would make the form decorative, and the suite would pass with the form deleted. Applied above routing for the same two reasons read-only is: a route added later cannot forget it, and an unauthenticated request to a path no route serves is told it is unauthenticated rather than told the path is empty. The original note said the audit account was ALREADY signed in; that is superseded, because Story 4.2 has to sign in and Story 4.11 has to assert that no credential reaches an artifact — against a system with no credential in play, that assertion passes because nothing happened. Its second half stands unchanged and is exactly why the credential here is INVENTED and declared in `fixtures/northstar/datasets/systems.json`: registering a real credential is the one thing this environment must not have. Only LoanCore; every other synthetic system stays unauthenticated, or every Epic 3 adapter test would carry a credential for no reason.
- **`apps/worker/src/probe.ts` does not exist, and cannot.** `no-target-system-probe-in-apps` fails the build on any import from `apps/` of anything matching `packages/infrastructure/(src|dist)/registrations/probe` — which is a PREFIX, so it covers `probe-runner.ts` too. The sweep therefore lives at `packages/infrastructure/src/registrations/probe-runner.ts`, beside the writer it uses and exactly where `db/migrate.ts` lives, and is started as its own process: `pnpm --filter @intellifin/worker probe` forwards to `node dist/registrations/probe-runner.js`. `tests/unit/boundaries.test.ts` plants both spellings from both apps. Do not add an entry point under `apps/` and weaken the rule to fit it.
- **The probe does `GET`, once, bounded, with `redirect: 'manual'` and no credentials.** Following a redirect would let a registered origin send the worker somewhere nobody allowlisted. It records `reachable` or `unreachable` and nothing about what it saw; `target_system_probe` has four columns and `northstar.spec.ts` asserts that against `information_schema`. A retired registration and one with no probeable origin (a `desktop` system) are not probed at all — the surface keeps saying "Never probed", which is true.
- **`sanitizeTelemetryFields` drops an undocumented key SILENTLY.** The sweep shipped one run logging "Probe sweep complete" with every count removed, and the migrator's "Refusing to migrate" had lost its reason the same way. `probed`, `probeReachable`, `probeUnreachable`, `probeSkipped` and `reason` are now in `TELEMETRY_FIELD_KEYS`, and `telemetry.test.ts` pins them. A new log field needs a new key there or it is not logged.
- **One process serves every synthetic system, so an ALLOWED ORIGIN here is a base URL that includes the path prefix** (`http://localhost:4300/loancore`). Six services is a Railway decision this story was not permitted to take, and six processes make the browser suite six times as fragile. Nothing downstream cares: a registration's origins are opaque strings the probe and the agent both treat as a base to fetch.
- **`scripts/seed-northstar.mts` registers through the Story 1.6 and 1.7 COMMANDS, never through SQL**, so a seeded row is audited exactly like one a person typed and a seeded row that could not be audited does not exist. It reads `fixtures/northstar/datasets/systems.json` — the one catalogue both it and the Northstar index page use — and re-running leaves an already-registered system alone. Every event it appends carries a `seed-northstar:` correlation-id prefix.
- **Playwright now starts TWO servers**, and `pnpm build` is a precondition for both: `pnpm --filter @intellifin/northstar start` runs `node dist/main.js`. `tests/e2e/northstar.ts` holds the port, the base URL and the verbatim denial rule, and has no side effects — `playwright.config.ts` imports it, and a module-level throw there would make the config unloadable.
- **`apps/northstar` builds through `tsconfig.build.json`**, which excludes `*.test.ts`, while `tsconfig.json` includes them so `pnpm -r typecheck` checks them. A build config that excluded them from both would leave the tests unchecked by anything.
- **`[DEFERRED to Epic 7]` LedgerDesk** (the desktop Target System) and **`[DEPLOYED 2026-09-08]` a Railway service for Northstar** — the `northstar` service existed on Railway since 2026-09-04 and Codex deployed `70497eb` to it (deployment `65c63c65`, SUCCESS) with owner authorization; `https://northstar-production-b312.up.railway.app` serves `/health` and the real LoanCore sign-in form, which is what let the live Solari runs reach the synthetic systems. The first needs a desktop sandbox; the second is the user's call and `.railway/railway.ts` gains nothing here. This note used to say "so Epic 3 picks them up deliberately", which was wrong twice over: Epic 3 came and went without it, and `epics.md` places the desktop kind in **Epic 7** (`FR7: … desktop kind completed in Epic 7`; `FR20: Epic 4 (web path) and Epic 7 (desktop path)`), which is the authoritative record. The owner reaffirmed Epic 7 on 2026-09-06. `fixtures/northstar/datasets/systems.json` still says "Epic 3" and `_bmad-output/implementation-artifacts/deferred-work.md` does not name the deferral at all — reported to the owner rather than edited, because they are planning artifacts and the disagreement is the finding.

### Story 1.8 review findings (applied 2026-09-02)

- **`import.meta.main`, never `process.argv[1] === fileURLToPath(import.meta.url)`.** Those two are not the same test: `import.meta.url` is the RESOLVED path, `argv[1]` is the path as invoked, and through a symlink they differ. pnpm's `node_modules` is symlinks and so is any `--prod deploy` tree, so the comparison is false, the module loads, does nothing and exits 0. Both entry points that guard this way are release paths — `db/migrate.ts` and `registrations/probe-runner.ts` — and for the migrator it means a release reporting success against an unmigrated database, after which every process refuses to start on a schema range it does not have. `packages/infrastructure/src/db/entry-point.test.ts` runs a real file through a real symlink, because the behaviour under test is Node's, not ours.
- **A background job must not borrow a surface's read.** The probe sweep used `listRegistrations`, which is capped at `REGISTRATION_LIST_LIMIT` and includes retired rows — both correct for a screen. With more retired registrations than a page holds, every live system fell off the end and the sweep probed nothing while exiting 0. `listActiveProbeTargets` is the job's read: active only, unpaged, and only the columns a probe needs.
- **`fetch` resolves on headers; an unread body holds the socket.** A timeout around `fetch` bounds the FETCH, not the process. A target that answers and then holds its body kept the probe alive 105 seconds past its own completion log, and unboundedly against a server that never closes. `controller.abort()` in the `finally` releases it and is a no-op on a request that already finished.
- **`sanitizeTelemetryFields` drops an undocumented key silently, so the parameter must be typed.** `fields?: unknown` let `telemetry.info('...', { workerGeneration: 7 })` typecheck and emit with the value gone. It happened twice before anyone noticed — the probe sweep logged every count removed, and the migrator's refusal lost the reason that said why. `TELEMETRY_FIELD_KEYS` is the runtime guard; `fields?: TelemetryFields` is the compile-time one, and both are needed.
- **A test that walks a hard-coded list of folders enforces the list, not the rule.** `synthetic-marker.test.ts` named three folders, so a planted fourth with a real bank domain, an email address and an account-shaped number passed 98/98. NFR-13 covers the fixtures, so the walk starts at the fixture root and subtracts an allowlist of tooling files. An allowlist of exclusions, never an allowlist of folders.
- **A golden case must be able to FAIL for the reason it exists.** Addendum §D's ambiguous-role record was Active, so C1 made it an Exception whichever way C2 went — and C2 was the case. It is Disabled now, like its sibling, so the ambiguity is the only thing left to decide.
- **A seed script that keys idempotency on a name must say when the row differs.** Re-running with a different base URL printed "seeded … against <the new URL>" while every row still named the old one. It does not silently repoint them either: an origin is digest-bearing, so changing it mints a platform-authored draft for every Procedure that froze it.
- **The Northstar read-only rule is middleware above ROUTING, and the test walks the route table.** A write to a path no route serves must be refused, not 404'd: a 404 says "there is nothing here", a 405 says "this system does not accept that, and here is the rule", and only the second is something a Run can record.
- **Declared counts and cover-sheet digests are generated from the datasets, never typed beside them**, and the digest is over the bytes actually served. Python generates, TypeScript recomputes with `node:crypto`; two implementations must agree or a test fails.
- **The Leavers export is CSV, not the addendum's `.xlsx`.** A valid xlsx needs a zip writer, nothing parses it yet, and the spec asks only for files with signed cover sheets. **LoanCore served the audit account as already signed in**, because a sign-in form is a POST that its own read-only rule refused — `[SUPERSEDED]` twice: by Story 4.2's credential, and then by the form the corrected read-only predicate allows. **LedgerDesk and the Railway deployment of the Northstar service are deferred**, both named.
- **Two agents planting boundary violations collide.** `tests/unit/boundaries.test.ts` uses one fixture directory name, so a second concurrent run of it fails for a reason that is not a defect. Read the FIRST failure, and do not run it while a reviewer is planting. Standalone `pnpm boundaries`, builds and typechecks must also wait for this module to finish: a full unit run temporarily contains deliberate illegal imports.

### Procedures and Templates (added with Story 2.1)

- **The four Template contracts are build constants in `packages/domain/src/procedures/templates.ts`, not rows.** AD-2 says the module owns its data; it does not say where. A Template row an operator could edit would let a deployment drift from the addendum §C contract its own tests assert. `tests/unit/procedure-templates.test.ts` reads the addendum off disk and pins every default verbatim, so transcription is a testable claim. Revisit only if a story wants operator-editable Templates — and then change the migration, the CHECK and this note together.
- **The `procedure_version.state` CHECK carries the WHOLE §E vocabulary from the first commit**, and the permitted-transition table lives in the domain as data beside it. A machine that grows one arrow per story ends up with no machine at all. Story 2.1 writes only `DRAFT`.
- **The section payload is `jsonb NOT NULL` and never read untyped.** The domain owns `isValidDraftSectionsPayload`; the repository reads a row whose payload fails the validator as NOTHING. Stories 2.2–2.6 each promote their part of it to typed columns as they author the section — a migration per section, not one invented up front.
- **The payload validator is structural, not a re-derivation.** It checks shape and Builder order, not equality with the Template — the moment a section becomes editable the draft must hold what the auditor saved. "The pre-fill equals the Template record" is a claim about what CREATION writes, and it is tested in the command's tests, not enforced by the validator.
- **A refusal is thrown from inside the unit of work, never returned from it.** Same lesson as Stories 1.5–1.7: a returned refusal commits what came before it. `renameProcedureDraft` throws its private `CommandRefused` and converts outside the callback.
- **The rename returns the new row-version token.** The surface adopts the token over the row as the command LEFT it, so the next save guards against the row as it now is. Recomputing the token anywhere else would be a second implementation of it.
- **The Template picker has no default selection.** Story 1.7 shipped a form defaulting to `OPTIONS[0]` and two browser assertions were true before the selection they tested. An unchosen select posts an empty string, which the boundary refuses as a missing value — never as `P-1`.
- **Breadcrumbs for a Procedure detail page are rendered BY the page**, via `src/procedures/DetailTrail.tsx`. The shell's `Breadcrumbs` reads only the pathname, and UX-DR7 puts the Control name in the trail — which the shell cannot know. `/procedures/[id]` and its Builder render their own trails server-side; do not try to thread the name into the shell.
- **`displayStateOf` in the command module and `displayVersion` in the repository both compute "ACTIVE, else newest".** The duplication is deliberate and tested on both sides: the repository's is the read path, the command's is exported for callers that hold versions in hand; a third copy is not wanted.
- **Telemetry messages for Procedure commands are in the closed union** (`'Create Procedure failed'`, `'Rename Procedure Draft failed'`). A new command's failure message needs a new entry or it will not typecheck — same rule as every story since 1.5.

### Population authoring (Story 2.2)

- **A Draft retains its source snapshot explicitly.** A new binding selection is resolved through the source-owned `PopulationSourceReader` under a shared row lock and must match the rendered digest; retaining a saved snapshot never resolves or rewrites its historical contract after retirement.
- **Period, scope, source snapshot, inclusion rule and both Gate flags are part of the full version token.** The Builder shares each command's returned token across its editors; an edit to one section must make an older tab's edit to another section stale.
- **Inclusion rules are schema-version-1 typed data.** Decimal constants remain strings; UTC Period dates are real Gregorian date-only values. P-1 explicitly maps `termination_date` prose to `termination_effective_date`; a replacement source keeps incompatible clauses visible for the author to select a declared column. No automatic include-all fallback or name mapping.
- **Generation 8 backfills Template rules without binding a source.** The runtime requires schema 8 because the new version columns are read unconditionally. Only the existing release/CI migrator applies the SQL.

### Story 2.1 review findings (applied 2026-09-04)

The implementing agent could run neither `pnpm test:integration` nor `pnpm test:e2e` — no hostable PostgreSQL, and `next build` fails from a path containing a space — and said so plainly rather than claiming a result it had not seen. Everything else it reported reproduced exactly. Both gates were run here against a real PostgreSQL 18.6: **5 integration failures and 7 browser failures**, none of which any other gate could have caught.

- **"Active version" must mean ACTIVE, or the card states a fact that is not true.** `displayVersion` fell back to the newest version when none was `ACTIVE`, and the card printed it under the cell UX-DR7 labels "Active version" — so a Procedure whose only version is a Draft rendered **"Active version: Draft"**. Story 2.1 writes only `DRAFT`, so that was every Procedure in the product. It is worse than the dash the card's wording rule forbids: a dash reads as "nothing here", while a state reads as a fact. `activeVersion` now returns the ACTIVE version or nothing, and a later story wanting "the newest version whatever its state" wants a differently-named field.
- **Two `<nav aria-label="Breadcrumb">` on one page are two landmarks nobody can tell apart.** The shell renders a trail on every route and `DetailTrail` added a second, whose whole purpose is to carry the Control name the shell can only show as a UUID. `DetailTrail`'s own comment said matching the shell's `aria-label` meant "a screen reader hears one kind of navigation, not two" — exactly backwards. **The accessibility gate cannot catch this**: `landmark-unique` is a best-practice rule, not WCAG-tagged, so it never reaches `results.violations`. `rendersOwnTrail` in `breadcrumb-rules.ts` is now the one place that knows a page trails itself, and the shell stands down there.
- **`aria-hidden` on the only sentence that says a section is read-only tells a screen-reader user the opposite of what the page tells everyone else.** They meet section after section of content with nothing saying any of it cannot be edited. Nothing could catch it — axe has no rule for a page hiding its own content, and the browser suite asserted the sentence was *visible*, which `aria-hidden` does not affect. The guard is a source scan, in the spirit of `Digest.test.ts` and `form-method.test.ts`.
- **A validation rule belongs in the function every path shares, not at one call site.** The storability check ran in `validateCreateProcedureInput` only, so a rename carrying a NUL or a lone surrogate reached the transaction and threw a raw `NotCanonicalizableError` — a framework 500 where the spec's matrix requires a sentence. It is inside `validatedControlName` now, which every path that stores a Control name already goes through.
- **The Builder header showed the name the Draft used to have.** `renameProcedureDraft` is scoped to the version deliberately — the Procedure row is untouched, and `create-procedure.test.ts` asserts that by name — but the header read `procedure.controlName`. So the rename committed, the chain recorded it, the banner said "The Control name is now …", and the heading directly above the field that had just changed it still said the old one. The header reads `draft.controlName`. **The design decision underneath it is still open**: `procedure.control_name` is set once at creation and nothing can ever correct it, which Story 2.8 should settle deliberately rather than inherit.
- **A denial string was retyped in three places and was wrong in all three.** Two suites expected the generic `Your role does not permit this action.` for a PoC Administrator attempting `procedure.author`; the gating table and EXPERIENCE.md both give that cell its own sentence. The production code was right. All three now read `DENIAL_REASONS.ADMIN_CANNOT_AUTHOR` — a fourth retyping is a fourth chance to get it wrong.
- **A test that has never been run is not a test.** Every integration failure was a defect in the new test file rather than in production code — a `{templateId, sections}` wrapper the writer never stored, a heading asserted on the surface that does not render it — and each would have failed on its first execution. The mutation-testing rows that named `tests/integration/procedures.test.ts` as their killing suite were recorded as passing without that suite ever running.
- **A brittle row count makes the next test the breaking change.** `expect(rows[0]?.c).toBe(created.length)` counts every Procedure the file created, so adding any test that creates one breaks a test that has nothing to do with it. New assertions were folded into a case that already creates a Procedure instead.
- **`git checkout -- <file>` reverts the fix, not just the mutation, when the fix is uncommitted.** Copy the file aside and restore from the copy when mutation-testing work that is not yet committed.
- **PostgreSQL 18 in this container dies under load and takes the whole suite with it.** Every integration file failing at once with `ECONNREFUSED` is the cluster, not the code: restart with `su postgres -c "pg_ctl -D <data> -o '-p <port>' start"` and re-run. Initialise it with password auth, never `--auth=trust`: `migrate.test.ts` proves the migrator reports a driver error by connecting with a wrong password, and trust auth accepts it, so the test fails for a reason that is not the code's.

### Target System selection and Audit Instructions (Story 2.3)

- `[EXTENDED 2026-09-07]` Six keys, plus the optional `authentication_destination` when configured. **A Procedure Version freezes the stored registration digest and its six-key envelope.** `snapshotFromRegistration` preserves the stored digest; `isProcedureTargetSnapshot` checks it through the registration-owned digest function and refuses an inconsistent contract. Never silently repair the registration while selecting it. Audit payloads omit the contract and identify instructions by text digest and length, so even a credential reference typed into instructions remains outside the immutable chain.
- **`procedures` reads registrations only through a registration-owned port.** `TargetSystemRegistrationReader.lockForSelection` (application port; `DrizzleTargetSystemRegistrationReader` in `registration-repository.ts`) reads the selected ids `FOR SHARE ORDER BY registration_id` — sorted, so two concurrent saves locking overlapping sets queue instead of deadlocking, the `DrizzleRoleWriter.lockHolders` discipline. It is bound into `ProceduresUnitOfWorkContext` beside `populationSources`, exactly as `DrizzlePopulationSourceReader` is. A Draft never reads the registration table directly (AD-2).
- **`listActiveRegistrations` is active-only and unpaged.** The administration list includes retired rows and has a display limit. Reusing either that list or its limit hides eligible registrations from the Builder; the picker must offer every active system until it has an explicit paging contract.
- **Two edits, one command (`updateTargetDraft`), the `updatePopulationDraft` shape.** `target-systems` saves the ordered, unique selection (a `bind` resolves fresh and requires active status + the rendered digest; a `retain` keeps the saved snapshot verbatim and never re-resolves it, which is how a Draft holds a system after its registration changed or retired). `audit-instructions` saves verbatim per agent-driven system. A target-save prunes instructions for a now-unselected system (not a refusal — deselecting legitimately drops the instruction); an instruction for an unselected or API/file system on the instruction-save IS a refusal (orphan). Both guard the whole row via `procedureVersionRowVersion` (which now covers `targets` and `instructions`), refuse a non-DRAFT and a stale token, and commit with one `lifecycle.procedure-draft-changed` event.
- **Clearing is an edit and must pass the same checks.** `validateDraftTargetEdit` checks shape, ids, duplicates, bounds and storability after authorization. Membership is checked against the locked Draft before blank text is removed; an empty orphan or duplicate entry must not bypass validation.
- **The signed Northstar CSV artifacts need LF bytes on Windows too.** `.gitattributes` pins their line endings; after an older checkout has converted them, `uv run fixtures/northstar/generate.py` restores the signed bytes without changing seed data. Run builds and type checks after the unit suite finishes: its boundary tests temporarily plant invalid imports in source folders.
- **The scope-widening check is a pure domain function and advisory only (FR-8).** `scopeWideningWarnings(text, systems)` names the write verb (SW-2), the out-of-scope origin (SW-3), and the unregistered system (SW-1); it NEVER refuses a save and is NEVER a submission blocker — `updateTargetDraft` does not consult it. Write verbs are `MUTATING_VERBS` plus `disable` and a few more (`MUTATING_VERBS` deliberately omits `disable` because no permitted action was ever spelled that way), matched WHOLE-WORD so `disable` flags "disable it" and not the read-only status label "disabled" — the false positive the acceptance criterion forbids. Origins match by authority + path boundary (`/loancore-other` is outside `/loancore`); system names match internal-caps tokens (LoanCore, PayrollVault) against the selected systems' display names. The fixture-driven proof lives in `tests/unit/scope-widening.test.ts` (the domain package reads no files); the golden fixture's "refuse to compile" prose was superseded by FR-8 to "flag inline", ids and execution outcomes preserved.
- `[SUPERSEDED 2026-09-07]` `targetBlockersFor` now returns only `targets-missing`; the `web-`/`desktop-coverage-missing` blockers were removed because Addendum C names LoanCore and LedgerDesk as DEFAULTS, not a mandate, and the desktop path is Epic 7. See "Explicit target scope in P-1" below. **Completeness diagnostics are distinct from scope warnings and derived, not stored.** `targetBlockersFor(templateId, targets)` returns `targets-missing`, then `web-coverage-missing`/`desktop-coverage-missing` for the agent-driven kinds the Template's new `defaultTargets` names (P-1 names both). It is computed on read in the repository and lives on the view, not on the row — a function of `targets` + `templateId`, both already in the row-version token.
- **Generation 9 adds `targets` and `instructions` jsonb columns to `procedure_version`.** The CHECKs are shallow (`jsonb_typeof = 'array'` + length ≤ 32, `coalesce(..., false)` for NULL safety); the deep validation — every snapshot self-consistent, every instruction for a selected agent-driven system — is `isDraftTargetFields`, which a raw writer cannot be made to run and which makes a bad row read as nothing. `SUPPORTED_SCHEMA_MIN`/`MAX` are 9; the migration hand-appends `INSERT INTO schema_meta VALUES (9)` as always.
- **The Target System and Audit Instructions sections are editable now, so five Builder sections stay read-only** (Control, Objective, Compliance Rule conditions, Evidence Requirements, Schedule) — `procedures.spec.ts` asserts `toHaveCount(5)`. All Builder editors SHARE one row-version token held in `DraftBuilder`: a save through any of them (`saveTargets` wrapper included) moves the token every other editor guards against. The instruction editors key off the SAVED `draft.targets`, so selecting systems and writing their instructions are two saves, and the second sees the first through revalidation.
- **LedgerDesk (the P-1 desktop) is still deferred; the desktop path is tested with a registered synthetic desktop.** `fixtures/northstar/datasets/systems.json` has no desktop system, so the integration and e2e suites register one directly (`com.northstar.ledgerdesk` as the application identity — which occupies the `allowed_origins` slot in the envelope). NFR-11's responsive floor is `BUILDER_DESKTOP_ONLY_SENTENCE` in `copy.ts`, shown below 900px via `.ls-desktop-only`.
- **Verify against PostgreSQL 18, including the migrator and schema gate.** Story 2.3 was verified against an isolated PostgreSQL 18.3 database at schema generation 9: all 126 integration tests passed, including 34 procedures tests. A transaction-race test must observe the competing query waiting on a database lock before releasing the first writer; merely starting a promise does not prove that the operations overlapped.
- **A Builder refresh must preserve dirty authoring fields.** Target selections and per-system instruction text merge returned Draft state only when the field is clean or the server has caught up to the local value. Template prose remains visible as a read-only reference and is copied only by an explicit action; clearing saved instructions must not resurrect defaults. Below 900px, `.ls-builder-authoring` is hidden and the desktop-only note replaces it.

### Compliance Rule authoring (Story 2.4)

- **Compiled status is derived from authored inputs on every save and read.** Generation 10 stores schema version, compiler version, conditions, and Agent-Judged threshold in four typed columns; `compileComplianceDraft` is the only producer, and fail-closed reads recompile authored inputs byte-for-byte so changed prose cannot retain a Template-derived rule. Audit events carry condition ids, digests, and lengths rather than raw rule text.
- **Rule arithmetic stores decimal strings and uses scaled integers.** Thresholds, tolerances and confidence never pass through binary floating point; numeric and time boundaries use the same explicit inclusive/exclusive comparison contract.
- **Applicability is a closed expression grammar over each Template's declared Observation fields.** Blank applicability compiles to `found = true`; P-1 C1 and P-3 deliberately seed `all records` so proven absence is evaluated rather than filtered out.
- **Record evaluation is conservative and ordered.** Every applicable condition has a value; missing Agent-Judged results and unnamed values are `UNEVALUATED`, and the reducer is fixed at Exception, then Unevaluated, then Compliant. Missing, ambiguous, contradictory, uninspected or unproven Evidence cannot pass.

### Evidence Requirements and Schedule authoring (Story 2.5)

- **Disable Next's Server Function argument logging.** Next 16.3 logs Server Action arguments in development by default, including account passwords and authored text; application telemetry redaction cannot intercept it. `logging.serverFunctions: false` in `apps/web/next.config.ts` closes that path. Verify the real dev-server log after exercising an account-creation action.

- **Windows verification needs bounded test concurrency.** This host exhausted virtual memory with Vitest's default worker count; run `pnpm test --maxWorkers=1` and the integration suite with the same limit. Keep builds and browser runs sequential with these suites. An allocation failure or a timeout is not a product test result; rerun the affected checks after resource pressure clears.
- **A Node PATH change does not replace pnpm's sibling runtime.** The old `pnpm.ps1` selected the Node executable beside itself even with Node 24.20.0 first on PATH. Create corepack shims in the pinned runtime directory and check `pnpm exec node --version`, not only `node --version`.
- **WSL PostgreSQL is a usable local test fallback.** Docker Desktop's startup failed on its internal socket and Windows virtual-memory exhaustion. Use a separate PostgreSQL 18 cluster/database, password authentication and TLS; keep a WSL session alive so Windows localhost forwarding remains available. Never reuse an unknown application database for integration tests.
- **Native PostgreSQL avoids VM overhead on a small Windows host.** Portable PostgreSQL 18.6 works with a separate loopback-only test cluster, SCRAM password auth and a self-signed TLS certificate. When starting `pg_ctl` via PowerShell, do not use `Start-Process -Wait`: it waits for descendant database processes too. Wait for the launcher with `WaitForExit()` or check readiness separately.

- **Evidence editor inputs exclude derived capture metadata.** Add-row state must contain exactly `EvidenceRequirementInput` keys; inserting `withPlatformCaptured` output adds the forbidden `platformCaptured` key and causes the command to refuse the save. The domain reuses the compliance shape/text helpers and grounding refusals name the attribute.
- **Capture metadata follows Target selection in the same audited write.** Selecting an agent-driven system overlays Structural Snapshot and screenshot requirements and records the original choices in `authoredCapture`. Removing the last such Target restores those choices, preserving authored grounding, model-read declarations and recordings. The editor submits authored inputs, never the effective overlay, including after reload or an unrelated edit. Legacy rows without provenance preserve their existing choices because their authorship cannot be recovered safely. The target audit event records an evidence digest and the whole-row token covers the result.
- **Removing forced grounding can leave an incomplete Draft.** Draft repository reads allow empty grounding so the auditor can repair it; evidence saves, plan derivation and submission still require grounding or an explicit model-read declaration. Do not invent model-read or retain a forced snapshot merely to satisfy validation. Reviewed-state reads remain strict.
- **Use `authoredEvidenceInput` for stored-to-form projections, including test fixtures.** Removing only `platformCaptured` with object rest leaks `authoredCapture` into the exact-key command input and correctly gets refused. No-op authorship tests must submit the same authored projection as the editor.
- **Release-managed Railway services must not use watch-path filters.** During the Epic 2 release, `railway up --ci` produced `SKIPPED` with "no changes detected in watch paths" and CLI 5.47.2 kept waiting, leaving a previously crashed worker down after migration. Production web/worker now have empty `watchPatterns`; GitHub auto-deploy was confirmed disabled. Keep release.yml as the migration-before-deploy gate. A Railway `SUCCESS` startup must be verified independently of CLI completion; check web `/api/health` for the expected schema and worker startup/heartbeat logs. Do not weaken the schema guard to recover an early deployment.
- **P-1 starts with its pinned weekly Schedule at an editable 00:00 UTC.** Midnight supplies the required fixed-time authoring default; the other Templates remain unset because they name no Schedule. Generation 11 backfills the same typed defaults. No Run, period or handover is computed.
- **Upload/frequency mismatch is a completeness blocker, never a refusal.** Both relevant editors preview it for local choices and show the saved pairing after revalidation. The Schedule CHECK requires the matching period-derivation rule; a missing JSON key or JSON null must not pass through SQL three-valued logic.

- **Parse evidence shape before locking; validate grounding after deriving capture from the locked targets.** An empty grounding declaration may acquire mandatory Structural Snapshot grounding for an agent-driven target. Rejecting it before that derivation made direct command callers behave differently from the Builder. Without mandatory capture, the refusal still names the attribute and writes nothing.
- **A refreshed row token is permission to save only the values it represents.** A pristine editor synchronizes server values with its token; a dirty editor must retain its baseline when its section changed remotely. A successful normalized save acknowledges the submitted values without discarding edits made while the request was pending.
- **Backfill tests must execute the upgrade on existing authored rows.** Generation 11 derives capture metadata from persisted Target selections, including an empty selection, rather than assuming Template defaults remain selected. SQL literal comparisons cannot prove that a backfill updated any row.
- **Template suggestions are not selected Target Systems.** A fresh P-1 Draft retains its suggested Structural Snapshot and screenshot requirements but records `platformCaptured: false` until an agent-driven Target is actually selected. Creation and upgrade must agree on this meaning.
- **Recheck local service health after a resumed agent turn.** The isolated PostgreSQL process stopped with its previous shell session; `pg_isready` exposed that before retrying browser checks. After a production build, this host also served a persistent development 404 for the existing health route; preserving `.next` outside the repository and starting with a fresh generated cache restored routing. Do not alter the health endpoint to accommodate a stale local cache.

### Queued executable plan derivation (Story 2.6)

- **Saved Drafts, audit events and derivation jobs commit together.** Both the pg-boss constructor database (queue metadata lookup) and `send` database use `fromDrizzle(transaction, sql)`. A producer using the pool for one lookup can escape the transaction or deadlock a single-connection pool. Runtime processes disable queue migrations; only the release/CI migrator installs its schema and creates `procedures`.
- **Authoring digests and whole-row tokens protect different things.** The queue digest projects only authored inputs plus frozen compiler/model configuration. Preview status and attempts change the optimistic token, but never compiler inputs. Compile and call the model outside locks, then lock and recheck the digest; stale attempts are retained without replacing the newer preview.
- **Model output has no authority to change executable meaning.** Both provider adapters derive a candidate from original authored inputs and the contract vocabulary. The domain validates the entire candidate and semantic equivalence, then stores canonical compiler bytes. Raw provider text/errors and incidental generated labels never enter the version or audit chain. Missing credentials use deterministic derivation only when the version froze no model; a missing frozen model configuration is a recorded failure.
- **Compiler version 1 freezes finite execution limits.** Three retries per Step Execution follow NFR-8. The other initial build-policy defaults are 120 seconds per Step Execution, 10,000 Step Executions per Run, 3,600 seconds per Run, and 1,000,000 tokens per Run; these are implementation defaults, not PRD mandates. They are literal durable-contract values under the frozen compiler version; changing them requires a new compiler/contract decision, never a deployment silently changing an existing version.

### Owner decision: activation-time handover (2026-09-04)

- **Never guess a regression-gated handover date at approval.** The owner chose authoritative timing only when regression passes and the successor actually activates. Approval retains pending regression and the successor relationship without a provisional timestamp. The activating command computes the first successor Schedule period boundary strictly after actual activation; immediate activation may compute it inside approval. Story 2.8, AD-19 and linked planning contracts record this renegotiation; later Regression Run and scheduler work must revalidate the corrected timing.
### Queued plan contract and verification follow-up (Story 2.6)

- **Durable plan bytes use recursive canonical JSON order.** JSONB does not preserve insertion order. The schema returns canonical key order on both derivation and read, so normal serialization stays byte-identical across PostgreSQL round-trips; execution consumes the stored contract rather than authoring inputs.
- **SSR component tests need an explicit JSX transform.** Next preserves JSX for its own compiler; root Vitest uses Vite 8/Oxc and needs `oxc.jsx.runtime: automatic` to render TSX components in node tests. The preview tests exercise real React markup; Playwright remains the WCAG gate.
- **pg-boss failure output needs the same transaction-safe JSON bridge as its jobs.** Installed `fromDrizzle` passes plain error-output objects as driver parameters; postgres.js rejects those unless JSON-encoded. The queue adapter preserves arrays/Dates and serializes plain objects. Handler failures are replaced with a fixed safe error before pg-boss persists them; retry tests exercise real storage and recovery.
- **Started derivations outlive authoring eligibility.** Refuse a job that begins on a non-Draft. If an already-started model attempt finishes after submission, append its stale operational attempt/audit while preserving the frozen plan, inputs and lifecycle state. Dropping the result must never mean dropping the attempt.
- **Plan action kinds have a versioned interpreter contract.** `docs/contracts/executable-plan-v1.md` binds lookup columns, matching, absence proof, ambiguity, capture and evaluation to frozen inputs. Canonical step descriptions explain it; models and freeform instructions cannot redefine the action vocabulary. Runtime execution remains later-epic work.
- **A lost Server Action response has an unknown outcome.** Older Builder editors now match Evidence/Schedule: explain that the change may have committed, block another save and require reload to inspect persisted state. A failed response is not proof that nothing changed; browser coverage commits the transaction before aborting its acknowledgement.
- **Fresh-page authoring tests must prove hydration before typing.** For the second Builder tab, observable blur validation proves React handlers are attached. Filling server-rendered inputs before hydration can lose values and falsely resemble a cross-session refresh bug; do not hide this with arbitrary waits or retried save clicks.

### Story 2.6 formal-review repair decisions

- **Persist an audited attempt start before any compiler/model work.** Finalization updates that same operational attempt and commits the result/audit atomically. A crash or final audit failure leaves a durable started attempt; queue retry/restart recovery finalizes it safely. No application lock is held during model I/O.
- **Queue state owns automatic retry timing.** Only classified transport/time-out failures request bounded retries; invalid responses fail without repeated paid calls. Current pending work is reconciled after terminal/expired jobs, with a live-delivery recheck under the version lock. A successful plan survives later duplicate failures. Recovery scans process at most 100 relevant terminal candidates plus a 100-Draft keyset sweep per tick. The Draft sweep also catches old-producer writes after an earlier plan succeeded; its cursor advances across ticks and resets on restart.
- **An explicit failed-plan retry is an authorized operational action.** Authorize, guard the expected whole-row revision, then enqueue/pending/audit atomically without changing frozen compiler/model identity or authored inputs. Its control stays outside the read-only preview.
- **Compiler-1 identity keys are opaque exact strings.** Preserve code points, case, whitespace, leading zeros and Unicode composition; no numeric parsing, trimming, case folding, NFC or fuzzy equivalence is authorized. Mismatches take the existing human-resolution path. Any later equivalence policy requires a new compiler/contract and reviewed successor.
- **Model prompt identity must select supported immutable text.** This build supports prompt version 1 only. A conservative full-response byte budget is checked before paid I/O, with a configurable model-supported output limit; oversized Drafts fail actionably rather than promising a truncated full contract. Web needs frozen model identity only; only worker/gateway composition requires its secret.
- **Section snapshot equality is structural.** JSONB object key ordering must not invent a dirty-section conflict. Arrays retain order. Summary list reads project only selected Procedure metadata, never full plans or complete attempt histories.

### Story 2.6 clean-checkout CI repairs

- **The migrator must build its transitive runtime dependencies.** Queue migration now imports the application package. Building infrastructure alone passes on a warm checkout but fails with missing application/dist on a fresh runner; `db:migrate` builds the infrastructure dependency closure before executing the migrator.
- **Docker test exclusions include colocated tests.** Root `tests/` is absent from the image context, so a colocated web test importing its fixture cannot participate in Next's image typecheck. Exclude `**/*.test.ts` and `**/*.test.tsx` from Docker inputs too; full-checkout typecheck and test commands retain every test.
- **Browser assertions must account for intentional polling backoff and background throttling.** Prove hydration through observable behavior before typing, return the edited tab to the foreground, and allow the ten-second maximum poll interval plus the server response. Keep the actual conflict, retained-value and no-overwrite assertions; do not replace them with sleeps.
- **The operational published marker names the current plan publisher.** Only the installing attempt is true; installing a replacement clears earlier markers while retaining their outcomes, timestamps and audit history. This survives out-of-order duplicate completion and A→B→A input reversions without timestamp tie-breaking.

### Version decisions and in-app notifications (Story 2.7)

- **Submission persists the exact review, including its predecessor.** The typed submission snapshot stores the preceding version identity/revision and section values under a shared row lock; approval freezes that snapshot rather than recomputing a diff against a possibly changed Draft. A predecessor with a pending plan is compared using saved authored fields. Operational derivation events may advance the row token without replacing the submitted or approved definition.
- **Authorship is trusted provenance, distinct from responsibility.** Creation records its human origin and responsible author; actual definition edits add human authors. Derivation starts, completions, recovery and retries never add authors. Generation 13 backfills only immutable creation and definition-change events; absent provenance denies submission/approval. Platform successors must preserve responsibility separately from their platform origin.
- **A locked command reads roles on its transaction connection.** An outer-pool role recheck can exhaust a one-connection pool or deadlock a full pool of concurrent decisions. Procedures joins an identity-owned role reader and recipient reader with the notification-owned writer. After rollback, denial auditing records the actual locked policy result without re-reading a role that may already have changed.
- **Notifications are durable in-app deliveries.** Submission addresses every current Audit Manager; approval/rejection addresses the responsible author. State, decision, event and pending rows commit together. The worker marks delivery by a conditional update on the unique send key; replay cannot create another item. Readers take the signed-in session and return only its delivered rows.
- **Tool configuration pins executable meaning rather than an empty object.** Review schema 1 records executable-plan-v1, opaque exact identity matching, frozen registered read actions and the closed action vocabulary, alongside the full plan, limits and configured model/prompt identity. A later change to that interpreter policy requires a reviewed configuration/version change.
- **Windows Node preloads require file URLs.** Convert an absolute Windows path with pathToFileURL before passing it to --import. The P-1 browser proof starts the actual worker with a test-only Anthropic HTTP preload, observes the installed SDK response path, and awaits process exit before deleting fixtures. This proves synthetic provider wiring, not live provider quality or credential acceptance.
- **A lifecycle response can be lost after commit.** Disable further decisions until reload inspects the saved state, retain the entered rationale, and never treat a missing acknowledgement as proof that approval/rejection did not happen.
- **Disk-full writes can truncate source before reporting failure.** Stop generators/builds when Windows reports ENOSPC; inspect edited file lengths and generated JSON before continuing. Recover only the affected files from Git plus a captured reviewed diff, then reapply the bounded patch and check whitespace. A generator may print ENOSPC yet exit zero: an empty snapshot is not a valid migration. Do not repeat verification until disk space is restored.

- **Submit acknowledges the whole Builder, not only the saved row.** Every independent editor registers dirty/conflict/pending/unknown status with the shared submission guard; the confirmation reads current statuses again. Registration is removed on unmount, explicit resets preserve server baselines, and unknown outcomes still require reload.
- **A review diff is a validated contract.** Strict readers verify owning version identity, the exact unique section set, current values against the submitted definition and truthful changed/first-version flags. Previous values remain frozen. An unreadable predecessor is a refusal, never absence of history.
- **Notification cursors preserve PostgreSQL precision.** Order by delivery timestamp plus send key, carry all six fractional digits and apply recipient filtering on every page. Validate the UTC calendar date and storable key before casting in SQL. Enqueue Procedure name/version snapshots through the Procedure command; notification readers need no cross-module table join. Pending delivery has its own partial index.


### Immutable versions and configuration changes (Story 2.8)

- **The epic delivery protocol is the shared completion rule.** Follow AGENTS.md's Epic delivery protocol: write a readable implementation report explaining delivered behavior, actual verification, decisions and remaining user action; link it from the PR. The user must not need the full diff to understand delivery.
- **Configuration writes serialize before module row locks.** Procedure, registration and source units of work acquire transaction advisory lock `(20428, 1)` before any module reads/writes. This intentionally limits PoC write throughput but prevents lock inversion and Active-reference phantoms during activation, version allocation and ripple confirmation. Credential probes and model I/O remain outside it. Concurrency tests observe the advisory wait, not a callback behind the lock.
- **Activated succession is a separate chain, not timestamp ordering.** The prior Active baseline is the activated chain tip; pending regression candidates are separate edges with null activation and handover. Out-of-number-order approvals and equal timestamps cannot choose the wrong baseline. Each edge retains its own boundary; no retirement or execution is implemented here.
- **Calendar handover uses period starts strictly after activation.** Daily means next UTC midnight, weekly means next Monday midnight and monthly means the next first-of-month midnight, irrespective of configured launch time. Once has no automatic boundary and preserves the explicit authored Period.
- **Reviewed definitions survive operational activity and upgrades.** Generation 14 refuses frozen-field updates to Approved, Active and Retired rows, including state-and-field bypasses. Only state progression, update time, derivation attempt history and guarded activation metadata are operational. Existing generation-13 Approved rows remain Approved with null activation metadata; migration never silently activates them. Deletion policy is separate from this frozen-field contract.
- **Change replay uses an immutable event identity or configuration revision.** Store minted version IDs before commit, including an empty result. Replay checks that result before resolving the Active set, so historical events cannot mint against later activations. Registration/source snapshots cross only a typed transaction port, never an audit payload; a configuration reverting to its original value still has a distinct event.
- **Platform configuration is an explicit release operation.** After migration/build, run `node scripts/apply-platform-configuration.mts <configuration.json>` with DATABASE_URL. JSON has `revision`, `changeKind` (`model` only), `model` (null or provider/modelId/promptVersion) and `interpreterContract` (`executable-plan-v1`). Prompt/tool publication is refused until a versioned compiler/interpreter contract exists. Only model changes using prompt 1 and the supported interpreter can publish; secrets remain worker environment values. Runtime startup never publishes a revision. Actual revision rows are immutable identities; reserved `@current` stores the real immutable revision plus publication identity. New Procedure creation reads that supported model/revision under its transaction; process configuration is only the pre-publication fallback. A new revision with unchanged configuration records no Drafts, and replay never resets the pointer.
- **Platform Drafts retain human responsibility without claiming human creation.** Each Draft records its originating version/change and queues derivation with the changed frozen model or exact changed registration snapshot. Human edits add authors and normal submission/approval rules still apply. An old worker reports unavailable frozen configuration rather than deriving under its own tuple.
- **A registration warning describes the proposed configuration edit.** Annotation-only changes carry no ripple warning. Digest changes count distinct Active Procedures, then recheck that exact count under the same serialization lock before mutation; drift refuses the save and requires reload/reconfirmation.
- **Lifecycle metadata is a strict durable contract.** Validate lifecycle flags, dates, state placement and platform provenance before granting stale-column Draft reads; legacy null metadata remains readable. Immediate activation validates and audits both Submitted-to-Approved and Approved-to-Active edges atomically, with separate actors, times and revision tokens.
- **Correlated subqueries must retain the outer SQL qualifier.** Drizzle single-table selection rewriting can strip the table name from interpolated Column objects inside SQL expressions. Write the trusted outer identifier explicitly in correlated subqueries and test at least two distinct owning rows; a one-row fixture cannot expose accidental inner self-correlation.
- **Review repairs preserve authorization and read boundaries.** New version rechecks the role after the shared lock and records a denial outside a rolled-back mutation. Registration/source fan-out filters its owned affected subset in SQL before strict validation. History pages are bounded and navigable; explicit Builder selections resolve directly rather than through a capped history list. Successor display reads recorded lineage independently of loaded history pages.

### PR 21 review findings (applied 2026-09-05)

- **A superseded version stays ACTIVE, so every read that means "current" applies the succession predicate.** Nothing writes RETIRED until Schedule handover, so `findLatestActiveVersion`, `listActiveVersions` and `countReferencing` all exclude a version whose successor has `activated_at`. Without it the ripple confirmation said "1 Procedure" and the fan-out minted two Drafts, one copied from the superseded definition. A test of the COUNT needs a successor that DROPS the registration, and a changed configuration waits for regression, so `tests/integration/immutable-versions.test.ts` simulates the Regression Run's activation with the one state progression generation 14 permits.
- **Every first publication of a configuration revision is in the audit chain**, `modelChanged: true` or not: it moves `@current` and with it the revision every new version stamps. A replay changes and appends nothing.
- `[EXTENDED 2026-09-09]` On a client `createDb` has wrapped the opposite happens — `sql.json` throws and the JSON text passes through — so `${JSON.stringify(x)}::text::jsonb` is the one spelling right on both; see the 2026-09-09 `sql.json` note at the top. **`${JSON.stringify(x)}::jsonb` double-encodes in postgres.js.** The cast tells the driver the parameter is jsonb and the driver stringifies the string again, so the column holds a JSON string. Use `sql.json(x)` or pure SQL (`jsonb_set`, `to_jsonb`). A "malformed value is refused" test passes either way, which is how it hid.
- **`entry-point.test.ts` covers every entry point that guards on `import.meta.main`**, the platform-configuration script included. An argv comparison there fails through a symlink and reports success having done nothing (Story 1.8).
- **A Server Action that can throw answers a framework 500 to the caller most likely to be probing.** `retryPlanDerivationAction` now has the try/catch its siblings have, and its failure message is in the telemetry allowlist.

### Durable Run initiation (Story 3.1)

- A fault-injection browser test aimed at a React error boundary must wait for the form's `data-client-ready` marker after document reloads. Native POST can succeed before hydration without showing the modal; verify that transport separately with JavaScript disabled, while asserting the same durable Run/job outcome.

- A recovery link to the current pathname plus a fragment only scrolls; it does not reset a failed React boundary. The uncertain Run response uses a real document reload, verified by dropping the response after the transaction commits and then retrying the same period.

- Keep local test environment helpers outside Temp, and set PowerShell `$ErrorActionPreference = 'Stop'` before dot-sourcing them. A missing helper must stop verification before it falls back to the wrong Node patch or database configuration.
- In explicit `INTELLIFIN_LOW_DISK=1` mode, browser auth setup allows cold route compilation before asserting the signed-in shell. Normal CI timeouts remain unchanged; this is not a retry or a relaxed product assertion.

- **Period ownership walks activated succession through a Procedures-owned reader.** The first version is unbounded; an activated null boundary replaces its predecessor for all periods. Pending edges never transfer ownership. Broken, forked or unreadable lineage refuses initiation, without version-number or timestamp tie-breaking.
- **Initiation joins the configuration lock before its role recheck.** The Run row, partial active-Standard uniqueness, pg-boss dispatch, first chained Timeline event and transactional `run_timeline` notification commit together. Run and durable correlation IDs are UUIDv7; request correlation IDs remain separate. Story 3.1 deliberately leaves the job queued until Story 3.2 supplies its consumer.
- **Run periods are separate execution inputs.** Initiation stores inclusive date-only boundaries and references the frozen version without rewriting its plan, source or registration snapshots.
- **Preflight local verification before starting a suite.** Run `scripts/verify-local-preflight.ps1 -RequireDatabase` with the pinned environment; it checks Node/pnpm sibling runtime, disk, RAM and isolated database readiness without printing credentials. Keep heavy checks serial, browser verification before the production web build.
- **Epic 3 adapter Work Item retries use one automatic extra bounded cycle.** Owner decision: after first exhaustion retry once; second exhaustion marks that Work Item FAILED and incomplete coverage makes the Run INCONCLUSIVE. Human retry/skip Escalations remain later agent-driven behavior.
- **Turbopack cache compaction needs spare disk beyond its final cache size.** Story 3.1 exhausted disk during a browser run with about 1.5 GiB initially free. Set `INTELLIFIN_LOW_DISK=1` for local verification to disable the development filesystem cache; retain the warm server in memory when possible. Stop task-owned writers after ENOSPC and inspect generated artifacts before retrying. Never stop another project's test process to reclaim memory.
- **React Server Action forms render the method as uppercase POST.** Keep the explicit method required by our form guard spelled `POST` on function-action forms so client hydration agrees with the server attribute. React may still emit its informational explicit-method notice; a hydration mismatch is a separate defect.
- **Raw postgres.js bigint columns are strings.** Audit `sequence` reads through raw SQL need explicit numeric conversion for bounded test assertions; Drizzle's mapped domain reader already supplies numbers. Do not change a correct event to accommodate a test driver's representation.
- **Check prior placeholder browser assertions when enabling a feature.** Story 3.1 enabled Initiate Run, but the Epic 2 immutable-version journey still asserted that it was disabled. Search the whole browser suite for the replaced control; preserve the earlier journey and assert its new contract. CI caught this despite all new Run tests passing.

### Deterministic population acquisition (Story 3.2)

- **Reserve and hash the acquisition pair before upload.** The expected envelope digest is committed with the Evidence reservation before conditional object creation. The envelope contains exact raw bytes and the independent declaration. Resume verifies that pair rather than fetching a new declaration for old bytes. Registration follows a separate raw-object size/digest reread; object I/O never holds a database transaction.
- **Population claims lock one Run, not platform configuration.** A revision and bounded lease reject stale completions. Four durable attempts (initial plus three retries) survive queue restart. A ready population completes only its frozen Session Step; unsupported preceding actions refuse safely.
- **Source coverage and Run period have different meanings.** The independent declaration interval must cover the Run interval. Inclusion uses the separately persisted Run dates without rewriting approved plan bytes. Indeterminate values remain rows and prevent readiness even when another predicate would exclude the row.
- **Population Evidence requires private S3 deployment configuration.** Worker startup requires EVIDENCE_S3_ENDPOINT, EVIDENCE_S3_REGION, EVIDENCE_S3_BUCKET, EVIDENCE_S3_ACCESS_KEY_ID and EVIDENCE_S3_SECRET_ACCESS_KEY. Optional EVIDENCE_S3_FORCE_PATH_STYLE supports compatible stores. This story provisions no bucket or credentials; the file store is test-only.
- **Worker browser fixtures must supply every required backend.** `tests/fixtures/s3-server.ts` provides an isolated HTTP object store to the actual worker and AWS SDK. Keep this wiring in older worker journeys too; injecting a handler or file store alone does not verify the production composition root.
- **Scope notification assertions to their Procedure.** A reused throwaway database can contain valid notices from earlier journeys. Match the test's unique Procedure as well as the notification kind; never clear unrelated notices to satisfy a global inbox assertion.
- **Reconcile response metadata as well as independent declarations.** Schema version, representation and ordered schema must agree. Use a closed API envelope so alternate/nested continuation markers cannot accidentally become a complete extraction. A Northstar cover's published HMAC is a synthetic integrity convention, not production authentication.
- **Preserve a bounded bad response before reporting failed checks.** Unsupported media and malformed declaration strings must not turn useful source bytes into a retry-only error. Fetch exposes decoded bytes; compressed Content-Length describes different bytes. Primary data is bounded at 16 MiB and declaration HTTP bodies at 1 MiB. Chunk UTF-8/hex encoding and CSV parsing; per-byte arrays and per-character concatenation amplify memory at the documented limit.
- **Exercise actual recovery interleavings.** Hold an old attempt, take over its expired lease, then release both success and failure paths; check revision ownership and unchanged events. The browser restart test kills the actual worker after envelope storage, expires only its persisted lease, restarts the process and checks stable Evidence. Merely constructing a new repository does not prove worker restart behavior.
- **A ready checkpoint still verifies Evidence on job redelivery.** Check both registered digests without rewriting objects. Do not describe this as ongoing tamper monitoring. Recovery handles each Run's error independently and stops scheduling the rest of its selected batch on shutdown. Completion rechecks the original overall execution deadline; each audit check records its own outcome.
- **A stale-claim test must keep the replacement claim active.** Hold attempt two in acquisition while releasing attempt one's success or failure. If attempt two has already completed, the status guard alone rejects the old result and the test does not prove revision ownership. Assert unchanged checkpoint/events before releasing the replacement.

### PR 23 review findings (applied 2026-09-05)

- **A worker duty that cannot run yet must not stop the duties that can.** `apps/worker/src/main.ts` threw a `ConfigError` when `EVIDENCE_S3_*` was unset, and `main().catch` exits 1, so Railway would have crashlooped the worker — and the throw sits after plan derivation and recovery start and before the heartbeat, so derivation, notification delivery and the liveness row went down with it, on a deployment whose bucket is simply not provisioned. Same shape as the `SUPPORTED_SCHEMA_MIN` incident: a startup guard refusing the deployment its own release created. `populationExecution(config)` in `startup.ts` now returns enabled-with-config or disabled-with-a-reason, `main.ts` branches on it and logs `Population execution disabled` once, and `startup.test.ts` asserts both the decision and that the composition root actually branches — the behaviour alone would not have caught a re-added throw.
- **The acquisition adapter and the evidence store are outside the barrel, and that is a build failure, not a convention.** Both were `export *`ed from `packages/infrastructure/src/index.ts`, which `apps/web/src/bootstrap.ts` imports, so the module whose whole job is an outbound GET to a registered Target System was reachable from the web, and the S3 SDK was in the web bundle graph. They now have `./acquisition` and `./evidence` subpaths; `no-population-acquisition-in-web` and `no-evidence-store-in-web` fail `pnpm boundaries` on any import from `apps/web/`, both spellings planted in `tests/unit/boundaries.test.ts`. The rule is scoped to the WEB, not to all of `apps/`: unlike the probe, the worker composes these in its own main loop, so a blanket `^apps/` rule would forbid the thing the worker exists to do. A new subpath needs an alias in `vitest.config.ts` AND `tests/integration/vitest.config.ts`.
- **`controller.abort()` in the deadline's `dispose`, third occurrence.** `withDeadline` cleared the timer and never aborted, so every early exit — a non-2xx, a redirect, a bad or over-long `Content-Length`, each `return null` in the declaration fetch — left the body unread with the only bound on it cancelled. `fetch` resolves on HEADERS. Every adapter test used a synthetic in-memory `Response`, so no socket existed and none of them could see it; the test that catches it runs a real server that sends headers and then nothing, and asserts `server.close()` completes.
- **The frozen source host guard is deliberately narrow: link-local and the unspecified address only.** A blanket internal-address refusal is WRONG here — the synthetic Northstar systems are served on loopback (`http://localhost:4300/loancore`) and a PoC may bind a source to a private neighbour, so refusing those breaks the documented path, and an existing adapter test proved it immediately. What no legitimate source ever names is `169.254.0.0/16` (cloud instance metadata), `fe80::/10`, or `0.0.0.0`. `isRefusedSourceHost` refuses those before a request is made, including the IPv4-mapped hex form a URL normalizes to (`::ffff:a9fe:*`). A host NAME that resolves to link-local is not covered; that needs a resolved-address check at connect time.
- **Two findings were left for the owner, and the owner has now decided both (2026-09-06).** They are no longer accepted risks; the rules that replace them are under "Owner decisions" below. A redelivered POPULATION_READY job past the Run time limit no longer discards the population it had already acquired, stored and verified, and a replayed request token no longer resolves into a Run the caller did not initiate. Both tests that pinned the old behaviour were rewritten to the new decision and say so in their own names.

### Adapter extraction and Reference Sources (added with Story 3.3)

- **The classification reads bytes that were already frozen, and needs no contract change.** `makePlan` emits one `extract-adapter` Session Step per non-agent-driven Target in authored order, and `inputs.targets[].contract.kind` is frozen beside it. `classifyPlanTargets` in `packages/domain/src/runs/execution.ts` reads only those two, so no action kind is added, `semantics()` does not move, and every ACTIVE version stays executable. Recorded as interpreter semantics in `docs/contracts/executable-plan-v1.md` and in full in `docs/contracts/adapter-extraction-v1.md`.
- **The spec's kind names were the POPULATION SOURCE vocabulary; the frozen bytes are the TARGET SYSTEM one.** Story 3.3's Boundaries say `read-only-api` is adapter-acquired and `versioned-file`/`manual-upload` are Reference Sources. A Target System registration's `kind` is `web | desktop | api | versioned-file` (`TARGET_SYSTEM_KINDS`), and `manual-upload` is not one of them. The implemented rule therefore is: `api` → one Work Item, `versioned-file` → a Reference Source Session Step and no Work Item, `web`/`desktop` → the stage refuses the plan. Refused, never skipped: skipping would let a Run conclude about a system nothing read. In practice such a plan never arrives, because its first Session Step is `create-workspace` and population acquisition already refuses that.
- **A credential value must have nowhere to live.** `ResolvedCredential` has `reference` and `authorize(headers)` and NO field holding the token; `resolvedCredential` closes over it, so `JSON.stringify` yields the reference alone and no checkpoint, audit payload, Timeline event, queue job, log field, Evidence artifact or error message has anywhere to pick it up from. Containment by shape, not by discipline — the same lesson `CredentialCapabilityReport` learned, one layer along.
- **"Audited by reference" cannot mean putting the reference in the payload.** `FORBIDDEN_PAYLOAD_KEYS` in `audit-event.ts` refuses `credentialref`, `credentialreference` and `credref` outright, so a `credentialRef` payload key throws. The retrieval event names the Target System instead; its frozen `credentialReferences` entry is in the plan the Run already points at. Check that list before adding any payload key that sounds credential-shaped.
- **`CredentialResolver` is a NEW port, not a widened `CredentialProvider`.** `describe` proves a reference read-only at registration time and has exactly two fields so the web can hold its result. A resolver returns something usable and is composed only by the worker, through `@intellifin/infrastructure/credentials`; `no-credential-resolver-in-web` and `no-adapter-extraction-in-web` fail `pnpm boundaries` on any import from `apps/web`, in both the `src` and the `dist` spelling.
- **`CREDENTIAL_TOKENS` is the worker's alone, and an ambiguous manifest is refused whole.** Two keys that trim to one reference reject the entire manifest — the `parseCredentialCapabilities` rule, for the same fail-open reason. The shape parser lives in `config.ts`, not in the resolver, so validating it at boot does not drag the resolver into the barrel the web imports. In production a non-empty value on any process but the worker refuses to start; outside production it is allowed, because one environment file is routinely shared and the web has no code path that reads it.
- **An adapter-acquired Target System's frozen allowed origin IS its extraction location.** Either the collection itself, or the system's read-only service index (`{service, synthetic, access: "read-only", endpoints[]}` — a closed shape, so a collection response can never be mistaken for one), from which the adapter follows exactly ONE entry, only inside the same origin, matched on a path boundary. That is what makes the registrations `scripts/seed-northstar.mts` writes (`http://host/accessgate`) executable without a path being guessed.
- **The RoleMatrix CSV carries a leading `entry` ordinal, and it had to.** The dataset declares `AMBIGUOUS_DUAL` twice with different permissions; flattened to `role,permission` those four rows union to `{CREATE_PAYMENT, RELEASE_PAYMENT, VIEW_PAYMENT}`, which CONTAINS a prohibited pair — so the account the expectations require to be Unevaluated (`p-2-sod-conflicts.json` case D5-c) would have been reported as an Exception. A boundary an artifact never had cannot be recovered downstream. The ordinal is generated by `uv run fixtures/northstar/generate.py` from the dataset's entry positions and the cover sheet's digest is recomputed over the new served bytes; `apps/northstar/src/fixtures.test.ts` recomputes both independently in TypeScript.
- **A duplicate population key is ONE Observation.** `run_observation` is unique on `(work_item_id, population_record_key)`, so a second row would be silently dropped and the reported count would disagree with the stored one. `buildAdapterObservations` deduplicates and reports `duplicate-record-keys:N` as the Work Item's diagnostic; the duplicate stays an Evidence Quality Gate event for Story 3.4. A record with no usable key produces NO Observation and is counted as `unkeyed-records:N` — inventing a key would fabricate coverage, and fewer Observations than included records is the safe direction.
- **The Run deadline starts with the FIRST POPULATION CLAIM and this stage inherits it.** `run_execution.run_started_at` is copied from `population_execution.started_at` on the first claim and never restarted, so a second stage cannot buy a Run another hour. Exhausting it is INCONCLUSIVE, not RUN_FAILED.
- **A Session Step failure is RUN_FAILED; a Work Item failure never stops the Run.** Addendum §E. A Work Item gets its bounded cycle plus the owner's automatic second (2026-09-05), so eight attempts, and then FAILED with a diagnostic while the next Work Item still runs. An unresolvable credential fails its item on the FIRST attempt: retrying a reference nobody declared eight times against a live system proves nothing.
- **The extraction stage does not propagate its retry to the queue.** A redelivery makes `acquirePopulation` re-verify its Evidence and can consume one of that stage's four durable attempts, so a transient extraction failure would spend the population's budget. It writes a `RETRY` checkpoint and the extraction recovery sweep — its own read, `PostgresAdapterExecutionRepository.recoverableRunIds`, because the population sweep stops selecting a Run once it is `POPULATION_READY` — picks it up.
- **Evidence rows are written before the Step or Work Item that names them.** `run_session_step.evidence_id` and `run_work_item.evidence_id` are real foreign keys, and `run_session_step_acquired` additionally forbids an ACQUIRED step with a null one — which also means a test's cleanup must delete steps and items BEFORE the Evidence they name.
- **`packages/application` has `lib: ["ES2024"]` and no host types at all.** `Headers` and `TextDecoder` do not typecheck there — that absence is the compiler-enforced half of AD-11. `CredentialHeaderSink` is a structural `{set(name, value)}`, and a test that needs to read bytes uses the domain's `decodePopulationUtf8`.
- **A fake clock plus an inherited deadline is a trap.** Every test in `execute-adapter-steps.test.ts` initially terminated at the claim with `run-time-limit`, because the fixed clock was four days after the population `startedAt` the fake supplied. When a stage inherits a durable deadline, the fixture has to be inside it.

### Observation registration (added with Story 3.4)

- **`registerObservations` is the ONE write path to `run_observation`, and the seam has no bypass.** `AdapterExecutionContext` EXTENDS `ObservationRegistrationContext` rather than owning a `saveObservations` of its own, so there is no reachable write that skips the digest, the coverage rule, the per-Observation checks or the event that records them — the containment `PostgresIdentityUnitOfWork` gives the identity commands, one layer along. The whole contract is `docs/contracts/observation-registration-v1.md`.
- **The Observation digest is SHA-256 over the RFC 8785 canonical JSON of the thirteen §B.1 wire keys, through the shared `canonical-json.ts`.** Written key by key, never a spread. It covers NOTHING operational — no attempt counter, lease, revision, row version, coverage state or registration time — because those move for reasons that have nothing to do with what was observed, and a digest that moved with them would make an untouched row look tampered with. `tests/fixtures/observation-digest-golden.json` is produced by `uv run scripts/make-observation-digest-golden.py` with Python `rfc8785` + `hashlib`, envelopes written out by hand; the unit test asserts `producer` starts with `Python`.
- **`observationId` is DERIVED, never minted** — RFC 9562 §5.8 UUIDv8 over a SHA-256 of `[workItemId, populationRecordKey]`. `run_observation` is unique on that pair, so a minted UUIDv7 would make every redelivery produce a different record, a different digest and orphaned check/evaluation rows: idempotency and tamper-detection would be indistinguishable. Two parts, not concatenated, so `("a","bc")` and `("ab","c")` are different Observations.
- **A stored row and its digest column are two things, and both have to be read.** An edit to a row does NOT touch its digest column, so comparing a fresh batch against that column alone finds them in agreement and sees nothing. `readObservations` returns the record rebuilt from the columns; registration recomputes its digest (`observation-integrity` on a disagreement) and only then compares it with the batch's (`digest-mismatch`). The first integration attempt at this passed for the wrong reason and had to be rewritten.
- **A refusal is thrown, so the transaction rolls back — the Evidence row, the Work Item and the Step Execution with it.** Same lesson as Stories 1.5–1.7. `ObservationRegistrationError` maps to the `observation-registration-refused` diagnostic and is TERMINAL on the first attempt: the same bytes make the same batch, so retrying it eight times against a live system proves nothing (the `credential-unresolved` rule).
- **`item.observations` is set before the commit that stores them, so a failed attempt must restore it.** Otherwise a rolled-back batch leaves the Work Item reporting Observations that are not there.
- **Honest absence has three legs and the third is the extraction envelope.** `parseExtractionRows` now returns `complete`: the response declares itself `complete`, its `returned` count equals the rows it carries, and its envelope holds no key outside the closed set. An open envelope lets an alternate continuation marker (`next`, `cursor`, a name nobody thought of) pass unnoticed, turning "this record is not in the system" into "this record is not on the page I happened to read". An unknown key does not fail the parse — the bytes are still what the Target System answered and are still frozen as Evidence — it makes the extraction not provably complete, so every absence from it is `UNINSPECTED`.
- **There is ONE closed collection envelope, `COLLECTION_ENVELOPE_KEYS` in `packages/domain/src/runs/population.ts`.** Story 3.2's `complete-extraction` check had it first, inline; Story 3.4 needed the same list and wrote a second one — which diverged immediately, on `synthetic`, the NFR-13 marker EVERY Northstar response carries. Every unit and integration fixture agreed with the new copy because the fixtures were written beside it, so all three suites were green while the real served bytes were judged incomplete. Only `population.spec.ts`, which runs the real worker against the real synthetic system, could see it — four and a half minutes in. Two copies agree on every value anybody thinks to try, and a fixture for a served response must carry the keys the server really sends. `tests/unit/collection-envelope.test.ts` is that check in one second: it calls the real Northstar handler and asserts every key it emits is in the list, so a key added to `collection()` fails there and not in a Run.
- **The absence proof is compared against an EXPECTED list the caller builds from the population record.** `adapterSearchKeys` returns every declared lookup column, not just the first: P-1 declares `employee_id` AND `full_name`, so an adapter that indexed one of them has not proven a record absent and the record stays `UNINSPECTED`. A declared key the record does not carry as a non-empty string gets the empty string, which no derived query key can equal.
- **`coverage` is three-valued, and `AMBIGUOUS` is not `COVERED`.** §H's per-record coverage counts `found ∈ {true, false}` only, so calling an ambiguous match covered would be a lie in exactly the place the Gate reads.
- **"An uninspected record is never Compliant" is a foreign key, not a rule in a command.** `run_observation_evaluation` carries the coverage state, held to the Observation's by a composite FK over `(observation_id, coverage)` (which needs a unique index on those two columns), under `CHECK (value <> 'COMPLIANT' OR coverage = 'COVERED')`. Claiming `COVERED` in the evaluation row does not help: the pair has to exist in `run_observation`. The command refuses first so the caller gets a named refusal rather than a constraint violation.
- **`required-evidence` must not require an attribute another Target System supplies.** `plan.observations` is the UNION across every Target System of the Procedure: P-3 declares `amount` and `processed_time`, which live in the population and not in the approvals system, so a check requiring every declared attribute of one adapter Observation FAILS a correct Run. It was written that way first and every suite stayed green, because a failing check is recorded rather than refused — the P-3 integration test passed with `attribute-missing` stored on every Observation. The check judges what the Observation carries: linked Evidence `REGISTERED`, every grounding linked, every carried attribute grounded. Per-record coverage is the Run-level Gate's question (3.8), and it needs to know which system supplies which field, which the frozen plan does not say.
- **A `PASS` never carries a diagnostic and a `FAIL` always does**, in `observationChecks` and in the `run_observation_check` CHECK alike. A passing check with a reason attached reads as a finding to everything downstream; a failing one with none is a finding nobody can act on. The corroboration seam's verdict is normalized to that rule rather than trusted.
- **`Date.parse` ROLLS OVER an impossible calendar date instead of refusing it.** `Date.parse('2026-02-30T00:00:00Z')` is 2026-03-02 — a two-day shift by the one function whose whole promise is that it never shifts one. `normalizeObservedAt` does the arithmetic itself with `setUTCFullYear` (not `Date.UTC`, which maps a two-digit year into the 1900s) and re-renders the fields to compare them. `observed_at_source` keeps the source text verbatim; registration refuses a source that does not normalize to the record's `observedAt`.
- **The two seams are REQUIRED dependencies, not optional ones.** `NO_CORROBORATION` and `NO_EVALUATION` are the explicit "not yet judged" the worker composes. Optional seams defaulted in the command would let a composition root register every attribute as unjudged forever with nothing saying so. Corroboration runs BEFORE the digest, because §B.1 sets corroboration at registration and a value written afterwards would leave every row disagreeing with its own digest; it must therefore be deterministic over the stored snapshot, or a redelivery reads as an integrity failure.
- **An evaluation's `confidence` is a DECIMAL STRING.** It is compared against the frozen `agentJudgedThreshold`, which Story 2.4 stores as a decimal string; two representations of one quantity is one representation too many. `UNEVALUATED` is a VALUE and never an origin.
- **Generation 20 adds three NOT NULL columns to `run_observation` with no backfill, on purpose.** A digest is SHA-256 over RFC 8785 canonical JSON and SQL has no canonicalizer, so there is nothing honest to backfill one with. Generation 19 is unreleased, so the table is empty in CI and in production; in a developer database the ALTER fails loudly with "column contains null values" and the fix is `DELETE FROM run_observation`. **The statement ORDER in that migration is load-bearing** — drizzle-kit emits `CREATE UNIQUE INDEX` last, and the composite FK needs it first, so it is moved up by hand.
- **An assertion that reads a column the query never selected cannot fail.** `expect(String(item!.diagnostic ?? '')).not.toContain('extraction-incomplete')` read `undefined` from a `SELECT` that omitted `diagnostic`, so it stayed green against a build whose closed envelope did not name `synthetic` and judged every real extraction partial — the exact defect the assertion was written to catch. `?? ''` and `String(...)` are what turned a missing column into a passing test; assert the value, not a substring of a coalesced one.
- **A cleanup that does not know about a new table takes the whole file's cleanup with it.** `run_observation_check` and `run_observation_evaluation` name their Observation with a real foreign key, so `DELETE FROM run_observation` now throws unless they go first. `tests/e2e/population.spec.ts`'s `afterAll` did not, so every row that file created survived and `procedures.spec.ts`'s empty-list test failed for a reason that was not its own — the "read the FIRST failure, the ones after it may be its shadow" rule, once more.
- **A batch is one transaction whatever its size**; only the STATEMENTS are chunked (500 rows), in order. `OBSERVATION_LIMITS.batch` equals `POPULATION_LIMITS.rows` and is a refusal, not a truncation. The stated cost of the event carrying every digest is that a batch at the cap writes a large immutable payload.

### Sealed Evidence packages (added with Story 3.5)

- **An Evidence id is a NAME, not a mint.** `evidenceIdFor({runId, kind, scope})` in `packages/domain/src/runs/evidence.ts` is a UUIDv8 over the idempotency key `evidence-v1:<runId>:<kind>:<scope>`, and `evidenceObjectKeys` derives the object keys from the same three values — the object keys Stories 3.2 and 3.3 already wrote, spelled in one place at last. A retried production after a crash therefore re-derives its reservation instead of minting a second object beside the first, exactly as `observationIdFor` makes a redelivered Observation batch byte-identical. `scope` is the FROZEN Session Step id; the Run-level population uses `''`, and a scope on it is refused.
- **Reserve, upload, verify, register — one implementation, in `packages/application/src/runs/evidence-package.ts`.** Both producers wrote the sequence by hand and the two copies had already diverged: the acquisition envelope was uploaded and then compared against the copy still in memory, which proves the process has not corrupted itself and nothing about what the store holds. `freezeArtifact` verifies availability, size and SHA-256 against the bytes just sent AND against any digest a previous attempt registered; `verifyRegisteredArtifact` is the resume check.
- **`SealPackage` is the ONLY thing that abandons a reservation.** `PostgresPopulationRepository.save` derived `ABANDONED` from a TERMINAL checkpoint and the adapter Work Item abandoned its own row on exhaustion; both meant the seal found nothing open and the Result listed no abandonment — the exact defect the story exists to prevent. A failed Work Item now leaves its reservation OPEN while the Run continues, which is true.
- **Sealing abandons BEFORE it judges, and before it inserts.** Completeness is judged over the artifacts as they will be, or a package seals on a reservation the same transaction is about to abandon. The insert order is also what makes the "Evidence frozen after the seal" trigger safe as an immediate trigger.
- **`required` is a flag on a RESERVATION, not a checklist of kinds a Template could have.** A Run that failed before it ever reserved a Reference Source is not incomplete for an artifact nobody asked for. `population` and `reference-source` are required; `adapter-extraction` is NOT — a failed Work Item is already `INCONCLUSIVE` at the Run-level Gate, and saying it again as an incomplete package would mean no INCONCLUSIVE Run could ever hold a complete one.
- **Generation 21 is the first migration in this repository with triggers, and that is deliberate.** Three of its four rules span rows, which no CHECK can express: a Run may not reach a terminal state without a `run_evidence_package` row (a DEFERRED constraint trigger on `audit_run` — the forcing function behind "seal on EVERY terminal transition", so a branch that forgets fails to commit rather than shipping an unsealed Run); a `SEALED` package may not exist while a required artifact is unregistered; and a sealed package freezes its Run's Evidence rows and can never be UPDATEd. DELETE is still allowed, because removing a whole Run is what test teardown does and is a different question from rewriting an outcome.
- **A test that drives a Run to a terminal state by raw SQL must seal it first.** `tests/integration/runs.test.ts` and `tests/e2e/runs.spec.ts` each have a `terminate()` helper that inserts a `SEALED` package over zero artifacts and then updates the state. Two statements, because postgres.js autocommits each one and the deferred trigger fires at the end of the second.
- **A teardown that deletes `audit_run` must delete `run_evidence_package` and `run_evidence_integrity` first.** Both carry a real foreign key. A teardown that fails leaves ACTIVE `procedure_version` rows behind, and the next run of `immutable-versions.test.ts` then fails inside `listActiveVersions` on somebody else's leftovers — three integration failures that look like defects and are pollution.
- **A mismatch during the Run is `RUN_FAILED`; the same mismatch after it changes nothing.** `verifySealedPackage` refuses a Run that is not terminal, and the `SealedPackageContext` it is handed has no writer for a Run state, a seal or an Evidence row — so "changes no state" is a property of what it can reach rather than of what it remembers not to do. A store that cannot be READ is not proof of tampering and is reported to the caller, never written into the chain as an integrity event.
- **`S3EvidenceStore.putIfAbsent` now reads first.** An object already at the key is reconciled with no write sent at all, so immutability no longer rests entirely on the backend honouring `IfNoneMatch: '*'`; the header covers only the window between that read and the write, which a leased claim already makes rare. The residual race — two writers landing between one's read and its write, on a backend that ignores the header — is still there and is written down rather than claimed away.
- **The population reservation addresses TWO objects under ONE row.** The raw bytes and the acquisition envelope are fetched, verified and registered together and neither means anything without the other, so `evidenceObjectKeys` returns both in a fixed order (`[0]` raw, `[1]` envelope) and `population_evidence` stays one row. The envelope's SIZE was never stored, so a post-Run verification checks it by digest alone: `expectedSize` is nullable through the domain, the port and the column, because a fabricated size would put a number nobody measured into an immutable chain.
- **`integrity` is not an audit event family.** The nine families are closed; a post-Run mismatch is `failure.evidence-integrity` and the seal is `lifecycle.evidence-package-sealed`. Inventing a tenth family in a story that does not own the vocabulary would be a schema change smuggled in as a string.

### Corroboration against the stored Structural Snapshot (added with Story 3.6)

- **The corroboration seam is not a dependency any more, and that is the point.** Story 3.4 left `NO_CORROBORATION` as an injected `AdapterExecutionDependencies` field; `executeAdapterSteps` now builds a `snapshotCorroboration` over the bytes `freezeArtifact` just read back and proved identical to what was uploaded, at the ONE `registerObservations` call site. The stage that froze the artifact is the stage that re-reads it, so no composition root can register an adapter Observation as unjudged forever. `NO_CORROBORATION` stays for a producer with no snapshot; the worker no longer names it. The whole rule is `docs/contracts/structural-snapshot-v1.md`.
- **`packages/domain/src/runs/structural-snapshot.ts` is the ONE extractor, and it does no I/O at all.** Bytes in, verdict out. Corroboration runs INSIDE the registration transaction (so a fetch would hold PostgreSQL open across a network call) and BEFORE the digest (so a verdict that could move between two reads would make a redelivery read as an integrity failure). Its only reachable input is the `Uint8Array` it was handed.
- **`[SUPERSEDED for `web_tree` by Epic 4]` `web_tree` and `desktop_tree` are unimplemented BY NAME.** Epic 4's agent capture implements `web_tree` (`WEB_TREE_MEDIA_TYPE`, `agent-capture.ts`), so `IMPLEMENTED_SNAPSHOT_SUBSTRATES` is `['web_tree','sheet','json']` and only `desktop_tree` is left — which is Epic 7. The rule itself is unchanged: `corroboration-unsupported`, and the check FAILS. A substrate that fell through to "matched" for a snapshot nobody read would be the exact defect this story exists to remove. The substrate comes from the media type registration recorded beside the digest, so it is a property of the frozen artifact rather than a guess about its content.
- **One locator grammar for both implemented substrates: `$.<collection>[<index>].<field>`** — the shape the adapter already writes. Neither name segment may contain `.`, `[` or `]`, so the parse is unique; the index carries no leading zero, because `[07]` and `[7]` would otherwise be two spellings of one cell; and a `sheet`'s collection segment is exactly `rows`, because a free name would let two defensible extractors disagree about whether `$.rows[0].role` or `$.role-matrix[0].role` addresses the one table a sheet has. A `sheet` is parsed by `parsePopulationCsv` — the same RFC 4180 parser the population uses, marker line and all — so a cell address means one thing in this product and not two.
- **`matched` has six conjuncts, not two.** The locator parses AND resolves, the re-read label is the declared one, the re-read value equals `originalValue` as RFC 8785 canonical bytes, `extractedText` is the text of that value, and `normalizedValue` is the value or its UTC normalization. Canonical bytes are what keep `"007"`, `"7"` and `7` three different things. An attribute with NO grounding is judged `null`, not `contradictory`: it was never captured, `required-evidence` already says so, and there is nothing to contradict.
- **"Nothing could read it" and "it read differently" are different words.** An unsupported substrate or an unavailable/unreadable snapshot leaves every verdict `null` and FAILS the check (`corroboration-unsupported` / `corroboration-unavailable`); only a real disagreement writes `contradictory`. Marking an unread attribute contradictory would accuse an Observation of something nobody checked.
- **`normalizeObservationValue` and `groundedText` moved into `packages/domain/src/runs/observation.ts`.** The capture writes them and the corroboration re-derives them, so two copies would accuse a correct capture of contradicting itself on the first value nobody tried. `normalizeObservationValue` now goes through `normalizeObservedAt` rather than `Date.parse`, which ROLLS OVER an impossible calendar date instead of refusing it — the same trap, in the value the digest freezes rather than in `observedAt`.
- **`ObservationCorroborationVerdict` carries the identity in its OWN slot.** §B.1 lets a declared attribute share the identity's name, and the two are grounded at different locators; the Story 3.4 name-keyed map would have given one of them the other's verdict. Latent then, reachable now.
- **Generation 22: the rollup IS the derivation, and the FK widens to carry it.** `run_observation.corroboration` (`MATCHED`/`CONTRADICTORY`/`UNJUDGED`) is pinned to its own `identity`/`attributes` jsonb by a CHECK built out of `jsonb_path_exists` (the two-argument form is IMMUTABLE, so it is legal in a CHECK), and a second CHECK pins the per-attribute verdict vocabulary inside the jsonb. `run_observation_evaluation` carries the rollup too and the composite foreign key becomes `(observation_id, coverage, corroboration)` with `CHECK (value <> 'COMPLIANT' OR corroboration <> 'CONTRADICTORY')` — so "a record its own snapshot contradicts is never Compliant" is a foreign key, the Story 3.4 shape one column along. **`CREATE UNIQUE INDEX` has to be moved above the `ADD CONSTRAINT ... FOREIGN KEY`** drizzle-kit emits after it, and both backfills have to run before it, since adding a foreign key validates every existing row.
- **Unlike generation 20's digest, this column HAS an honest backfill and gets one.** A digest is SHA-256 over canonical JSON and SQL has no canonicalizer; a rollup is derived from columns that are already there, so the migration computes exactly what the CHECK then requires. `UNJUDGED` for a row registered before anything corroborated is what it is.
- **`tests/fixtures/snapshot-extraction-golden.json` is produced by `uv run scripts/make-snapshot-extraction-golden.py`** with Python `csv`, `json`, `datetime` and PyPI `rfc8785` — an independent locator parser, an independent CSV and JSON read, and an independent UTC normalization. The unit test asserts `producer` starts with `Python`. Its `sheet` vectors are the REAL `fixtures/northstar/generated/role-matrix.csv`, and the test requires the fixture to still hold that file's bytes, `entry` ordinal included.
- **An integration test for a hand-built batch needs population keys DISJOINT from the extraction.** `run_observation` is unique on `(work_item_id, population_record_key)`, so the adapter's own Observations take every key its population names; `DISJOINT_POPULATION` leaves the extraction rows free for a batch that grounds into them deliberately.
- **A value contradiction hides an identity mismatch.** `corroborateObservation` runs the identity-key comparison only when the identity attribute itself re-read faithfully, so a case meant to prove `identity-mismatch` must ground a real cell and bind it to the wrong population record — not record the wrong value at the right locator, which fails earlier as `value-contradicted`.

### Deterministic evaluation and Exceptions (added with Story 3.7)

- **There is one rules engine and Story 3.7 did not write it.** `evaluateComplianceRecord` in `packages/domain/src/procedures/plan-compiler.ts` already implements the approval and permission-pair rules, the closed applicability grammar, the exact decimal comparisons and the conservative evidence handling, over the conditions the Version FROZE. `packages/domain/src/runs/evaluation.ts` wires an Observation into it and maps the answer onto §B.1's shape; the reduction is the same `reduceComplianceEvaluations`. The whole rule is `docs/contracts/deterministic-evaluation-v1.md`.
- **The evaluation seam is built by the stage, not injected into it — the Story 3.6 lesson, one story along.** `ruleEvaluation` needs the frozen plan, the frozen included population and the Reference Source bytes this Run's own Session Steps froze; a composition root holds none of the three, so a seam it supplied could only ever be `NO_EVALUATION`. `AdapterExecutionDependencies` therefore lost `evaluation` and gained `exceptions`, the fingerprint key as a port.
- **A rule may read only the Template's DECLARED Observation fields.** P-2's `username` and P-3's `memo` are the seeded prompt-like strings; a value no rule can read is a value no rule can be steered by. The population supplies the base (P-3's `amount`, `currency` and `processed_time` live there and not in the approvals system) and the Observation's grounded attributes win. An `ambiguous` match gets NO boolean reading of `found`, so a condition naming it is `missing or invalid Observation field found` rather than quietly false.
- **A record key the included population carries TWICE resolves to `null`, never to one of the rows.** P-3's TX-500008 is 210,000.00 in one row and 215,000.00 in the other, and first-wins, last-wins and a union each answer a question the population cannot answer. `null` makes the record ambiguous, which is Unevaluated. P-2's AG-1007 is the same trap seen from the other side: the extraction carries it twice too, so the match is `ambiguous` as well.
- **A role expansion is a LIST of entries and the `entry` ordinal is the boundary.** The RoleMatrix declares `AMBIGUOUS_DUAL` twice with different permissions; merging them yields `CREATE_PAYMENT + RELEASE_PAYMENT`, a prohibited pair, and a confident Control Failure where the contract requires Unevaluated. Every read failure is `NO_ROLE_EXPANSION` (`incomplete role expansion`, therefore Unevaluated): a role expanded from half a file is indistinguishable from a role with fewer permissions, and the second reads as Compliant. Exactly one artifact must be readable as one — zero is incomplete and so is two.
- **The per-record Gate outcome outranks the rule verdict, through the evidence facts and not a second rule.** `observationEvidenceFacts` sets `complete: false` when ANY per-Observation check failed, and `evaluateComplianceRecord` then records every condition `UNEVALUATED` — including one the rule would have called an Exception. An Exception raised on a record whose identity did not corroborate is a finding about a record nobody has established the identity of.
- **`UNSUPPORTABLE_COMPLIANT` is a second lock on a door the evidence facts already close, and it never turns.** A COMPLIANT on a record that is not `COVERED`, or one its own snapshot contradicts, is REFUSED by `registerObservations` and by the composite foreign key — which rolls the whole batch, the Work Item and the Step Execution back. Degrading an outcome is the right failure; destroying a Run is not. Because the branch is unreachable while the two agree, `evaluation.test.ts` asserts the AGREEMENT over every coverage x corroboration rather than the branch.
- **Every row this evaluator writes carries origin `RULE` and no `rationale`.** Including one that records an Agent-Judged condition as Unevaluated: the origin says which evaluator wrote the row, and the deterministic one did. A free-text rationale is where retrieved content gets quoted back as the reason for an outcome — exactly what the seeded memos exist to catch. A rule's reason is its diagnostics.
- **A non-applicable condition stores COMPLIANT and says why.** Compiler 1 gives it that value and the record's evaluation is the compiler's fixed reduction over these values, so a second reduction here would be a second engine. `CONDITION_NOT_APPLICABLE` in the diagnostic is what lets Story 3.8's count of APPLICABLE conditions exclude it: a row saying only `COMPLIANT` is indistinguishable from a rule that was evaluated and passed.
- **The Exception is created by the FIRST `EXCEPTION` evaluation, in that transaction.** `exceptionIdFor(runId, observationId)` is a derived UUIDv8, never minted, so a redelivery reaches the row it already wrote; a unique index on `observation_id` and `ON CONFLICT DO NOTHING` say the same thing below the command. The fingerprint is HMAC-SHA-256 over the canonical JSON of five keys and the RUN IS DELIBERATELY ABSENT: a fingerprint identifies the FINDING, so the same control failure recurring next month is recognisable as the same one.
- **`EXCEPTION_FINGERPRINT_KEY` is the worker's alone, and without it adapter execution is DISABLED by name.** The `CREDENTIAL_TOKENS` trade, one line along: refusing to boot would stop plan derivation, notification delivery and the liveness row for a stage that could not run anyway, and an Exception with no fingerprint is a permanent row nobody can later check. The key reaches the evaluator as an `ExceptionFingerprinter` port with NO field holding it — `JSON.stringify` yields `{"keyId":"..."}` — the `ResolvedCredential` containment.
- **`sha256HexOfBytes` is now a rendering of `sha256Bytes`, and `hmacSha256Hex` chains the same function.** One implementation, so the hex form and the keyed form cannot disagree about what SHA-256 is. `tests/unit/sha256.test.ts` checks the HMAC against `node:crypto` at the three key lengths where RFC 2104 padding hides (shorter than a block, exactly a block, longer) and against the published RFC 4231 vectors.
- **Generation 23's two rules are triggers because neither is a CHECK: an Exception can never be UPDATEd, and never DELETEd while its Observation stands.** Removing a whole Observation is a different act — it takes the record and its digest with it, and the registration event still names both — so `run_exception.observation_id` cascades and the DEFERRED constraint trigger passes at commit. That is also why no teardown needed changing: `DELETE FROM run_observation` already carries the Exceptions away.
- **`verifyRegisteredArtifact` is now the verdict of `readRegisteredArtifact`.** A resumed Run needs both that the stored Reference Source is what it froze and what it SAYS; two functions that each read and compared would be two answers to one question.
- **P-3's TX-500007 has no per-record evaluation, and that is correct.** It carries no `processed_time`, so the frozen inclusion rule cannot place it in or out of the Period: Story 3.2 marks the row INDETERMINATE, it never reaches an Observation, and the `complete-inclusion` population Gate is what makes the Run Inconclusive. `tests/unit/golden-evaluation.test.ts` pins that this is the ONLY expectation case reached that way, and asserts the row's disposition and reason, so the branch cannot quietly absorb a record that simply went missing.
- **The golden expectations are asserted twice: in one second and in a real Run.** `tests/unit/golden-evaluation.test.ts` drives both populations through the production pipeline (inclusion rule, `buildAdapterObservations`, `snapshotCorroboration`, `ruleEvaluation`, `registerObservations`) and `tests/e2e/population.spec.ts` asserts every P-2 case again against the real worker, the real Northstar service and a real database. Both read the expectation files OFF DISK; runtime code never imports them (AD-12). Verified by mutation: first-wins on a duplicate population key fails P-3 D5, and merging RoleMatrix entries by role fails P-2 D5-c.

### The Run-level Evidence Quality Gate and limit mapping (added with Story 3.8)

- **`GATE_CHECKS` is a TRANSCRIPTION of addendum §H, and something compares it with the addendum.** Twenty rows, in the addendum's own order; `tests/unit/gate-vocabulary.test.ts` reads the §H table off disk and asserts the row set, the order, and — per row — whether `GATE_DIAGNOSTIC_STATE` can produce each state that row's "Failure outcome" cell names. A list asserted against a copy of itself proves only that it equals itself, and this one decides whether an audit Run may conclude. The whole rule is `docs/contracts/run-level-gate-v1.md`.
- **A row's failure outcome belongs to its DIAGNOSTIC, not to the row.** §H gives population acquisition and pagination/extraction completeness BOTH outcomes, so a table keyed by row loses half the addendum. `GATE_DIAGNOSTIC_STATE` is keyed by diagnostic and exhaustive by type. One failure genuinely lands on two rows: a Session Step whose `extract-adapter` acquisition failed is both `session-step-failed` (workspace access) and `acquisition-unavailable` (extraction completeness), and §H says so twice.
- **The Gate CONSUMES what earlier stories recorded; it never re-judges it.** Six rows roll up `run_observation_check` (Stories 3.4 and 3.6) and seven route `population_snapshot.checks` (Story 3.2) onto their §H row. `POPULATION_CHECK_DIAGNOSTIC` is `Record<PopulationCheckName, …>` and the observation table is `Record<ObservationCheckName, …>`, so a check added upstream without a §H row does not compile. That is why `POPULATION_CHECK_NAMES` became a closed union the reconciler is typed against.
- **`AdapterExecutionContext` EXTENDS `RunGateContext`, so there is no injection point.** The stage that finishes the last Work Item already holds everything the Gate needs; a composition root cannot omit or switch it off. Stories 3.6 and 3.7 both REMOVED such a seam rather than leave one, and a Gate that could be left out is a Run that concludes without one.
- **The Gate rows, every Timeline event, the terminal Run state and the Evidence package seal commit in ONE transaction.** `sealIfTerminal` runs inside it, and generation 21's deferred trigger refuses a Run reaching a terminal state without a package row — so a branch that forgot would fail to commit rather than ship an unsealed Run.
- **A Gate failure is never repaired by re-running a check, and the ROWS alone do not prove it.** `saveGateChecks` uses `ON CONFLICT DO NOTHING`, so removing the `readGateChecks` early return leaves the rows identical and appends a SECOND full set of Timeline events. The idempotency test asserts the event count as well; generation 24 refuses an `UPDATE` to `run_gate_check` in a trigger. `DELETE` stays permitted — removing a Run takes its Gate rows with it, which is a different act from rewriting one row's outcome.
- **`population_snapshot.generated_at` (generation 24) exists because §H's freshness row has to name WHICH way a snapshot is unfit.** Stale, future-dated and unknown are three different statements and an auditor acts differently on each; the stored pass/failed boolean beside it can say none of them. It is nullable, NOT backfilled and never defaulted to `now()`: a row an earlier build wrote reads as "unknown", which §H makes `INCONCLUSIVE` — the fail-closed direction — and a fabricated generation time would put a fact nobody measured into an audit conclusion.
- **`run_gate_check` keeps an EXACT `total` beside a bounded sample of at most 32 identities.** A Run over a hundred thousand records has to be able to commit its own conclusion, and the rows go onto the Result and into an immutable event. `tallyGateFindings` takes an ITERABLE so a producer walking the population never holds a hundred thousand findings.
- **The closed diagnostic vocabulary is pinned inside the jsonb by CONTAINMENT.** `diagnostics <@ '[...]'::jsonb` refuses a number, an object and an undeclared spelling alike, in one expression rather than thirty-three `jsonb_path_exists` clauses. The integration test asserts BOTH directions: an invented diagnostic is refused, and every diagnostic the domain has is storable — a CHECK that quietly refused a finding the Gate can produce would be found by nothing else.
- **`CANCELED` is never produced by a timeout or a limit.** `RUN_STOP_STATES` is `['INCONCLUSIVE','RUN_FAILED']` and a test walks every cause. `CANCELED` is reserved for a person cancelling (Story 3.10), and the §E.1 outcome rules read that state to decide what a human may do next.
- **The frozen limits are READ from the plan, never restated.** `exhaustedRunLimit(usage, plan.limits)` checks Step Executions, elapsed time and tokens in §E.1's order. Step Executions count ATTEMPTS — `startStepExecution` increments the counter where a Step Execution actually starts, so no branch can start one without spending the limit for it — and the count on the claim comes from `run_step_execution`, so attempts an earlier claim made before a restart still count. Tokens are 0 for every Run of this epic because the adapter path calls no model; the counter is passed anyway so the agent epic fills it rather than adding a limit that was never mapped.
- **`adapterAttemptBudget` is `(retriesPerStep + 1) x 2` and `sessionStepAttemptBudget` is `x 1`.** The owner's 2026-09-05 second cycle exists to let a Run CONTINUE past a failed unit; §E maps a Run-level Session Step's failure to `RUN_FAILED`, so a second cycle there buys nothing. Both are derived from the plan's own `retriesPerStep`.
- **A 401 or a 403 is `denied`, not `transport` — and a redirect is `scope`.** They used to land in `!response.ok`, so a Work Item was retried three times against a system that would go on refusing and the only durable record that the platform had been told no was a transport count. `PopulationAcquisitionError` gained `'denied'` and `'scope'`; both are terminal for the unit AND for the Run, and `stopRun` appends the `security.action-denied` event from `runStopFor(cause).securityEvent` rather than at each call site.
- **Duplicate Source primary keys are counted over EVERY parsed row, not only the included ones.** §H says "No duplicate Source primary key", and a duplicate inclusion happened to filter out is still two Source rows claiming one identity.
- **The required evaluation fields are the Template's declared Observation fields INTERSECTED with the binding's declared schema.** `COMPLIANCE_OBSERVATION_FIELDS` is the union across the population and every Target System — P-3 declares `decision`, which lives in the approvals system — so requiring all of them of a population row would fail a correct Run. The `required-evidence` trap of observation registration v1, one layer along.
- **The §H unnamed-value row matches §B's OWN sentence, `rule does not name value <v>`, and not the missing-field one.** `RULE_DOES_NOT_NAME_VALUE` is exported from `plan-compiler.ts` beside `MISSING_OBSERVATION_FIELD` and matched by the repository, because a retyped copy of either inside a SQL `LIKE` drifts silently the first time the wording changes. They are two DIFFERENT defects: a value the condition met and does not name, versus a value it names and could not read. Matching the second put every `ambiguous` record on the unnamed-value row as well — an `ambiguous` match has no boolean reading of `found`, so the compiler records `missing or invalid Observation field found` for it — and only the real golden P-2 journey in `tests/e2e/population.spec.ts` showed it.
- **A test file that writes Run rows must delete `run_gate_check` before `audit_run`.** It carries a real foreign key, and `adapter-execution.test.ts`'s `afterAll` failed silently on it — leaving 140 Runs, 237 bindings and 639 queue jobs in the shared test database, which then pushed three new bindings off `listBindings`' page and failed a Story 1.7 test that has nothing to do with any of it. Read the FIRST failure, and check the teardown when an unrelated suite starts failing on counts.
- **Story 3.8 changed where the adapter stage LEAVES a Run.** It used to end `RUNNING` with `EXTRACTION_COMPLETE`; it now ends terminal, sealed, with twenty Gate rows. Every Story 3.5 test that mutates `run_evidence` after `executeAdapterSteps` therefore needs `unseal()` first — generation 21 freezes a sealed Run's Evidence — and every resume test needs `audit_run.state` set back to `RUNNING` beside `run_execution.status='RETRY'`, because the stage refuses to claim a Run that is not RUNNING and the two commit together in real life.

### What a Run concludes: three repairs (2026-09-05)

- **§H's per-record coverage rule is per TEMPLATE, and it is now machine-readable.** The row says coverage is "computed over Observations per the Template's coverage rule (§C)", and the four §C rules genuinely differ: P-3 says "found or proven absent" in as many words and P-1's C1 makes a proven absence the Compliant finding, while P-2 requires every account to "appear in the extraction with a grounded role list" and P-4 requires each parameter grounded in the page. The generic `found ∈ {true, false}` reading was applied to all four, and under P-2 that made an account absent from its own Target System `COVERED` → its `found = true` applicability NOT APPLICABLE → compiler 1's COMPLIANT for a non-applicable condition. **An account whose permissions nothing could read passed its own control**, and `p-2-sod-conflicts.json` case D6 names that state Inconclusive. `TEMPLATE_COVERAGE_RULES` in `templates.ts` is `must-appear` / `found-or-proven-absent`, `observationCoverage` takes it as a REQUIRED input, and `must-appear` + `found = 'false'` is `UNINSPECTED` — which the generation-20 composite foreign key already makes impossible to call Compliant, so nothing downstream needed changing and no migration was needed.
- **It is a coverage rule, not a new check.** `search-completeness` still says whether the ADAPTER LOOKED and still PASSES for an honest P-2 absence; whether this Template accepts an absence as coverage is a different question. A new check name would have meant a new `run_observation_check` CHECK and a migration for nothing.
- **`templateCoverageRule` fails closed to `must-appear`.** The id comes from a frozen plan, so it is arbitrary text; `must-appear` can only DEGRADE coverage. It uses `Array.prototype.find`, not an object index — the `Object.hasOwn` trap, sixth occurrence.
- **A test of the honest-absence legs must run under a `found-or-proven-absent` Template.** Under `must-appear` every absence is `UNINSPECTED` whatever it proves, so the three legs decide nothing and the test would pass against an implementation that had none of them. `register-observations.test.ts` and the integration honest/dishonest test both moved to P-3; the P-2 case is a separate test that names the rule it exercises.
- **An unaccounted population row no longer ends the Run at acquisition.** `POPULATION_CHECKS_DECIDED_AT_THE_GATE` in `population.ts` holds exactly `complete-inclusion`, and `ready` excludes it. §H's early-stop row is "Population acquisition", which is about acquisition FAILING; an indeterminate row is not that, and §E decides the Gate rows "after the last Work Item". The OUTCOME is unchanged — the failing check is on the checkpoint summary, reaches the Run-level Gate and makes the Run `INCONCLUSIVE` on `count-reconciliation-inclusion` — only WHEN it is decided, and what exists by then. Every other check still stops the Run where it did: those are about whether the BYTES are what they claim to be, and a Run that cannot trust its bytes has nothing to execute over. Before this, twelve of P-3's thirteen named golden cases could not be produced by a Run at all: `TX-500007` has no `processed_time`, so one indeterminate row ended every P-3 Run before its first Work Item, and only a hand-built unit test that called `includePopulation` itself and filtered to `included` ever saw them. `tests/e2e/population.spec.ts` now runs the P-3 journey against the real worker and the real synthetic ApproveNow service.
- **`complete-inclusion` is RECOMPUTED at the Gate, not routed.** `runGateChecks` already derives `rows-unaccounted` from the counts — deliberately, because the stored boolean is what a defect in the counting would have written — so routing the boolean as well reported ONE unaccounted row as two. `RECOMPUTED_POPULATION_CHECKS` in `gate.ts` skips it in the routing loop; `total` is exact and is what the Result shows. Unreachable before, because a failing `complete-inclusion` never reached the Gate.
- **An evaluation port answers about EVERY Observation it was given, exactly once.** `registerObservations` refuses anything else as `evaluation-shape`. A short answer leaves those Observations with no evaluation row, which downstream is indistinguishable from a frozen plan whose Compliance Rule this build cannot recompile — §H's condition-completeness row reports both as `condition-evaluation-missing` and nothing says which happened. "Nothing judged this" is therefore a result carrying NO evaluations, never an omitted result: `NO_EVALUATION` and `ruleEvaluation`'s unknown-Template branch both map every subject. Returning `[]` there would now REFUSE the batch, and a refusal rolls the Work Item and its Step Execution back — destroying a Run where §H only wanted to degrade it.
- **A §H row must never PASS for want of a fact.** `condition-completeness` counted gaps against `plan?.inputs.complianceConditions.length ?? 0`, so a Run whose plan could not be read compared every Observation against zero conditions, found no gaps and PASSED. `runRunLevelGate` fails that row outright when `plan === null`. The adapter stage refuses such a plan as `unsupported-frozen-plan` before its first Work Item, so this is the second lock on that door — and `run-gate.test.ts` exists because that makes the branch unreachable from the composed stage, and a branch nothing exercises is a branch that can be inverted silently.
- **An unqualified `LIMIT 1` over "the rows in this state" picks a row a later change can add to.** `adapter-execution.test.ts` selected `WHERE coverage='UNINSPECTED' LIMIT 1` to get the row it had just inserted by raw SQL; the P-2 coverage rule made a real Observation UNINSPECTED too, and the test's next raw insert collided with that Observation's real check outcomes. Scope such a select to the key the test itself wrote, and order it.

### Evidence integrity repairs (2026-09-06)

- **An adapter extraction's Evidence scope carries the ATTEMPT; a Reference Source's does not.** A Work Item freezes its response BEFORE it parses it and keeps failed bytes registered — both deliberate, because a response that is not a declared collection is still what the Target System answered. What follows is that a second attempt has different bytes to freeze, and `putIfAbsent` reconciles rather than overwrites: with a key derived from the step id alone, every retry read back attempt 1's object, found a digest that did not match, and died with `extraction-integrity-failed` against a system that was answering perfectly well. One gateway maintenance page therefore spent all eight attempts and cost the Run that system's coverage, and **the owner's two bounded retry cycles were decorative for exactly the transient failure they exist for.** `adapterExtractionScope(stepId, attempt)` puts the attempt in the name. A crash does not advance the attempt counter, so a resumed attempt still derives its own key and reconciles with its own bytes — Story 3.5's idempotency is unchanged. The number is durable before any upload: the reservation commit persists `item.attempts` before `extract` is called. `item.evidenceId` is deliberately NOT carried in as the prior id — it names the previous attempt's row, and adopting it would give that row this attempt's object key and lose the earlier artifact. A Session Step is acquired without being parsed, so its retries only run when nothing was frozen at all, and it keeps a scope with no attempt in it.
- **A failed Work Item therefore leaves EIGHT abandoned reservations, not one.** That is the truthful record of eight attempts, and `adapter-extraction` is not `required`, so the package still seals. The test asserts they are DISTINCT: eight entries naming one artifact would mean the key never varied.
- **A Reference Source is refused at acquisition unless its media type is one the extractor can actually read.** `acquireReference` accepted any 2xx body, so an HTML proxy error page became a REGISTERED required artifact and the package sealed while the Run page printed "Sealed. Every artifact this Run required is registered and verified" over it — the one claim Story 3.5 exists to make true, wrong. The list is `isReferenceSourceMediaType` in the DOMAIN, the same list the snapshot extractor reads, so acquisition refuses exactly what nothing could read rather than a second list that drifts. The Session Step then fails, §E makes that `RUN_FAILED`, and the abandoned reservation makes the package INCOMPLETE, which is true. A cover-sheet path is NOT guessed from the artifact's name: reading a guarantee out of a URL's spelling makes it a naming convention anybody can satisfy by typing.
- **`observed_at_source` is re-derived at the integrity recomputation.** It sits outside the thirteen hashed wire keys and has no CHECK, so an `UPDATE` rewriting it left the digest matching and a redelivered batch reported the row as already registered. `readObservations` selects it and registration requires `normalizeObservedAt(stored.observedAtSource).observedAt === stored.record.observedAt`. It is NOT added to the digest: that envelope is §B.1's and is pinned by an independently produced Python vector.
- **`verifySealedPackage` finally has a caller.** `startEvidenceIntegritySweep` is a bounded page per tick over terminal Runs with its own keyset read, the shape `startPopulationRecovery` and the probe runner use. It is inside the `evidence.enabled` branch, so an unprovisioned bucket disables it rather than crashing the worker (the PR 23 lesson), and it imports NOTHING — it takes its ports — so adding it to the barrel the web reads does not drag the storage client into the web bundle.
- **Never edit a shell script while it is executing.** bash reads a script by BYTE OFFSET as it goes, so inserting text mid-run leaves the running shell resuming at an offset that is now the middle of a different line. The gate script was edited during a run and every step after that point executed garbage — printing a `command not found`, then a stream of `FAIL` lines that were fragments of the edit rather than results. The steps BEFORE the edit are still real; everything after it must be discarded and the run repeated. Same class as editing source during a browser run, which crashes Turbopack and produces failures that are not product defects.
- **A verification script must exit non-zero when any step fails.** `gates.sh` echoed `FAIL` per step and then exited 0 regardless, so a background completion notice read as an all-clear over a failing gate. It tracks a flag and ends with `GATE PASSED` or `GATE FAILED`. An absent signal that looks like "fine" is the defect shape this project keeps finding; a harness is not exempt from it.
- **A test that waits on a queue row and then reads an in-process counter has a race.** `plan-recovery.test.ts` waited for the delivery row to reach `completed` and then asserted both handler invocations had been observed; the row goes final slightly before the last invocation is visible here, so it read `[1]` about one run in three. Wait on BOTH facts. A regression where the retry never happens still fails, on the timeout message rather than on a bare count mismatch.

### The sealed Result and the System Outcome (added with Story 3.9)

- **`OUTCOME_ROWS` is a TRANSCRIPTION of addendum §E.1 and something compares it with the addendum.** Seven rows, in the addendum's own order, with the first, second and fourth cells verbatim; `tests/unit/outcome-rules.test.ts` reads §E.1 off disk and compares them cell by cell. The rows apply IN ORDER and the FIRST match wins, which is why they are an array of predicates walked with `Array.prototype.find` rather than a chain of conditionals anybody can reorder without noticing — and why there is no lookup keyed by anything a caller supplies. The whole rule is `docs/contracts/run-result-v1.md`.
- **A passed Gate is NECESSARY and never sufficient for Pass.** The Gate asks whether the Evidence supports a conclusion; the outcome asks what that conclusion is, and deriving either from the other is the mistake this story exists to prevent. `gatePassed` is read from the twenty `run_gate_check` rows Story 3.8 wrote and the evaluation facts from the `run_observation_evaluation` rows Story 3.7 wrote. FEWER than twenty rows is not a pass either: a Run stopped by a limit or a denial never reached the Gate, and an unrun Gate is not a passed Gate — the `snapshot-generation-unknown` reading. `run_result_pass_requires_gate` says the necessary half where nothing can route around it.
- **Rows 4 to 7 do not repeat "Gate passes" in their predicates, because row 3 already did.** By the time the walk reaches row 4 the Gate passed; writing the precondition into each of the four as well would be four copies of one fact, and the copies are what drift. The consequence is that the ORDER carries the precondition, which `outcome-rules.test.ts` asserts by driving a Run whose Gate failed and every evaluation fact is set.
- **Row 5's "(by human rejection)" is PROVENANCE, not a predicate.** Made one, an `UNEVALUATED` of any other origin would match no row at all and fall through to Pass, whose own cell requires "every condition on every record Compliant". Read as provenance the table is TOTAL — rows 1 to 3 cover every terminal state but COMPLETED, rows 4 to 7 partition (pending) × (Exception) × (Unevaluated) — and `systemOutcome` THROWS rather than defaulting, because a default would quietly become the eighth row.
- **All seven rows ship even though this epic can reach five.** Epic 3 produces evaluations of origin `RULE` only, so nothing is ever `pending` and row 4 cannot fire; row 5 fires by human rejection, which is Epic 6. Both are tested with a constructed state, in `complete-run.test.ts` and against PostgreSQL — the whole §E vocabulary landing at once, exactly as `procedure_version.state` and `GATE_CHECKS` did.
- **`sealed` means FINAL, and only `PENDING_CONFIRMATION` is not.** §E's "a Result seals when the Gate has passed and no evaluation is pending" describes the COMPLETED path, the only one where sealing is a decision rather than a consequence; a Canceled, Run Failed or Gate-failed Run has nothing left to decide and its outcome can never change either, so calling those unsealed would say the opposite. `version` is 1 on write, and generation 25's trigger permits exactly ONE update — the sealing of a pending Result, which must seal and must raise the version by one — and refuses every other, including a re-statement of what is already there.
- **`completeRun` replaces `sealIfTerminal` at every terminal transition, in both producers.** `RunResultContext` is extended by `RunGateContext` and by `PopulationExecutionContext`, so there is no seam a composition root could omit — the Stories 3.6/3.7/3.8 discipline. `audit_run_requires_result` is a DEFERRED constraint trigger beside generation 21's: a branch that reaches a terminal state without a Result fails to commit rather than shipping a Run nobody can read.
- **The order inside the transaction is load-bearing: decide, move the Run state, seal the package, publish, write.** Row 5 is §E's `COMPLETED → INCONCLUSIVE` "only at Result sealing", so the state is taken BEFORE the package is sealed — otherwise `run_evidence_package.run_state` records a state the Run left in the same transaction.
- **`requiredTargetSystems` and `includedRecordKeys` moved into `gate.ts`.** The Result's coverage counts and the §H per-record coverage row are the SAME matrix, decided by the same `coverageFindings`; two derivations of its axes would be two answers to one question, and here the divergence would be a Result that disagrees with the Gate it reports. `OBSERVATION_CHECK_DIAGNOSTIC` is exported from `run-gate.ts` for the same reason — the golden reconciliation rolls the per-Observation checks up through the command's own table rather than a retyped copy.
- **`TEMPLATE_RESULT_FIELDS` is transcribed from each §C block and only names fields the Template DECLARES.** A Result that published every attribute would print the seeded prompt-like strings beside the outcome they must never influence; P-2's prohibited pairs come from the compiled rules' own diagnostics rather than from a second role expansion. `outcome-rules.test.ts` reads §C off disk for each of the four.
- **A test whose Gate failure and Exception land on the SAME record proves nothing about the order.** Duplicating the conflicted account made its population row ambiguous, so the evaluator recorded UNEVALUATED and the Exception the ordering test needed had never existed. The duplicate has to be a different account: the Run then really produces both, and row 3 winning over row 6 is observable.
- **The `gatePassed` fact is redundant with the Run state for every producer that exists, and is kept anyway.** `runRunLevelGate` sets INCONCLUSIVE/RUN_FAILED before completing, so hard-coding `gatePassed: true` passed every integration test; only `complete-run.test.ts`'s constructed nineteen-row Gate caught it. It is the second lock on the door `run_result_pass_requires_gate` holds, and it is tested where it is reachable.
- **The Result's coverage COUNTS are over included rows; its named sample is deduplicated.** A population that carries one key twice is two included rows and one record, and `coverageFindings` produces a finding per row — so `inspected + uninspected` equals `population.included` and an auditor can check the arithmetic, while naming the record twice would read as two records. The Gate's own `affected` lists dedup for the same reason.
- **A file that raises real Exceptions cannot `DELETE FROM run_exception` in its teardown.** Generation 23 refuses to delete an Exception while its Observation exists, and `run_exception` cascades from `run_observation` — so removing the Observation is what carries it away. `run-gate.test.ts` deletes it first and never notices, because nothing there raises one.
- **Every test file that writes Run rows must now delete `run_result` before `audit_run`** — the fourth table to join that list after `run_gate_check`, `run_evidence_package` and `run_evidence_integrity`. A teardown that does not know about a new table takes the whole file's cleanup with it, and the next run of an unrelated suite then fails on somebody else's leftovers: 162 Runs and 1097 queue jobs survived one failed run here and pushed two Evidence packages off the first page of a keyset read.

### Cancelling a Run and starting a linked rerun (added with Story 3.10)

- **Who performs the `CANCELED` transition depends on who owns the Run, and the domain owns the table.** `RUN_CANCEL_TRANSITIONS` in `packages/domain/src/runs/run.ts` maps each of the four ACTIVE states to `command` or `worker`. A `QUEUED`, `PAUSED` or `AWAITING_AUDITOR` Run has no process holding it, so `CancelRun` transitions it AND removes its dispatch job in one transaction — leaving a "cancel requested" marker on a queued Run would mean it is cancelled only if a worker eventually collects it, which is exactly backwards. A `RUNNING` Run is held under a lease by a worker mid-transaction, so the request is recorded and honoured at the boundary that worker already commits at. All four states are in the table although this epic produces two, for the same reason the whole §E state vocabulary and the whole §E.1 outcome table landed at once.
- **A cancellation IS a terminal transition, so it goes through `completeRun` like every other one.** `performCancellation` in `packages/application/src/runs/cancel-run.ts` is the ONE place a Run becomes `CANCELED` — the web command and both worker stages reach it — and it writes the state, the Timeline event and the Result together. Generation 25's deferred trigger refuses a Run reaching a terminal state without a Result, so a bare state update fails to commit rather than shipping a Run nobody can read.
- **`CANCELED` is the one §E.1 outcome that does not require the Gate to have run.** A Run cancelled while queued has no Gate rows, no Observations and no Evidence beyond what it had already frozen; its Result records `gatePassed: false` with `checks: 0`, and the `canceled` row is first in the table and matches on the state alone. Do not fabricate a Gate result to make it look like the others.
- **Cancel-meets-claim is decided by the Run's own row lock, not by the configuration advisory lock.** `PostgresRunCancellationRepository` takes `SELECT … FOR UPDATE` on `audit_run`, exactly as the two worker-stage repositories do, and deliberately does NOT take `pg_advisory_xact_lock(20428, 1)`: cancelling reads no Active version set, and serializing every cancellation against every configuration write buys nothing. Removing the `FOR UPDATE` makes the held-open race test fail.
- **A held-open race test must close its transaction in the `finally`.** The first version released the claim in a `finally` and awaited it AFTER the try/finally, so a failed poll left the transaction dangling; the file's own cleanup then raced a commit still in flight and left a Run, a Procedure and five versions behind for a later suite to trip over. `release()` and `await claim` both go inside the finally.
- **A rerun is a new Run, and its Procedure and period come from the PREDECESSOR.** `rerunRun` shares `createRun` with `initiateRun`, so there is ONE creation path: the request-token idempotency check, the active-Run check, the period owner resolved AFRESH, the insert under the partial unique index, the dispatch and the first Timeline event. Resolving the owner afresh is what makes a rerun after a handover run the version that NOW owns the period, and is why a period with no `ACTIVE` owner is refused with initiation's own `NO_RUN_OWNER` sentence. A caller that could supply the Procedure could point a "rerun" at a different one entirely.
- **There is deliberately NO `run.rerun` gated action.** A rerun starts a Run, so it is gated by `run.initiate`. `roles.test.ts` asserts all 24 actions against all 3 roles, so a synonym would break a completeness claim about a table transcribed from EXPERIENCE.md character for character.
- **The rerun link is on the NEW Run's row and its own chain, and nowhere else.** No event is appended to the predecessor's aggregate, which turns "the predecessor is unchanged" from a promise into a check: `tests/integration/cancel-run.test.ts` compares the whole `audit_run` row, the whole `run_result` row and `audit_event_heads` before and after.
- **The cancellation marker is four columns written whole or not at all, and the FIRST request wins.** `(a IS NULL) = (b IS NULL)` is boolean = boolean and is never NULL, so unlike a comparison of the values a NULL CHECK cannot pass here. `DrizzleRunRepository.requestCancellation` guards on the marker still being absent, so a second person cannot overwrite the requester, the time or the reason the Canceled Run Detail then reports; the command refuses the duplicate above it and appends nothing.
- **Neither surface collects a reason, and the domain supplies the sentence.** EXPERIENCE.md's confirmation table puts cancel AND rerun under the ROUTINE weight, which restates the consequence and has no rationale field — unlike the "routine with rationale" weight a Result rejection gets. The commands accept an optional bounded reason for a caller that has one; the web passes none, and `RUN_CANCELED_DEFAULT_REASON` / `RUN_RERUN_DEFAULT_REASON` are what is recorded. A blank reason would read as a missing fact rather than as an absent note.
- **A cancellation observed at a boundary beats a limit observed at the same boundary.** The check runs before the limit and attempt computation in both stages, so a Run whose deadline had passed and whose cancellation had been requested records `CANCELED`. That is not a limit producing `CANCELED` — a person did, while the Run was still `RUNNING` and nothing had yet recorded the limit — and it is the only ordering that keeps a named actor on the outcome. The reserved-state rule is unchanged: `RUN_STOP_STATES` still holds `INCONCLUSIVE` and `RUN_FAILED` only, and a test walks every stop cause.
- **A unit already running finishes and commits; only the NEXT one is refused.** `canceledAtBoundary()` runs before each Session Step and each Work Item, inside the same guarded transaction that writes, so the Evidence, Step Execution and Observations of the unit in flight all survive. The Run-level Gate is deliberately NOT gated by it: a Run that has finished its last Work Item should conclude rather than be cancelled.
- **A partial reservation is left OPEN and named by the seal.** Nothing on the cancellation path touches an Evidence row or an artifact; `SealPackage` is the one thing that abandons a reservation, so a Run cancelled mid-acquisition seals INCOMPLETE and lists the reservation as abandoned rather than dropping it.
- **`predecessor_run_id` is a self-referencing foreign key, so a teardown deletes successors first.** `DELETE FROM audit_run WHERE procedure_id=… AND predecessor_run_id IS NOT NULL` before the unqualified delete, in `tests/integration/cancel-run.test.ts` and `tests/e2e/runs.spec.ts` alike.
- **Never `DELETE FROM audit_events WHERE actor_id = …` in a teardown.** A `security.denied` event has no aggregate and is chained under `platform`, so removing one takes a row out of the MIDDLE of that chain and `procedures.test.ts`'s "the platform chain is verifiable" test then fails for a reason that is not its own. Leave the denial where it is; `audit_events` has no key to the user anyway.
- **The Cancel and Rerun controls require JavaScript, deliberately, and say when they are ready.** EXPERIENCE.md requires a focus-trapping confirmation dialog on every mutating action, which cannot exist without script — the same trade the administration mutations record — and both fail SAFE: a click before hydration does nothing and the Run is visibly unchanged. `RunLifecycleActions` carries `data-client-ready` on `#run-lifecycle` and the browser journey asserts it before every click. Without that, the click after the full-document navigation to the successor Run passed standalone and hung for the whole 120-second timeout inside the full suite.

### Seeing a Run: the Runs list and the five Run Detail tabs (added with Story 3.11)

- **Run Detail is five ROUTES, and each authorizes for itself.** `apps/web/src/runs/detail.tsx` exports `openRun` (authorize, THEN resolve the Run) and `RunDetailFrame` (trail, header, badge, refresh banner, tabs, cancellation state, action bar), and every one of the five pages calls both. It is deliberately not a `layout.tsx`: a page that forgot to authorize would still be wrapped by a layout that did, and "every tab authorizes for itself" would be a convention again. `Tabs` renders links in a `<nav>` with `aria-current`, never `role="tab"` — a tablist with no tabpanel announces a widget the page does not have.
- **`rendersOwnTrail` now covers `/runs/**`, and it was a live defect.** Story 3.10's Run Detail rendered its own `<nav aria-label="Breadcrumb">` while the shell rendered a second one, so the page had two landmarks nobody could tell apart and the first showed a raw UUID. The accessibility gate CANNOT see it: `landmark-unique` is best-practice, not WCAG-tagged, so it never reaches `results.violations`. `breadcrumb-rules.test.ts` is the guard.
- **A stored `jsonb` document is request-shaped input, and `run_result.publication` proved it.** Its CHECK says only that the value is an object, so `{}` is storable — and the Result tab reached into `publication.population.rowsParsed` and answered a framework 500 for the whole Run. `isRunResultPublication` in `packages/domain/src/runs/result.ts` is the structural validator; `readResult` returns `publication: null` when it fails, and the surface still shows the outcome, the seal and the version, because those are typed COLUMNS. Generation 25 refuses to UPDATE a sealed Result, so a test for this has to SEED the empty document rather than patch one in.
- **Timestamps are ISO 8601 UTC with `Z` on every Run surface.** EXPERIENCE.md's Formats row fixes it; Story 3.10 rendered `2026-09-06 09:00:00 UTC`, which is not ISO 8601. `utcStamp` in `apps/web/src/runs/labels.ts` is the one renderer.
- **Tables become label/value stacks at 1023px, not 899px.** EXPERIENCE.md's responsive table puts the stacking in the 900–1023px band and gives the `< 900px` row only the Builder's desktop-only note; the stylesheet stacked at `< 900px`, leaving that whole band scrolling a table the contract says should be stacked. `1024–1239px` now also pins the identifier column with `position: sticky`, which is the other half of that row.
- **`stylesheet.test.ts` now SCANS the components for `ls-` class names** instead of enforcing a hand-kept list, and found `.ls-actions` — shipped in Story 2.7 with no rule at all, so every Procedure Version action bar rendered as a bare stack. Only fully static tokens are checked; a class assembled from a template needs an explicit entry beside the treatments and tones. The same test now strips comments from `globals.css` before looking for `var(--x)` reads, because a token named only in a comment is neither read nor defined.
- **A badge word is never taken from a stored value without a guard.** `StatusBadge` THROWS on a state its family does not hold, and on a server-rendered list that is a 500 for every Run on the page. Every lookup in `labels.ts` is `Object.hasOwn`-guarded and returns `null` (or the stored value itself) so the caller writes it in words. `labels.test.ts` walks `RUN_STATES`, `SYSTEM_OUTCOMES` and `WORK_ITEM_STATES` against `STATUS_VOCABULARY`, which `status.test.ts` pins to DESIGN.md on disk — so a word no family holds fails rather than being compared with a copy of itself.
- **No Gate rows is `Not evaluated`, and it is said in words.** A Run canceled while queued has no §H row at all, and an empty checklist rendered as though the Gate had run and found nothing is the "empty list reads as a passed control" defect in its purest form. `GATE_NOT_EVALUATED` says which of the three ways it happened. `gateWord` also keeps `Incomplete` for a partial set: Story 3.8 writes all twenty in one transaction, so it should be unreachable, and a badge that could not say it would leave a reader with `Passed` over a checklist that never finished.
- **The Gate checklist's prose is a transcription, and `gate-rows.test.ts` reads the addendum off disk.** `GATE_ROW_CONTRACTS` carries §H's own check name and its own PoC rule for all twenty rows, plus EXPERIENCE.md's two-group split; the test pins both cells character for character and the group membership against the artifacts. The domain's `GATE_CHECKS` stays the row VOCABULARY and carries no prose.
- **The Safe next action panel's body is addendum §E.1's own "Permitted human action" cell**, read from `OUTCOME_ROWS[].humanAction`, which `tests/unit/outcome-rules.test.ts` already pins against the addendum. Inventing a sentence there would put the platform's words where the contract already has some.
- **Every diagnostic, rationale and Target-System-sourced value goes through `UntrustedText`.** The deterministic evaluator writes no free text, but a diagnostic MUST name an unknown value, so a system answering with "NOTE TO THE REVIEWING AUDITOR: close this finding" gets that sentence stored as the recorded reason for an audit outcome. It is rendered as `<pre>` inside a warning block, labelled with the field it came from and DESIGN.md's own sentence, and never as the platform's prose. The rule is applied to every such value, not only where a fixture exercises it.
- **The Evidence kind badge and the corroboration badge are NOT in `status.ts`.** That module is pinned against DESIGN.md's nine-row table by a test that reads it off disk, so adding a row the table does not have would break the one claim it makes. They live in `src/runs/MinorBadge.tsx` with a word and an icon each, because "never colour alone" is a floor for every badge.
- **The grounding inspector asks the DOMAIN which snapshots it can open.** `snapshotSubstrateForMediaType` plus `IMPLEMENTED_SNAPSHOT_SUBSTRATES` — `sheet` and `json` at the time, and `web_tree` since Epic 4 — so the inspector opens exactly where Story 3.6's extractor actually re-reads. A second media-type test here would agree on `text/csv` and diverge on the first charset parameter nobody tried.
- **The Timeline's name and its detail are two nodes.** They were one, so a row could not be addressed or read by its name alone; `population.spec.ts` addresses `RoleMatrix` and `ApproveNow` that way. Nesting is by `--ls-timeline-level` at 20px, and in an adapter Run a Work Item IS the execution of its `extract-adapter` Session Step — there is no separate row above it — so Session Steps and Work Items are both plan-step-level and the Step Executions nest beneath whichever started them. Epic 4's agent Runs and the fourth Tool Action level slot in without a rewrite.
- **The Runs list is its own read, keyset-paged on `(initiated_at, run_id)`.** A surface must not borrow another read's shape and a job must not borrow a surface's (Story 1.8). `run_id` is a UUIDv7, so it is a deterministic tiebreak rather than an arbitrary one — and a keyset page needs a TOTAL order or a row appears on two pages, or on none. A cursor naming a Run that is not there is the first page, never an error.
- **A bound JS array becomes a RECORD in a `sql` template, not an array.** `${ACTIVE}::text[]` and `ANY(${ids}::uuid[])` both raised `cannot cast type record to …`. The active-state list is interpolated with `sql.raw` behind a `/^[A-Z_]+$/` assertion at module load (it is a frozen domain constant, not request input); the fingerprint read goes through the query builder's `inArray`.
- **The Change column is fingerprint-based and only across compatible versions.** Story 3.7 put the Run deliberately outside the Exception fingerprint, so the same finding recurring next month is recognisable; the previous TERMINAL Run of the same Procedure is found with a lateral join, and a different `version_id` gives EXPERIENCE.md's verbatim `Not comparable — versions differ`. An in-flight Run reports absence rather than a diff against a set still being written.
- **`Missed 06:00 UTC start; not run` and the two disabled-Submit sentences are transcribed into `copy.ts` and NOT rendered.** Epic 3 initiates every Run by hand, so nothing could truthfully fill `{time}`; Story 6.3 is what submits a Result, and a disabled control whose action does not exist is worse than a control that is not there yet. Quoting them now is what stops the later story retyping them.
- **A browser run reads the packages' `dist`.** `next dev` resolves `@intellifin/domain` and `@intellifin/infrastructure` through their built output, so `pnpm build` is a precondition for the browser suite AND must be re-run after every package edit while iterating on it. A stale `dist` showed up as the exact defect the new code had just fixed.
- **A teardown that deletes a Run must delete `run_evidence_integrity` first, and must delete the OBSERVATION rather than the Exception.** The worker's post-Run integrity sweep writes findings against a seeded artifact whose object was never uploaded, and generation 23 makes an Exception permanent while its Observation exists (deleting the Observation cascades it away). A teardown that fails leaves rows that make an unrelated suite's empty-list assertion fail — read the FIRST failure, and check the teardown.

#### What Story 3.11 found with no data behind it

Both are stated on the surface in words rather than shown as a dash, and both are named here so a later story fixes the WRITE rather than the read:

- **`[CLOSED 2026-09-06]` No Evidence table recorded a capture time.** FR-31 requires "Work Item, Target System, Step, capture method, capture time in UTC, and integrity digest" on every Evidence item, and neither table had a column for one, so the instant was DERIVED from the Step Execution and the METHOD from the kind. Generation 32 stores all three fields on both tables; see "Owner decisions" below. The read no longer derives anything.
- **`[CLOSED 2026-09-06]` The independently declared record count was never persisted.** `reconcilePopulation` checked `d['count']` and stored only the `declared-count` pass/fail boolean. Generation 32 stores the declared and the retrieved count, each attributable to the artifact it came from; see "Owner decisions" below. The web still may not read object storage and `no-evidence-store-in-web` still fails the build on it.
- **The Review tab and the Review column have no data by DESIGN, not by omission.** Epic 3 creates no Auditor Review; Story 6.3 submits one. The column shows the contract's absent marker with a spoken sentence beside it, and the tab says what would appear — never a "Draft" badge for a review nobody started, which is Story 2.1's "Active version: Draft" defect in a new place.
- **An accessibility scan that runs while a navigation is committing reads the wrong document.** `executable-plan.spec.ts` failed once in a full-suite run with a `document-title` violation of `serious` impact, and passed alone immediately afterwards — the shape of a race, not of a missing title, and the page does set one. The preview POLLS, so a refresh can be in flight when the scan starts, and a navigation that has begun committing briefly has no `<title>`. Assert the title BEFORE scanning: it removes the race and asserts something true, since WCAG 2.4.2 requires that title and the page has it. Do not re-run an intermittent accessibility failure until it is green — the gate has no allowlist precisely so that a violation cannot be waved through, and an intermittent one is the kind that ships.

### Signing in, and the gate every Tool Action passes (added with Story 4.2)

- **The action gate is at the port's CALL SITE, in `packages/application`, and never in the provider adapter.** `performToolAction` in `execute-agent-steps.ts` is the ONLY path from a stage to `BrowserExecution.perform`, and it calls `authorizeToolAction` first. An adapter that enforced its own allowlist would make the guarantee a property of that adapter, and the whole point of the port is that the provider can be replaced — the containment shape this codebase uses everywhere: the correct path is the only reachable one. The workspace's request interception is the SECOND boundary, not the first, and `tests/integration/agent-execution.test.ts` calls the port DIRECTLY with the gate bypassed to prove the second one exists. The whole rule is `docs/contracts/tool-action-v1.md`.
- **The gate reads the VERSION's frozen bytes and nothing else**, in a fixed order: the action against `permitted_actions`, then the destination against `allowed_origins`, then every parameter VALUE against the Run's frozen population. First refusal wins, so one action gives one reason rather than a list a reader has to rank. A write action is not expressible — `PermittedReadAction` is eight literals and every member observes — and the membership test is `includes` over the frozen array, never an object index, because the action is request input (`Object.hasOwn`, seventh occurrence).
- **An empty `scopeValues` denies every parameter.** Fail-closed: a stage that has not put the frozen population in front of the gate has not proved a value is inside it, and "no scope" must never read as "no rule". Story 4.2's sign-in carries no parameters, so the first PRODUCTION caller of the parameter rule is the story that searches (4.5); it is exercised by unit, application and integration tests today rather than left as a branch nothing runs.
- **`withinFrozenOrigin` in `packages/domain/src/runs/tool-action.ts` is now the ONE home of "stay inside the frozen origins".** It is written over STRINGS because `packages/domain` and `packages/application` have no host types at all — the compiler-enforced half of AD-11 — so there is no `URL` there and a gate that could not ask the question would have needed a second copy of the answer. `packages/infrastructure/src/runs/origin-policy.ts` became a `URL`-shaped door onto it (`withinOrigin(o, c) => withinFrozenOrigin(o.href, c.href)`), which is safe because `URL` has already normalized the spellings a browser produces. It REFUSES a dot segment rather than resolving one: normalizing would be doing the browser's job with the browser's rules, and the two only have to disagree once.
- **`sanitizeDestination` STRIPS where `parseFrozenLocation` REFUSES, and the difference is the point.** A destination denied FOR carrying `user:pass@` must still be recorded, and recorded without them. `safeDestination` in `browser-execution.ts` is now a rendering of it, so the log and the gate cannot disagree about what a destination is.
- **`run_tool_action` is ONE table and ONE shape for both surfaces** (generation 28), because AD-6 says it in as many words: "every lookup or extraction is an Adapter Action on the Timeline with the same sanitized-action schema". `surface` is the only field that distinguishes the producers. Story 4.2 writes the `agent` rows; **the adapter path writes none yet**, and that is named rather than counted — the SHAPE is here so it is not invented twice.
- **A 401 from a Target System is `performed` with `status: 401`, not `denied`.** The action HAPPENED and the system said no, which is a different fact from a gate refusal that never left. Both are terminal, both carry `security.action-denied`, and neither is ever a transport failure: Epic 3 paid for that once. `run_tool_action_denied` is ONE CHECK — `(outcome='denied') = (denial IS NOT NULL)` — because either half alone permits a row that reads as the other.
- **`run_session_step` gained an `action` column, and the ACQUIRED constraint had to read it.** `run_session_step_acquired` required Evidence on every ACQUIRED step, which is right for a Reference Source acquisition and refuses exactly the row a successful sign-in writes: a sign-in establishes a session and freezes nothing. The constraint now says what it always meant — an ACQUIRED ACQUISITION has Evidence. The migration adds the column with a DEFAULT, backfills, and DROPs the default, because `ADD COLUMN ... NOT NULL` fails on a table that already holds rows.
- **`acquirePopulation` read `sessionSteps[0]` literally, so every agent Run was refused before anything could sign in.** The compiler emits `create-workspace` FIRST whenever a Target is agent-driven, so the population step is at index 1 in an agent plan. `populationSessionStep(plan)` is where the compiler's own ordering now lives, and it is a POSITION check rather than a search: a plan that puts the population step somewhere else is a plan this build did not compile. It also refuses a `create-workspace` step on a plan with no agent-driven Target, which is the case `classifyPlanTargets` used to catch by accident.
- **The agent phase has its OWN checkpoint (`run_agent_execution`) and its own recovery sweep**, and it does NOT propagate a retry to the queue — the Story 3.3 rule, one phase along: a redelivery re-verifies the population Evidence and spends one of that stage's four durable attempts, so a transient sign-in failure would cost a Run the budget of a stage that had already finished. The adapter sweep's read now excludes a Run whose agent phase is unfinished, or it would end a Run whose workspace and Target System were both healthy.
- **The sign-in destination is the FROZEN origin, and no path is guessed.** `allowed_origins` is a normalized set and is SORTED, so "the first" is deterministic for one frozen contract — the same rule `targetOrigin` applies on the adapter path, and a registration with several origins signs in at whichever sorts first. An integration test that added a second origin called `/elsewhere` therefore signed in THERE rather than at `/loancore`, silently; it names the second one to sort after.
- **The credential is presented inside the DESTINATION's own frozen origin, and nowhere else.** `[SUPERSEDED, mechanism only]` It was attached by the request INTERCEPTION rather than by `setExtraHTTPHeaders`, because the header would otherwise ride every request the page makes until it is cleared — and the workspace's egress allowlist is the UNION of every web Target's frozen origins, so the moment a plan names two web systems the first one's credential would reach the second. The sign-in now types into the system's own form, so that injection became unreachable and was removed rather than left as a branch nothing exercises; the GUARANTEE is unchanged and is now the form-action origin check in `signIn`. Proven by mutation, then as now: removing the origin check lets a cross-origin form receive the credential.
- **A denied SUB-RESOURCE must not fail the Tool Action.** `perform` compared the workspace's denial COUNT before and after a successful navigation and threw `scope` if it had moved — which is right for a navigation that was aborted and wrong for a page that merely referenced a font, a beacon or an image off-origin. It reported `scope` for something the platform never attempted, and one test-server change that added an `<img>` to the served page turned three passing tests red. What is checked after a SUCCESSFUL goto is where the main document ended, against the workspace's own allowlist; the denial count still distinguishes a refusal from an outage on the FAILURE path, because Chromium reports both as an aborted navigation.
- **A spent lease is not an unresolvable credential.** `unit.budget()` throws when the lease, the frozen Step timeout or the Run deadline runs out, and it is called inside the credential block — reporting that as `credential-unresolved` would name the wrong thing AND be terminal, because a reference nobody declared is not worth retrying and a deadline is a different fact.
- **The authoring warning and the execution denial are still two mechanisms.** FR-8 flags and never refuses; the gate refuses and never flags. `tests/unit/scope-widening.test.ts` proves both halves against the same fixture and builds each execution action out of the value the ADVISORY check named, so the thing the Builder flagged is provably the thing the gate refuses — without the two sharing an implementation, which is what would make a false positive block a save.
- **A Playwright spec that reads module state after another test failed reads an empty string.** Playwright restarts its worker after a failure, so `agent-sign-in.spec.ts` re-reads its Run id from the database rather than trusting a module variable — otherwise a later test fails on `''` instead of failing for its own reason.
- **The workspace row's STATUS is not assertable after the Run ends.** The worker releases the workspace in its `finally`, so a browser test that read `status = 'OPEN'` after a terminal transition was asserting a race. What is assertable is that the Run HAD one and which guarantee it was.
- **`[NAMED, NOT BUILT]` The Timeline does not render Tool Actions yet.** Story 3.11 anticipated the fourth level ("Epic 4's agent Runs and the fourth Tool Action level slot in without a rewrite") and this story writes the rows without rendering them: a surface showing agent Tool Actions beside no Adapter Actions would be worse than none, and the tab has its own accessibility gate. The data is complete; the read is a later story's.

### The clean source, Pass and Control Failure (Epic 3 end-to-end validation, 2026-09-06)

- **Neither golden population can reach Pass or Control Failure, and that is the datasets working.** `accessgate-accounts.json` lists AG-1007 twice; `ledgerflow-transactions.json` carries TX-500007 with no `processed_time`. §H counts duplicate Source primary keys over EVERY parsed row and counts every row the inclusion rule could not place, so both read the SOURCE rather than the included set — no scope and no inclusion rule escapes either, and a failed §H row is `INCONCLUSIVE`. And §E.1 row 3 sits ABOVE row 6, so a Run with three real Exceptions is still Inconclusive. A dataset that seeds every failure mode at once cannot also be the dataset that demonstrates success, so the two remaining outcomes needed a THIRD source that seeds nothing.
- **`coredirectory-accounts.json` is that source, and it publishes TWO populations differing by one role on one account.** CD-3103 holds `VENDOR_MAINTAINER` and `VENDOR_APPROVER`, which expand to `CREATE_VENDOR + APPROVE_VENDOR`; its counterpart CD-3003 holds only the first. Schema, period, cover-sheet generation, extraction endpoint and Reference Source are identical, so the difference in outcome is attributable to the rule and to nothing else. CD-3001 and CD-3003 are deliberate near misses, each one permission short of a pair: a rule that flagged a MEMBER of the conflict vocabulary rather than a PAIR fails the Pass case.
- **It expands through the SAME `rolematrix.json`, and carries the SAME generation timestamp as every other current fixture** (`2026-09-01T00:00:00Z`, effective `2026-08-01`..`2026-08-31`, generation `2026-09-01.1`). A second role matrix would be a second source of truth for one expansion; a second generation date would be two answers to "when was this true", and the first Run whose period straddled them would fail `freshness` for a reason nobody would look for.
- **One extraction endpoint over both populations, and that is correct under `must-appear`.** P-2's §C coverage rule asks that every account of the BOUND population appears in the extraction, not that the extraction carries nothing else. `/coredirectory/accounts` lists all eight, which is what an identity store looks like.
- **The failing §H set is asserted EMPTY, before the outcome, against the expectation file's own `gate_expectation.failed_checks`.** A Pass produced by weakening a check is not a Pass. Proven by mutation: one undeclared role in the compliant population puts `unnamed-value` on the Gate and the Pass Run becomes `INCONCLUSIVE`; removing `VENDOR_APPROVER` from CD-3103 makes the Control Failure case fail; binding each Procedure to the other population fails both.
- **A browser assertion whose subject is a table the Run never wrote reads `undefined` and says nothing.** A Run that stops at acquisition leaves no population snapshot, no Gate row and no Observation, and every assertion then fails with "received value must be a non-null object" — which names no stage. `describeRun` in `clean-source.spec.ts` reads the two checkpoints and the closed diagnostic vocabulary the stages recorded, so the FIRST failure names the stage that stopped and, when the Gate is what stopped it, the §H row.
- **Playwright reuses an already-running Northstar server outside CI (`reuseExistingServer: !CI`).** A server left over from an earlier session runs the OLD `dist`, so a newly added route or published file 404s and the Run dies with `population-transport-failed` — which reads exactly like a broken fixture. After adding a route or an `ARTIFACTS` entry, kill whatever is on the Northstar port before the browser run; `pnpm build` alone is not enough.
- **The clean cases are asserted twice, and only the browser one is the proof.** `tests/unit/golden-evaluation.test.ts` drives both populations through the production pipeline in a second, with the HTTP fetch, the object store and PostgreSQL stood in for; `tests/e2e/clean-source.spec.ts` runs both Procedures through the real worker process against the real synthetic service, a real PostgreSQL and a real object store, and asserts what each Run STORED. Both read the expectation files off disk (AD-12); neither imports them.

### The isolated Agent Workspace (added with Story 4.1)

- **Solari and Playwright were never alternatives, and there is ONE implementation.** Solari is a managed remote browser you drive WITH the Playwright client API: `sessions.create()` hands back a wire-protocol endpoint and `chromium.connect()` connects to it. So `PlaywrightBrowserExecution` is the only implementation of the port and where the browser runs is a composition-root choice. It uses `sessions.create()` + `chromium.connect()` rather than `solari.launch()`, because `launch()` returns a `BrowserSession` typed against the SDK's bundled **`patchright-core`** — a different package from `playwright-core`, with separately declared types that do not assign to each other. Two modes would then hold two `Browser` types, and the only ways out are a second code path or an `as`. `Session` is four strings, so nothing typed against the fork crosses the module. The whole rule is `docs/contracts/agent-workspace-v1.md`.
- **The weaker guarantee is written wherever the guarantee is claimed, and `run_workspace.mode` records which one a Run had.** `solari` is a separate managed browser with provider-side egress; `local` isolates browser STATE per Run — cookies, storage, cache, session — and does **not** isolate the worker process at all, with egress policed inside the browser rather than at the network. The acceptance text says nothing crosses between Runs: that is true of browser state and false of process memory, and a column that says which is what stops the stronger sentence covering both.
- **"Does this Run need a workspace" is a pure function of the frozen plan.** `workspaceRequirement` in `packages/domain/src/runs/execution.ts`, beside `classifyPlanTargets`: the compiler emits `create-workspace` FIRST exactly when a selected Target is web or desktop. No stored flag, because a flag could disagree with the plan the Run is executing and the plan is what an auditor reads.
- **The egress allowlist is the `web` Targets' frozen origins and NOTHING else.** A `desktop` registration's application identity (`com.northstar.ledgerdesk`) occupies the `allowed_origins` slot of the six-key envelope and is not a URL; putting it in a browser allowlist would be inert at best. A desktop-only plan therefore gets an EMPTY allowlist, under which every destination is denied — the truth about a browser with no web system to visit, and fail-closed.
- **`withinOrigin` has one home now, `packages/infrastructure/src/runs/origin-policy.ts`.** It was private to `adapter-extraction-http.ts` until the workspace interception needed the same judgement; both import it and the extraction module re-exports it so its own test keeps working. Two copies would agree on every value anybody thought to try and diverge on the first one nobody did.
- **A fragment is stripped before the comparison and a request carrying one is not denied.** `withinOrigin` refuses a non-empty hash, which is right for a location this platform CHOSE to fetch and wrong for a URL a browser handed back — a fragment never goes on the wire.
- **A WebSocket handshake is not a `route()` request.** Without `context.routeWebSocket` a page could open one to any host and the allowlist would never see it. `serviceWorkers: 'block'` for the same reason: a service worker's own fetches are invisible to `context.route`.
- **A frozen origin this build cannot parse refuses the WHOLE workspace (`policy`), never a partial allowlist.** A silently narrower allowlist is a workspace confined to less than the Version said, and it looks exactly like a Target System that was simply down.
- **A denial is a security event with the destination and no query string.** `security.action-denied`, `cause: scope-violation`, diagnostic `workspace-egress-denied`. The recorded destination is scheme, authority and path only: the chain is immutable and a query string is where a token or a signed URL lives. `denied()` keeps the exact total beside a bounded sample of 100 — the `run_gate_check` shape, because the enforcement is never bounded even when the record is. The lifecycle event's field is `deniedTotal` and not `denials`: it never resets, so a second boundary reports every refusal the workspace has had rather than the ones since the last one, and a number that reads as a delta and is a total is a number somebody will add up.
- **`SOLARI_API_KEY` absent is not a disabled duty.** Unlike `populationExecution` and `adapterExtraction`, `agentWorkspace` is never disabled: the local mode is the same code path against a locally launched Chromium, so the question is only WHICH guarantee, said once at boot by name. Provisioning still lives inside the storage branch because that is where the job handler is; the REAPER is outside it, because a deployment that lost its bucket still has workspaces to give back.
- **`await solari.close()` is REQUIRED in Node and `browser.close()` is not enough.** The client keeps a loopback proxy server open for its connection-retry path and that handle keeps the event loop alive, so a worker that closes only its browsers never exits. Same defect class as an unread `fetch` body holding a socket (Story 1.8) and a deadline's `dispose` that cleared the timer without aborting (PR 23), so it is a shutdown step in `main.ts`, not a happy-path call.
- **`Session.expiresAt` is a HARD provider deadline, not an idle window.** The SDK's `timeoutMs` is the CLIENT's HTTP timeout and has nothing to do with the browser; what ends a session is `expiresAt`, at which Solari auto-releases it, and nothing a Run does resets it. It is stored on the row, and a resumed claim past it treats the identity as GONE (`workspace-expired`) rather than as an outage. The frozen Run limits stay the authority for ending the RUN.
- **`[SUPERSEDED 2026-09-15 — see the `SOLARI_RECORDING` entry at the top]` `recording: true` must be passed at session creation or the replay 404s forever**, and there is no way to enable it later. That decision is taken in Story 4.1's code and Epic 5 is what reads a replay, so the flag is threaded through now (`SOLARI_RECORDING`) even though nothing reads one yet. It is OFF by default, matching the provider: recording is metered, and turning one on is a cost decision this build must not take for a deployment. The consequence is written down rather than discovered — **a Run made before it is switched on has no replay, permanently**, so Epic 5 turns it on before the Runs whose replay it wants and cannot recover the ones behind it. — **Two things in this were wrong and a later session acted on both.** The replay that 404s is the PROVIDER's, not the product's: Epic 5 shipped Replay reading the platform-owned asset set and `replay-v1.md` says it is whole without a provider recording, so "Epic 5 turns it on before the Runs whose replay it wants" describes a dependency that never existed. And the default is not a cost choice: Solari records input values by default and a sign-in types a credential into a form field, so ON puts an audit credential on a third party's servers permanently. It stays OFF for that reason.
- **`proxy`, `stealth`, `captcha`, `webBotAuth` and profiles are OFF and named rather than defaulted.** `proxy: "smart"` runs an escalation ladder and swaps the egress in place when it detects a block page — the opposite of confining a Run to its frozen origins. Naming no profile is what makes every session start clean, which is exactly what per-Run isolation wants; a later "resume where the agent left off" story would be choosing to weaken it.
- **`SolariErrorCode` is five codes and they are not one class**, and it is widened with `| string`. `ConcurrencyLimitExceeded` → `capacity` (retried), `BrowserUnhealthy` → `unavailable` (retried), `FeatureRequiresPlan`/`PlanLimitExceeded` → `entitlement` (terminal), and **an unrecognised code → `refused`, terminal**: calling an unknown reason transient would retry it four times on the strength of not knowing what it is. Folding a refusal into `unavailable` would leave the only durable record saying something was unreachable — the `credential-unresolved` rule from Story 3.3.
- **`attach` returning `null` is expected, not exceptional, and the stale identity is RELEASED before a replacement is made.** A browser does not survive the process that connected to it: Solari's `wsEndpoint` is loopback-wrapped by the client, so it means nothing outside the process that created it, and the SDK has no `sessions.get`. So reattach across a worker RESTART is impossible with `@solarisdk/browser@0.1.3` and the I/O matrix's "reattach impossible" row is the honest path — release, recreate, record `workspace-reattach-failed`. Within one process a lost claim really does reattach.
- **The provider identity may be stored and named in a Timeline event; the endpoint and the key may not.** `workspace_id` is `browser.id`, opaque and NOT a capability — releasing a Solari session still needs the deployment's API key — and it is what makes a provider-side session correlatable with a Run. `WorkspaceRef` has no field for a key, a token or an endpoint, so no checkpoint, payload, log field or error message can pick one up.
- **`run_workspace` cascades from `audit_run`, unlike the four tables every teardown deletes by name.** `run_gate_check`, `run_result`, `run_evidence_package` and `run_evidence_integrity` record an OUTCOME and should not be silently removable; a workspace row is operational state, and removing a whole Run takes it along — the reading that already makes `run_exception` cascade from `run_observation`. Ten existing teardowns delete `audit_run` without knowing this table exists, and a foreign key nobody knew about does not fail its own suite: it leaves rows behind and fails an unrelated one later on a count.
- **The reaper is the third sweep of an existing shape.** Its own read (`reapableRunIds`, a keyset page ordered by Run id), ten Runs per tick, a cursor that resets on a short page, and a stop that lets the active release finish and starts none of the rest. A release is network I/O, so it cannot be a step inside the transaction that ends the Run; the worker releases in a `finally` and the reaper is the backstop for a worker that died before reaching it.
- **The one leak that cannot be closed is written down rather than claimed away.** A provider session created and the process dying before the identity is committed cannot be released by anything here: there is no name for it and the SDK offers no listing. It is bounded by the provider's own grace timer.
- **A `create-workspace` Step Execution needs a row on the Timeline to render it.** `run_step_execution` rows with `work_item_id = null` are keyed by plan step, and nothing rendered `session-1`, so the attempt would have been an invisible row. `RunTimelineRead.workspace` and the row above it in `Timeline.tsx` are what make it visible, and the mode is shown in words because `local` and `solari` are not the same guarantee.
- **A retry counter must not count a SUCCESS.** `attempts` bounded provisioning failures, but the claim incremented it on every delivery — including one that only REATTACHED to a workspace that was fine. `acquirePopulation` asks for a redelivery on any transient transport failure and has four attempts of its own, so a Run that retried its population three times arrived here four times, and the fifth delivery failed a Run whose workspace had been healthy every single time. An `OPEN` row now carries its count forward unchanged and is exempt from the limit; a failure moves it to `RETRY`, and the next claim does count. Found by reading rather than by a test, and the test that catches it drives six redeliveries.
- **A browser spec that hard-codes an address the suite parameterises asserts the wrong row.** `administration.spec.ts` located the signed-in administrator's own row by the literal `administrator@example.test` while `ACCOUNTS.administrator.email` reads `E2E_ADMIN_EMAIL`. Pointed at a differently-named administrator the locator resolved to somebody ELSE's row, whose select is correctly enabled — so the failure read as a broken self-demotion guard rather than as a wrong locator. Locate by the configured value, never by a copy of its default.
- **`pkill -f <pattern>` matches your own shell.** `pkill -f northstar` inside a command line containing the word `northstar` killed the shell running it (exit 144). The environment's own rule, met in practice.
- **`git checkout -- <file>` reverting an uncommitted fix, a second time.** Restoring `labels.ts` after a mutation test silently deleted the `workspaceModeWord` the story had just added, and the suite went green because the test file had been reverted with it. Copy the file aside and restore from the copy — the rule Story 2.1 recorded, learned again.

### The verification harness is not exempt (2026-09-06)

Four failures in one session were in the HARNESS rather than in the code under test, and every
one of them looked like a result. An absent or miscounted signal that reads as success is the
same defect class this project keeps finding in the product; the thing that checks the work has
to be held to the rule the work is.

- **A status check that greps a nested JSON body counts the wrong things.** A monitor on the
  GitHub jobs API grepped `"status": *"completed"` and reported ALL FOUR GREEN while two of the
  four jobs were still running: each job embeds a `steps[]` array whose entries carry their own
  `status`, so completed STEPS were counted as completed JOBS. Parse the job-level fields, treat
  any non-`success` conclusion as a failure, and require every job `completed` before reporting
  green. It was caught only because the answer was checked against the authoritative API before
  being acted on — the same "verify the reported figure" that catches an agent's numbers.
- **A verification script must exit non-zero when a step fails.** `gates.sh` echoed `FAIL` per
  step and then exited 0 regardless, so a background completion notice read as an all-clear over
  a failing gate. It tracks a flag now and ends `GATE PASSED` or `GATE FAILED`.
- **`pgrep -f <pattern>` matches your own shell**, so `until ! pgrep -f ...` can never exit. It
  deadlocked one agent for hours. Check once, wait a bounded time, check again, and proceed
  saying so — never an unbounded loop. Same root as the `pkill -f northstar` that killed its own
  shell.
- **An `&&` chain that short-circuits reports a failure that never ran.** A background gate
  spelled `source nvm.sh && nvm use && pnpm typecheck > log; echo "EXIT=$?" >> log` produced a
  log containing one line — `EXIT=1` — because the first link failed in that shell and every
  command after it was skipped. Read at a glance it says "typecheck failed"; what it means is
  "typecheck did not run", and the harness reported exit 0 for the whole invocation because the
  final `echo` succeeded. Separate setup from work with `;`, capture each step's own exit
  status, and write the interpreter version into the log so a run that used the wrong Node or
  no Node at all cannot look like a product result.
- **A gate script needs every environment variable the app validates at STARTUP, not only the
  ones its tests read.** A browser gate that set `DATABASE_URL` but neither `SERVICE_NAME` nor
  `BETTER_AUTH_SECRET` failed with the web process printing `"Refusing to start"` and naming the
  missing key — the AD-15 startup guard working exactly as designed, read at first glance as a
  defect in the story under test.
- **`pnpm seed:identity` takes ONE account per invocation**, `--email` and `--role`, and only
  re-assigns a role for an address that already exists; it never resets a password. There is no
  bulk seed, and `SEED_PASSWORD` alone does nothing.
- **Two branches at the same schema generation are two different schemas.** While Epic 3's repair
  and Epic 4's Story 4.1 both sat at generation 27, running one branch's suite against the
  other's database would have migrated nothing and tested the wrong shape while looking fine.
  A worktree gating a different branch needs its OWN database, not just its own checkout.

- **Two database-backed suites must NEVER run at the same time against one database, and a
  green one that did proves nothing either.** Started concurrently on 2026-09-10, the
  integration suite reported ten failures and the browser suite one, and every single one
  was the other suite: the browser specs start real worker processes whose recovery sweeps
  claim any abandoned `RUNNING` Run in the database — sealing packages the integration
  fixtures were about to write Evidence into, and leaving `run_gate_check` empty — while
  the integration files insert `audit-manager` rows that `escalations.spec.ts`'s live
  recipient query then counts and waits forever to see delivered. The failures name the
  Gate, the absence judge and the notification path, so they read as product defects for
  as long as it takes to notice both runs share a `DATABASE_URL`. Run them one after the
  other; a suite that writes Runs also needs the OTHER suite's leftovers gone, because
  `run-surfaces.test.ts`'s keyset page and `run-waits.test.ts`'s recipient count are both
  bounded reads over the whole table.
- **A backtick inside a `sql` template ends the template, and the file then has NO tests.**
  A generation-45 comment carrying `` `run_wait_opened_by` `` was pasted inside
  ``sql`INSERT INTO run_wait ...` `` in `notification-delivery.test.ts`; the file stopped
  parsing and Vitest reported it as ` ❯ tests/integration/notification-delivery.test.ts
  (0 test)` — a line that reads as a collection hiccup in a 43-file list rather than as a
  suite whose coverage has silently gone to zero, and it survived two full runs unnoticed.
  Keep prose comments OUTSIDE tagged templates, as `//` lines above the call, and treat
  "(0 test)" as a failure with the same weight as a red assertion.
- **A Turbopack internal panic aborts the dev server mid-run.** ` thread 'tokio-rt-worker'
  panicked at turbopack/.../aggregation_update.rs` is followed by `Aborting.`, and every
  spec after it fails `net::ERR_CONNECTION_REFUSED` in about a second. Sixteen red tests,
  one cause, none of them the product. Read the first failure — again.
- **A one-time module import inside a test's own timeout is a flake waiting for a busy
  machine.** `session-route.test.ts` and `sign-in-route.test.ts` are fully mocked and touch
  no database, and neither resets the module registry — so only the FIRST `await
  import('../app/api/...')` ever pays the transform, and on this workspace's graph that can
  exceed a 5-second test timeout or a 10-second hook one. The first case then fails and its
  work leaks into the second (`roleLookups` read 2 where 1 was expected), and a timed-out
  HOOK reports its 37 tests as **skipped** rather than failed — which reads as a collection
  quirk, not as coverage that did not run. Warm the module in a `beforeAll` with room; every
  assertion stays as it was, and the per-test times went from 5,354 ms to 6 ms.
- **PostgreSQL 18 in this container dies under load, and running two suites at once is that
  load.** Started together, the browser suite and the unit suite killed the cluster: the web
  process logged `ECONNREFUSED`, `/api/health` answered 503 twenty times, and Playwright
  ended with `Timed out waiting 180000ms from config.webServer` — while the unit run showed
  four failures in the two files above, all of them the missing database. One cause, two
  suites, six red results, none of them the product. It recovers cleanly with
  `rm -f /tmp/pgdata18/postmaster.pid && pg_ctl -D /tmp/pgdata18 -o '-p 5434' start`.
- **A background wrapper reports the SHELL's exit code, not the command's.** A run spelled
  `pnpm exec playwright test > log; echo "E2E=$?"` was reported as **exit code 0** by the
  task harness while the log said `Timed out waiting 180000ms` — the `echo` succeeded, so
  the shell did. Read the log, never the wrapper's code. Same family as the `&&` chain that
  reports a failure that never ran.
- **The FIRST browser run after a cold `.next` pays route compilation inside a 10-second
  assertion.** `auth.setup.ts` clicks Sign in and waits for the shell; Next compiles `/` on
  that first navigation, and on this box it does not finish in ten seconds, so the setup
  fails and all 188 specs report `did not run`. The webServer's own health check hits
  `/api/health`, a route handler, so the PAGE is still cold when the suite starts. A second
  run with the cache warm is the honest answer; `INTELLIFIN_LOW_DISK=1` exists for the
  opposite problem and would make it slower.
- **A test script that mutates the DOM before hydration makes React log a defect that is
  not one.** The full browser run prints twenty `A tree hydrated but some attributes of the
  server rendered HTML didn't match the client properties` blocks, each ending in a
  `<details … data-plan-detail>` whose server HTML carries `open=""` and whose client
  property is `open={false}`. `DraftBuilder.tsx` sets no `open` prop at all; what sets it is
  `keepBuilderStepsOpen`, whose `addInitScript` opens the Builder's three disclosures before
  React arrives — React's own message names that case ("a browser extension … which messes
  with the HTML before React loaded"). So it is the harness, it is deliberate, and the right
  response is to know it rather than to remove the `open` that no component writes. Read the
  COMPONENT before believing a hydration diff, and check whether a spec's init script
  touches the element the diff names.

### Credentials just in time, and capture suppressed while one is on the wire (added with Story 4.3)

- **"Entry" is credential USE, which is wider than typing and INCLUDES it.** `[REVISED 2026-09-06]` It first read "not typing", because LoanCore then authenticated a GET with an `Authorization` header and had no form. It has one now, so both cases are live and both are covered: the value is TYPED into a field and submitted in a body by the agent sign-in, and PRESENTED in a header by an adapter extraction. What must have nowhere to land is the form field, the request body, the request header and every artifact that could carry any of them: a network artifact, a Structural Snapshot, a screenshot, a frame. The byte-level scanner is unchanged and still covers everything it did. Settled in `epic-4-loancore-authentication-decision.md`. The whole rule is `docs/contracts/credential-containment-v1.md`.
- **`ResolvedCredential` gained two METHODS and still has no field.** `redact(text)` removes every whole-value spelling; `discloses(bytes)` says whether bytes carry it. Neither returns the value and neither widens what a holder can learn — `authorize` already writes it into any sink it is handed — so `JSON.stringify` of a resolved credential is still `{"reference":"..."}` and there is nowhere for a checkpoint, payload, queue job, log field or error message to pick one up. Fifth time this codebase has made the containment-by-shape move.
- **The needle is encoded, not the haystack decoded, and the scan is over BYTES.** A screenshot is not text and `decodePopulationUtf8` throws on the first malformed sequence; a byte search reads a PNG, a PDF and a Structural Snapshot with one rule. Percent-, HTML- and JSON-escaping are the identity on `[A-Za-z0-9._~-]`, so the raw form covers them for an ordinary token; **base64 is the one that transforms everything**, and it is searched for at all three byte alignments because that is how a value sits inside a `data:` URL, an `Authorization: Basic` header or a HAR. What it does NOT catch — compressed, encrypted, re-cased, split across a line break — is written down in the module rather than claimed away: detection is a wall against the paths a capture mechanism produces, never a proof of absence.
- **A credential this build cannot scan for is never resolved at all.** `compileSecret` refuses a value under `MIN_SCANNED_SECRET` (12): a four-character "secret" matches ordinary text, so scanning for it would refuse almost every artifact, and lowering the bar would fail OPEN in the one guarantee the module exists to give. It surfaces as `credential-unresolved` — terminal, because a manifest entry does not get longer by being asked for again — and NOT at boot, so a deployment with an unscannable token still runs plan derivation, notification delivery and its heartbeat (the PR 23 lesson).
- **The guard is fed by WRAPPING the resolver, never by remembering.** `guardedCredentials(resolver)` returns a resolver whose every answer is held by a `CredentialGuard`; each stage wraps once at the top and never keeps the unwrapped one, so there is no "register this credential" step for a branch to skip. `freezeArtifact` takes the guard as a REQUIRED argument and `NO_CREDENTIALS` is the explicit "this stage has presented none" — the `NO_CORROBORATION` shape, because an optional seam defaulted inside the function would let a composition root register every artifact unscanned for ever with nothing saying so. Proven by mutation: either stage keeping its unwrapped resolver fails a named test.
- **The population stage passes `NO_CREDENTIALS` and that is the TRUTH, not a convenience.** Population acquisition runs before the sign-in and before any adapter extraction, so at the moment its bytes are frozen the Run has resolved nothing to scan for. Holding the plan's credentials there to scan for them would mean resolving a secret in a stage that must never have one.
- **The scan runs BEFORE the upload, so "nothing is stored" is literal rather than nearly true.** The object store is immutable by design and an artifact that reached it could not be taken back out. And it is a REFUSAL, never a redaction: bytes a Target System served are Evidence, and rewriting them to make them acceptable would falsify what a system answered. A platform-produced capture is redacted by its producer, through the same guard, before it gets here; one that still discloses afterwards is a redaction defect and must fail loudly rather than be quietly re-redacted.
- **`AcquisitionFailureCode` gained `credential`, and it is neither `integrity` nor `contract`.** Nothing is damaged and the system honoured its contract; what happened is that the platform may not keep what it answered with. `extraction-credential-disclosed` / `reference-credential-disclosed` are TERMINAL for the unit on the first attempt — the same bytes disclose the same credential every time (the `credential-unresolved` rule). A Work Item failure still never stops a Run: the reservation stays open, the seal abandons it, and the Gate concludes on the coverage that item never produced.
- **`BrowserToolAction` is a UNION, and that is the suppression.** The arm carrying a credential has no `capture` field at all, so a Structural Snapshot, a screenshot or a frame cannot be asked for while a credential is on the wire — it does not compile. A structural type does not CONTAIN anything, so `perform` refuses such a request at runtime too, FIRST, before the workspace is looked up: it is a fact about the REQUEST, and reporting it as `unavailable` because the browser happened to be gone would name the wrong thing. **`[NAMED, NOT BUILT]` nothing in this build captures**; `BROWSER_CAPTURE_KINDS` is the vocabulary and Story 4.4 owns the mechanism.
- **A suppression that showed as a gap would be the sign-out defect's shape.** `run_tool_action` records `capture` on EVERY row and `capture_suppression` when there is one (generation 29), pinned by ONE CHECK — `(capture='SUPPRESSED') = (capture_suppression IS NOT NULL)` — because either half alone permits a row that reads as the other. The value is DERIVED by the platform from its own request (`captureStateFor`), never reported by a provider: a fact a provider reported is a fact a provider could get wrong.
- **Generation 29 HAS an honest backfill, unlike generation 20's digest, so it gets one.** A Tool Action inside a `sign-in` Step Execution presented a credential, and that is a stored column rather than an assumption about what the code did when the migration was written: `UPDATE ... FROM run_step_execution`, then `SET NOT NULL`, then the CHECKs. Exercised against real rows in a scratch schema before it was trusted, because `ADD COLUMN ... NOT NULL` fails on a table that already holds any.
- **`sanitizeDestination` keeps the PATH, so a destination is redacted before it is recorded.** A system that puts a token in a path segment — or a redirect that does — would otherwise put a working credential into the immutable action log. Both the requested destination and the location the navigation ENDED on go through `guard.redact`. Same doctrine one step along as stripping `user:pass@`: a destination denied FOR carrying a credential must still be recorded, and recorded without it.
- **The Timeline's fourth level is rendered now, which overturns Story 4.2's deferral, deliberately.** 4.2 left Tool Actions as data because "a surface showing agent Tool Actions beside no Adapter Actions would be worse than none". 4.3's acceptance text requires the action to be VISIBLE and to say its capture was suppressed, and a data-only guarantee is not that. The adapter path still writes no rows, which is a gap already named rather than a new one. Rows collapse under the Step Executions `<details>` by default — EXPERIENCE.md's "collapsed to Work Item rows by default" — so a browser assertion has to open it, exactly as a reader does.
- **A Session Step's Timeline row said "Reference Source" for every Session Step**, which stopped being true the moment Story 4.2 wrote the first `sign-in` row. A label stating something untrue is worse than one stating nothing; `RunTimelineSessionStep` now carries the frozen `action` and `planActionWord` names it. `RunTimelineWorkItem` omits it: a Work Item's action is the plan step it belongs to, which is already `stepId`.
- **The seeded negative test is a deliberately hostile synthetic surface.** `/accessgate/credential-echo` echoes the presented `Authorization` header into its own response body — the path nobody predicts, and the one that matters — inside the same closed collection envelope every other endpoint serves, so the ONLY thing wrong with it is the disclosure. It is bound by no Procedure this repository seeds, named in no expectation file and registered by no seed script; `tests/e2e/credential-containment.spec.ts` is the only thing that points a Run at it. It invents no credential — it repeats what the caller sent — so this environment still holds none (Story 1.8's rule, unchanged).
- **Test credentials are built by the REAL factory or by the domain's own functions, never hand-stubbed.** A `{reference, authorize}` literal whose `redact` is the identity would let every containment assertion in three suites pass against a build that redacts nothing. The unit vectors go the other way: they are encoded by Node's `Buffer`, `encodeURIComponent` and `JSON.stringify` rather than by asking the module for its own forms and then looking for them.
### PR 23 review findings, second pass (applied 2026-09-06)

**The shape four of the ten share: a rule stated correctly in prose and implemented incompletely.** Two are a LIMIT applied to a read whose cardinality is not what the limit bounds; two are a capability disabled by name without disabling what depends on it. A doc comment is not an implementation, and in this codebase the comment is usually right — so when one is found, read the code beneath it as a claim to be checked rather than as an explanation of it.

- **A limit belongs to the cardinality of the READ, not to the table it starts from.** `readGateObservations` was capped at `POPULATION_LIMITS.rows`, which is exactly right one function above it — acquisition caps `population_row` at that number, so it can never bind — and wrong here, because the per-record coverage matrix is RECORDS × REQUIRED TARGET SYSTEMS. Sixty thousand records over two systems is a hundred and twenty thousand Observations and twenty thousand were dropped; a dropped `COVERED` cell reads as MISSING coverage, so a fully covered Run sealed `INCONCLUSIVE` and published coverage counts that were wrong. `GATE_OBSERVATION_LIMIT` is now `POPULATION_LIMITS.rows * TARGET_DRAFT_LIMITS.targets` and provably cannot bind, and the read is ordered on the unique index so a bound that somehow did bind would drop the same rows every time. `result-repository.test.ts` checks it against `OBSERVATION_LIMITS.batch` and the `<= 32` read out of generation 9's own CHECK on disk — never against a copy of its own definition.
- **An exact total and a bounded sample are two questions, and `LIMIT` answers only the second.** `readConditionGaps` took `rows.length` after a `LIMIT`, so a §H row's `total` was not a count at all. It is two statements now — a `count(*)` and a `LIMIT GATE_AFFECTED_LIMIT` sample — which is what `readFailedObservationChecks` and `readUnnamedValues` in the same file already did, and what `readResultFindings` does one file along. **Copy the working sibling rather than inventing a third shape.** The original defect needed more than a hundred thousand Observations to show, so the integration test pins the shape at thirty-three gaps instead: it fails against the re-merge a later edit would produce, and could not have failed against the code it replaced.
- **A capability disabled by name must also stop the work that depends on it.** The whole Run block sat inside `if (evidence.enabled)`, so with no `EVIDENCE_S3_*` the worker registered NO consumer for the `runs` queue while the web's Initiate Run action stayed enabled and went on enqueueing: every Run sat `QUEUED` for ever, with no diagnostic and no Result. One stage along was worse — `if (acquired.retry || adapter === null) return acquired;` acknowledged the job after acquisition, leaving the Run `RUNNING` at `POPULATION_READY` with its Evidence frozen and neither sweep able to select it again. The worker now ALWAYS consumes the queue and `stopUnexecutableRun` ends such a Run `RUN_FAILED` through `completeRun`, with a closed diagnostic naming the missing capability. **The web cannot make this decision** — `EVIDENCE_S3_*` and `CREDENTIAL_TOKENS` are the worker's environment — so refusing at initiation was never available; and a Run that failed for a stated reason can be acted on and rerun, while a Run that never moved cannot. The trade is that a MIXED worker pool, one process configured and one not, would let the unconfigured one fail Runs the other could run. That is not a shape `.railway/railway.ts` declares; if it ever is, the capability belongs in the queue's job routing and not in whether a consumer exists.
- **`stopUnexecutableRun` fabricates nothing.** No checkpoint is written and no Evidence reserved: for a queued Run nothing was ever attempted, and an invented reservation would make the seal list an abandonment for an artifact nobody asked for. For the `POPULATION_READY` case the checkpoint is left exactly as acquisition wrote it, because the population really was ready — what failed is the stage after it. A cancellation still wins there, because a Run that never ran earned no outcome to keep.
- **A bucket that is not there is not an object that is not there.** `isMissing` in `s3-evidence-store.ts` counted `NoSuchBucket` as absence, and S3 answers it with HTTP **404**, so removing the name alone would not have been enough — the status test had to be reached second. `read` answering `null` is what `verifySealedPackage` records as `object-missing`, so one deleted or misnamed bucket would have written a PERMANENT tamper finding, and its immutable `failure.evidence-integrity` event, against every registered artifact of every terminal Run the sweep reached. The rule was already written down one file along: *a store that cannot be READ is not proof of tampering.* Only OBJECT-level absence may answer `null`.
- **A keyset cursor naming no row must resolve to NO cursor, and the comparison must not lose precision.** The cursor was compared against a scalar subquery inline, so a valid UUID naming nothing made `(initiated_at, run_id) < NULL` — NULL for every row — and the page came back EMPTY, which is neither the first page nor an error. It is resolved in its own statement now and treated as absent when it finds nothing. **The resolved timestamp travels as TEXT and returns as `::timestamptz`**: `timestamptz` keeps microseconds and a JavaScript `Date` keeps milliseconds, so a round trip through one would truncate the cursor downward and silently skip every Run sharing that millisecond — a row on no page at all, which is the failure the total order exists to prevent. The existing test ASSERTED the empty page, three lines under a comment saying a person who edits a URL should meet page one.
- **Generation 21's DELETE exemption was right and one case too wide.** Removing a WHOLE Run is test teardown and stays permitted; deleting a `run_evidence` or `population_evidence` row while its `run_evidence_package` SURVIVES is not that — the package goes on naming an artifact whose metadata is gone, and the post-Run sweep verifies only what `readRegisteredArtifacts` returns, so nothing is read, nothing fails, no finding is recorded, and the Run page keeps printing "registered and verified". Generation 27 refuses that delete while the package row exists, and stands down once it is gone. **So the SEAL is deleted before what it sealed**, and two teardowns that had the two lines the other way round were reordered. `TG_OP` chooses `OLD` or `NEW`: a function reading `NEW.run_id` on a DELETE dereferences NULL and fails every delete, teardown included.
- **The outcome a Run EARNED beats a cancellation observed at the final boundary, and the request is never silent.** A person can ask for a Run to stop while its last Work Item runs, or while its acquisition is already failing. Honouring it at the adapter stage would throw away a complete, sealed conclusion one transaction from being written — §E.1's `canceled` row matches on the STATE alone, so twenty Gate rows would become `gatePassed: false, checks: 0` — and at the population stage it would hide WHY the Run could not conclude behind a state that says only "somebody asked". What was missing is that the committed marker was then answered by NOTHING: the person clicked Cancel, got a confirmation, and the Run said Completed. `completeRun` now appends `lifecycle.cancellation-superseded` naming the requester, the time, the reason and what happened instead. It lives THERE and not at the two call sites because every terminal transition already goes through it — which is why Story 3.10 put `performCancellation` there — so one check covers both worker stages, the web command and every path Epic 4 adds. `readCancellation` is a port on `RunResultContext` and reads on the TRANSACTION's connection: the `RunRecord` a stage carries was read at its claim, and the case this exists for is a request committed after it. The UI half already existed — `CancellationBanners` says "The Run ended before the cancellation was performed, so its own outcome stands."
- **A predecessor could not answer the question its own recovery sentence asked.** `RunLifecycleActions` tells somebody whose rerun response was lost to "Reload the Run to see whether a new Run was queued", and the rerun link is deliberately on the SUCCESSOR's row and its own chain and nowhere else — so the page they reloaded showed nothing at all. They saw no change, clicked Rerun again, and once the first successor had itself concluded the active-period check no longer refused them: two Runs from one intent, with the person believing there was one. `findSuccessors` and the `RerunLinks` banner are the answer. It does NOT refuse a second rerun: nothing in the contract says a terminal Run has at most one successor, and inventing that rule inside a bug fix would be a product decision taken sideways. The related accepted decision — `initiate-run.ts` binding a request token to another auditor's Run on a duplicate refusal — is untouched.

### Owner review: a failed release must not lose what it could not give back (2026-09-06)

- **A swallowed failure that is followed by a REPLACEMENT destroys the only thing that could ever undo it.** `provisionWorkspace`'s reattach branch released the stale identity with `.catch(() => undefined)` and then fell through to `create`, overwriting `checkpoint.workspaceId`. The adapter already resolves `InvalidSessionId` and a 404 as SUCCESS — on a release, "the stored identity is gone" is the outcome asked for — so a release that THROWS is an outage, a capacity refusal or a policy denial, and the remote session is very possibly still running. `run_workspace` is the only durable record of it and the reaper reads that row, so after the replacement nothing anywhere could name the old session: it would be held until the provider's own plan deadline with no operator able to find it. **The general shape: `.catch(() => undefined)` is safe only where the next statement does not depend on the call having worked.** Here the next statement was the one that made it unrecoverable.
- **So the release failure ENDS the attempt instead, and keeps the identity.** A private `StaleReleaseFailed` — thrown, never returned, and carrying no `cause`, because the diagnostic vocabulary is closed and an error message is where an endpoint or a value rides into an immutable event — reaches the file's one failure handler, which writes `workspace-release-failed` and leaves `workspaceId` and `expiresAt` untouched. It is RETRYABLE and deliberately not a `WorkspaceFailureCode`: `TERMINAL_CODES` answers "will CREATING refuse identically again?", which has no bearing on a release, and a retry costs one reattach and one release against a session that may still be alive. The budget bounds it; when it is spent the row is `FAILED` and STILL names the workspace.
- **An EXPIRED identity is the one branch where swallowing is right, and the two must not be collapsed.** Past the provider's HARD deadline the session auto-released itself, so there is nothing to leak, the call is a courtesy, and a failure means it was already gone — the outcome asked for. A replacement is correct there whatever the release answered. The mutation that collapses the two is killed only by the companion test: the pre-existing expired test releases successfully, so it cannot see the difference.
- **Keeping the identity is worth nothing if the backstop cannot see the row it is kept on.** `reapableRunIds` selected `PROVISIONING`, `OPEN` and `RETRY` — and `FAILED` is exactly where a row ends when the budget is spent, which is where every path that preserves an identity through a failure lands. The one row the reaper most had to find was the one row it could never select, so the sweep stopped precisely where the leak started. **A read that filters on a state vocabulary has to be re-read whenever a new way of reaching one of those states is added**; the fix and the read that consumes it are one change, not two.
- **`remaining()` is evaluated ONCE and outside both branches.** A lease already spent is not a release that failed, and recording it as one would name something that never happened: it throws `unavailable`, which is honest — nothing was released and nothing was created — and the identity survives either way.
- **The fake's `release` records the ref BEFORE it can throw**, so a test can tell "attempted and failed" from "never attempted". A fake that threw first would let a build that skipped the release entirely pass the regression test.

### Read-only means no mutation of audited business data (2026-09-06)

The owner overturned the rule Story 1.8 wrote and Story 4.2 built around: *read-only means
no mutation of audited business data; it should not force a specially invented GET-only
sign-in solely to satisfy an earlier fixture rule.* The decision, the error it corrects and
what is deliberately NOT changed are in
`_bmad-output/implementation-artifacts/epic-4-loancore-authentication-decision.md`.

- **The system-level guard refuses MUTATION, not methods, and every property that made the
  method rule good survives.** One rule, applied ONCE, ABOVE routing in `handleRequest`;
  fail-closed; a write to a path no route serves still refused rather than 404'd; the
  denial still JSON on every surface and still naming FR-3. Only the predicate changed:
  from "is the method GET or HEAD?" to "is this a declared non-mutating operation?". The
  HTTP method was being used as a PROXY for mutation, and a sign-in POST creates a session
  and mutates nothing FR-3 constrains — FR-3 constrains what the platform may INVOKE, which
  is enforced against the registration's frozen `permitted_actions` by `authorizeToolAction`.
- **The declaration is the type's default, not a convention.** `Route.nonMutating` is
  OPTIONAL and its absence means the route mutates, so a route added by a later story is
  refused every method — GET included — until it says otherwise. `read-only.test.ts` walks
  `ROUTES` and asserts BOTH directions per route, because a suite that asserted only
  refusals would pass against a guard that refuses everything, sign-in included. It also
  drives a hand-made undeclared route, which is the fail-closed branch no real route takes.
  `routes.test.ts` requires every route to declare, and to declare in upper case: a
  declaration spelled `post` permits nothing and reads as though it permitted something.
- **`Allow` is per route now.** The matched route's declaration, or `GET, HEAD` for a path
  no route serves — because a read there gets a real answer, this system's own 404. A
  matched route that declares nothing gets an EMPTY `Allow`: saying `GET, HEAD` while the
  guard refuses a GET would be a header contradicting the response beside it.
- **`READ_METHODS` was renamed `NON_MUTATING_READS`.** The name said "the whole rule" and
  the value is now a declaration a route reaches for. `isReadMethod` is gone with it.
- **LoanCore has a real sign-in form, and `/loancore` IS the sign-in surface.** A caller
  with no session is shown the form at the frozen allowed origin itself, so the platform
  navigates to the origin its Procedure Version froze and needs to guess no path and parse
  no page to find the form. `/loancore` and `/loancore/sign-in` are the two public paths,
  allowlisted the way `apps/web`'s `isPublicPath` allowlists `/sign-in`; every other
  `/loancore` path answers 401. The `WWW-Authenticate` challenge names the FORM
  (`FormSignIn realm="LoanCore", form="/loancore/sign-in"`) rather than `Bearer`, which
  would name a way of authenticating this system no longer has.
- **The header sign-in was REMOVED, not kept beside the form.** Leaving one would make the
  form decorative: every test would pass with the form deleted, which is the failure
  "assert both directions" exists to prevent.
- **The workspace signs in through the form, and the form is judged before anything is
  typed.** Exactly one `<form>` with exactly one `<input type="password">` and exactly one
  submit control; the form must declare `POST`; its resolved action AND the submitter's own
  `formaction` must be inside the destination's frozen origin. A stated mechanism contract,
  not a heuristic — a mechanism that picked one of several forms would be choosing, on a
  page a Target System controls, where a credential goes. That origin check is what the
  interception's header injection used to do, which is why the injection could be deleted
  rather than left unreachable.
- **`ResolvedCredential` gained `enter(field)` and still has no field holding a value.**
  `authorize` writes `Authorization: Bearer <token>`, which is a PRESENTATION; a form field
  carries the credential itself, so they are two methods rather than one with a mode. The
  sink is nameless: which field a credential goes in is the mechanism's business, and a
  resolver that chose the name would be one that knows what a sign-in form looks like.
- **`BrowserActionResult.method` is read back, and generation 31 widens
  `run_tool_action_method` to `TOOL_ACTION_METHODS` (`GET`, `HEAD`, `POST`).** The method
  recorded is the one that produced the action's FINAL response, walked back through the
  redirect chain the system chose — so a sign-in records the form's `POST` and not the
  `GET` the browser was left on after the 303. Recording only the `GET` would put the
  method-as-a-proxy-for-mutation equivalence back one layer down, in the log a reader checks
  the guarantee against. The set stays CLOSED, and `performToolAction` refuses a method
  outside it as a `contract` failure rather than letting a row violate the CHECK and take
  the transaction with it.
- **Both credential-entry cases now exist in the fixtures, and both are tested.** The typed
  form is LoanCore's; the header echo is `/accessgate/credential-echo`, on the adapter path,
  untouched. The integration suite gained a system whose sign-in form posts to ANOTHER
  frozen origin — both inside the workspace's egress allowlist, so the interception would
  let it through — and asserts `sign-in-scope-violation` plus a server log showing nothing
  was posted to either origin.
- **The other synthetic systems stay unauthenticated and fully read-only.** Only LoanCore
  has a sign-in. Adding one everywhere would make every Epic 3 adapter test carry a
  credential for no reason.

### Verifying another agent's continuation (2026-09-08)

Codex pushed 128 commits to `codex/epic-4-agent-runs` while this session was rate-limited. The
method that checked them is written down so the next handover is checked the same way rather
than trusted, and the two harness mistakes it produced are recorded beside it.

- **Read the authoritative signal, never the report.** CI verdicts were read at the JOB level
  (five jobs, each `success`), the live-provider claim was read from the CI job LOG (the
  worker's five model turns, the `AWAITING_AUDITOR` state and the release timestamp are all
  in it), and the Railway deployment from the Railway API. The engineering report agreed
  with all three; it was not the evidence.
- **Both migration paths, then parity.** Fresh install empty → 41 and upgrade 32 → 41 in two
  databases, then `information_schema` column, constraint and trigger counts compared
  (516 / 737 / 40 on both). A migration chain that installs is not proven to upgrade.
- **Scan for weakened tests, not only for failing ones.** Deleted test files, added
  `.skip`/`.only`/`.fixme`, and `expect(` lines REMOVED from pre-existing test files (15,
  each read, each replaced by a stronger one). A green suite says nothing about what it
  stopped asserting.
- **Grep the single-writer seams by hand** (`run_observation` inserts, `run_result` writes,
  `audit_run.state` writers, `browser.perform` call sites) and have a read-only mapping agent
  do it independently. Two answers that agree from different methods.
- **Check what the other agent changed in YOUR files first.** A ten-line patch to the
  generation-32 migration and a lost-claim release of an ATTACHED workspace handle were both
  defects in this session's own work, found by Codex's populated-upgrade and race tests.
- **`nvm use` does not take effect inside `nohup bash script`.** The gate started under Node
  22.22.2 against a repo pinned to 24.20.0, and only the interpreter line written into the
  log exposed it. Printing the version is not enforcing it: the script now exports
  `/opt/node24/bin` explicitly and REFUSES to run on any other Node or pnpm version.
- **`pkill -f <pattern>` matched this shell's own command line, a second time.** Exit 144,
  and everything after the `pkill` in that command never ran, so the wrong-Node gate kept
  running while the shell that meant to kill it was dead. Kill by PID, or spell the pattern
  `"[g]ates-codex"` so the regex cannot match its own literal text.
- **Three decision-log notes went stale without a marker.** A change that supersedes a rule
  written here must mark the old entry in the same commit, or the next agent implements the
  old rule. `[EXTENDED]` and `[SUPERSEDED]` markers with a pointer are the convention.

### Owner decisions (2026-09-06): five closed questions

Five decisions the owner took together. Three needed storage and are one migration,
**generation 32**, because they are one release. Each closes something this file used to
record as an accepted risk or a named gap; those notes now point here.

- **A Run stopped by its own time limit keeps the Evidence it already froze.** The limit is
  unchanged and `runTimeoutSeconds` is still a frozen compiler-1 value: a Run that crosses
  it still ends `INCONCLUSIVE`. What changed is that it no longer throws away a population
  it had already acquired, stored and verified. `stopAtRunLimit` in
  `acquire-population.ts` is the one path — it does NO store read, spends NO durable
  attempt, and carries the checkpoint's digests, size and capture provenance through
  verbatim, so `population_evidence` stays `REGISTERED` and the seal finds it. The limit is
  checked BEFORE any I/O (a timeout must not start work) and again after a SUCCESSFUL
  verification, where it used to be a `remaining()` that turned the success into a
  transport failure and spent an attempt on it. Inconclusive-with-Evidence and
  inconclusive-with-nothing are different findings to an auditor.
- **The Result NAMES the artifacts it sealed with**, in `publication.evidence.artifacts`,
  beside the exact `registered` count. A count cannot tell those two findings apart:
  `registered: 1` says a number, not which artifact, and a reader cannot follow a number to
  the bytes. `completeRun` reads `readPackageArtifacts()` AFTER the seal — the same rows in
  the same transaction the seal counted, and abandonment can only touch a `RESERVED` row,
  so the count and the list cannot disagree. `sealPackageDecision` derives the count FROM
  the list for the same reason, and the seal EVENT names them too — it used to record only
  the gaps, so the chain could not tell a Run that froze a population and then hit its time
  limit from one that froze nothing. `EvidencePackageSection` shows them on the Result tab,
  each linked to its Evidence card: a field nothing reads is a field nobody maintains. An
  older document has NO `artifacts` key, which is a different statement from an empty list
  — "this build did not record which" against "this Run froze nothing" — and the section
  says which rather than rendering an empty list a reader takes for the second.
- **A request token records a DECISION, not a Run.** `docs/contracts/run-request-token-v1.md`
  is the whole rule. The first use of a token decides its answer — the Run **this caller's
  own request created**, or the refusal it received — and every later use returns exactly
  that, link included. It used to BIND the caller's token to whichever Run blocked it, so a
  replay after that Run ended answered `ok: true` with its id and walked one auditor into
  another's audit work. The subject (Procedure and period) is stored on the row, because a
  refused request has no Run to read it off, and `procedure_id` carries **no foreign key**:
  a request naming a Procedure that does not exist is exactly the `no-owner` case the record
  has to hold, and a foreign key answered a framework 500 to the caller most likely to be
  probing. Refusals are CODES, never sentences. An authorization denial is deliberately NOT
  recorded — AD-7 forbids caching a role decision, and that is the one thing a replay
  should be able to answer differently.
- **Capture provenance is stored per artifact, never derived on the way to a screen.**
  `captured_at`, `capture_method` and `capture_time_source` on both `run_evidence` and
  `population_evidence`. `registerEvidence` is the ONE way an adapter record becomes
  `REGISTERED`, so the provenance is a property of becoming registered rather than of three
  call sites remembering to set it. `capture_time_source` distinguishes `registration` (the
  clock inside the transaction that wrote `REGISTERED`) from `step-execution` (RECOVERED,
  which is what the migration backfilled onto older `run_evidence` rows) — and there is no
  third value for "we made one up": `population_evidence` was NOT backfilled, because no
  Step Execution produced that artifact, and those rows keep saying `Capture time was not
  recorded.` The instant never moves on a redelivery: re-verifying bytes is not
  re-capturing them. The method backfill IS honest — it is structural, not a guess, because
  every row either table has ever held was written by the adapter path.
- **The reconciliation shows two numbers, not a pass/fail word.**
  `population_snapshot.declared_count` and `retrieved_count`, each attributable to one of
  the reservation's two objects — the declaration to the envelope, the rows to the raw
  artifact — by REFERENCE to `population_evidence`, never a second copy of
  `evidenceObjectKeys` and never bytes the web read (`no-evidence-store-in-web` still
  fails the build, and must). `retrieved_count` was honestly backfilled and a CHECK pins it
  to `included + excluded + indeterminate` for every row; `declared_count` was NOT, because
  the declaration lives in object storage and SQL cannot read it, and defaulting it to the
  retrieved count would make every unreconciled population look reconciled. The stored §H
  verdict stays beside them, READ and never re-derived from the two numbers.
- **Desktop execution stays deferred to Epic 7.** Nothing to build; see the Story 1.8 note
  above for the two planning artifacts that disagree.

Two mechanical lessons from doing it:

- **A teardown keyed on `run_id` misses a row whose decision has none.** A refusal record
  has a NULL `run_id` and names the blocking Run in `refused_run_id`, so every teardown
  keyed on `run_id` alone left it behind and the `audit_run` delete then failed on its
  foreign key — taking the whole file's cleanup with it and leaving 40 Runs that made an
  unrelated suite's bounded read return the wrong page. Delete by `procedure_id`, which the
  row now carries, or by `run_id OR refused_run_id`.
- **And a refusal can name a Procedure the file never created.** The unknown-owner case is
  exactly that, and `procedure_id` carries no foreign key precisely so it can — so a
  teardown scoped to the Procedures a file seeded leaks one row per run, silently and
  forever. A file that initiates Runs also deletes `run_initiation_request` by its own
  `initiator_id`, which owns every request row it wrote whatever Procedure it named. Under
  the old behaviour nothing was recorded on that path, so nothing leaked; a decision that
  starts being recorded starts needing to be cleaned up.
- **Read the FIRST failure.** Four suites failed on that pollution and none of them had
  anything to do with it — `immutable-versions.test.ts` inside `listActiveVersions`, and
  `run-surfaces.test.ts` on four bounded reads that had fallen off page one.

### Agent registration: unknown applicability is not a missing judgment

When the frozen evaluator returns MISSING_OBSERVATION_FIELD for Agent-Judged applicability, preserve unknown as UNEVALUATED without a proposal. It is neither CONDITION_NOT_APPLICABLE nor permission for a guessed model conclusion. Registration rejects proposed or conclusive output for that state before writes.

### Agent work resumption keeps human decisions until registration commits

A closed wait is not consumed when a lease is claimed. Keep its exact wait id and original escalation/capture binding until the Observation transaction succeeds; chained candidate and unnamed-value decisions retain at most two explicit closed wait ids. Never rediscover a decision by guessing from history. A stored snapshot is Evidence, not proof that a reattached browser has that live page; ordinary retries re-navigate and search. Worker inspection recovery must also restore provider context and re-confirm authentication where process state was lost.

### Sealed review history remains visible for an Inconclusive Result

A human rejection can seal a pending Result and set the Run to INCONCLUSIVE. The Run-detail composition must mount the immutable evaluation history for that terminal state as well as COMPLETED; a successful server action followed by refresh must not hide its own decision. Disposable review fixtures delete Work Items before their referenced Evidence rows.

### Agent limits apply again at the commit boundary

A successful browser/model read can consume the deadline while its registration waits for the Run lock. Check the original Run limit inside that transaction and again before the final Gate; retain acquired Evidence but never seal Pass after expiry. Process frozen targets outermost, included population records innermost. Typed uncertainty must consume the same bounded extra retry cycle as transport failure, rather than minting unlimited human Retry grants.

### A submit button's DOM formAction is not its inherited form action

Without a formaction attribute, the button property can report the document URL while native submission uses the associated form's action. Resolve explicit overrides by hasAttribute, otherwise use form.action/form.method. An exact one-request authentication grant must name the URL the browser actually submits to; never broaden it to the whole origin to mask this mismatch.

### Identify stalled integration modules without logging payloads

CI's progress reporter names a test module before hooks start and after it finishes. A stuck browser/database hook otherwise leaves only the prior successful module in aggregate logs. Keep this instrumentation to file identities: raw SQL and test/target payloads are not diagnostic telemetry.


## Explicit target scope in P-1 (2026-09-07)

The owner's takeover instruction requires explicitly selected targets and defers desktop execution. Addendum C names LoanCore and LedgerDesk as defaults, not a mandate to expand the auditor's scope. targetBlockersFor now requires a nonempty explicit selection; contract validation and preservation of every selected target remain unchanged. Selecting a desktop still fails unsupported execution safely. Two canonical web-only P-1 regressions failed before repair and pass after it; 56 focused tests plus domain/root-test typechecks pass. Do not add a hidden desktop or mutate a compiled plan to make browser fixtures run.


## Recovering a workspace's access phase (2026-09-07)

Every work recovery now runs provisionWorkspace before sign-in, adapter/reference completion and investigation. A confirmed replacement returns workspaceReplaced and forces fresh positive authentication; unchanged-context redelivery retains the idempotent SIGNED_IN shortcut. Failed provider release preserves its cleanup reference. P-4's frozen public-page contract is verified using credential-free structural capture and public-access-verified, never session-established. SIGNED_IN remains the durable access-phase state, not a universal authentication claim. Exact required label constants live in one application leaf module.


## P-4 uses the shared rule evaluator (2026-09-07)

The agent producer must pass every frozen included compliance-baseline row, including duplicates, and the explicit Run period to ruleEvaluation. The existing domain compiler evaluates these same baselines; duplicate/missing baseline entries and absent, invalid or out-of-period snapshot times remain UNEVALUATED. Never replace the shared evaluator with a producer-specific expected-value comparison or use wall-clock freshness instead of the Run's period.


## Immediate agent-work foreign key (2026-09-07)

run_agent_work.work_item_id references run_work_item immediately. A first claim must insert its Work Items before saving the checkpoint that references the next item, within the same transaction. The reverse order throws in PostgreSQL and rolls back to RUNNING; a permissive in-memory repository hid it. The focused repository now optionally enforces that real constraint and reproduces the failure before repair. No deferred foreign key or relaxed database constraint is needed.


## P-4 page declaration and grounded batch (2026-09-07)

A P-4 page is one Work Item, with one Observation per distinct frozen baseline key; duplicate baseline rows are retained for shared evaluation, and a missing page value has no fabricated grounding. The genuine model gateway chooses only offered snapshot locators; platform code reads their cells and registers through the shared corroborator/evaluator. A single immutable metadata-only declaration is written with that batch. The Run Gate binds it to registered Structural Snapshot, capture, performed Tool Action and Work Item, and compares actual SQL Observation count, captured page count and declared count through the existing declaredCountMatches predicate. A failed count or missing Observation never becomes Pass.


## Historical stage assertions after agent wiring (2026-09-07)

Adapter extraction now completes references and leaves web work for investigation; tests must assert zero fabricated adapter Observations rather than the removed agent-driven-target refusal. The sign-in-only P-2 browser fixture remains outside the implemented P-1/P-4 investigation scope and must fail with unsupported-frozen-plan after preserving authenticated access. Poll only safe durable stage/status/diagnostic columns when diagnosing stalls. Schema inventory fixtures follow the query's exact column-name order; never remove columns to repair an ordering mismatch.


## Search-control provenance is temporal (2026-09-07)

A search result can repeat the form that submitted it. Bind the request parameters to its single pre-search control snapshot; combining before/after node lists invents duplicate controls and prevents otherwise complete two-key absence proof. Retain the result's independent completeness proof. A supplied ambiguous/invalid pre-search page must not fall back to a cleaner result page. Existing evidence without a pre-search capture uses its one recorded page, preserving the bounded compatibility path.


## P-4 prohibited baseline fields (2026-09-07)

An explicitly prohibited baseline parameter has no approved comparison value. populationFieldFindings therefore exempts only approved_value emptiness for P-4 rows with exact disposition=prohibited. The column must still exist in the declared schema, and approved/unknown-disposition rows still need a value. This matches the existing shared compiler's prohibited-parameter rule and Northstar's canonical fixture; it does not excuse any missing observed parameter or duplicate baseline.


## Disposable journey fixture cleanup and release prerequisites (2026-09-07)

Whole-Run teardown in isolated CI must remove Result/package before protected capture metadata, and Observations before permanent Exception rows; never disable protection triggers for cleanup. run_evidence stores digest, while raw_digest belongs to population_evidence. Railway production worker configuration inspection on 2026-09-07 found no SOLARI_API_KEY, EVIDENCE_S3_* configuration, CREDENTIAL_TOKENS or EXCEPTION_FINGERPRINT_KEY. OAuth reveals names only, not provider values. No infrastructure or variables were changed. The existing Northstar public domain is configured, but this environment's HTTP reader refused it; reachability from Solari remains unverified.


## Agent capture completeness and integrity

Agent Observation registration verifies both structural snapshot and screenshot are registered against the same immutable capture action and target. A screenshot transport failure can retain a grounded Observation, but required-evidence fails and conclusions stay UNEVALUATED; human recovery retains the original capture binding. Only typed transport failure permits partial capture. Integrity mismatch terminates RUN_FAILED immediately; unknown failures never become partial success. Keep the during/after Run distinction in evidence-package-v1: a later sealed-package integrity finding flags the audit trail without rewriting the Run or seal.


## Rejected model proposals are auditable

A provider response rejected by the strict gateway must not disappear into ordinary retry telemetry. Agent work records a fixed security.action-denied event with Run/Work Item/Step Execution IDs when retrying malformed proposals, without retaining rejected JSON. Keep Story4.6's malformed-response retry budget. A successful port response naming an unknown tool is a terminal denied action, never an attempted browser interaction.


## Executable agent mutation evidence

Run destructive guard mutations only in a clean detached linked worktree, never in an engineering branch. The mutation harness requires an assertion-passing baseline and an actual failing assertion after each guard removal, restores each source in finally, and rejects source-anchor drift, import failures and skipped tests. Keep real provider, intercepted-provider, SSR, local Chromium and Solari evidence distinct. A surviving SSR preselection mutation means browser coverage is still required, not that the product guard may be assumed verified.


## ProdConsole catalog fidelity

Golden journeys must derive the registered label and entry-origin contracts from the seed catalog, not a custom superset or deeper URL. ProdConsole already serves Snapshot taken at; declaring that existing label changes no golden timestamp or expected outcome and prevents a missing registration field from being hidden by test setup. Capture time cannot substitute for page publication time. The seeded home page still requires actual model-directed navigation to its configuration page; a journey starting directly at that deeper URL does not prove the seeded route.


### Epic 4 durable human review completion

Human review commands use a dedicated pg-boss queue and a durable PENDING/SUCCEEDED/REFUSED row. The web only authorizes/enqueues; the worker rechecks authority and commits the decision, worker-signed Exception and Result together. Pending-only uniqueness permits a fresh retry after an immutable refusal. Preserve an Exception's original conditions/fingerprint/diagnostics; display the effective review condition set separately. Missing worker fingerprint configuration must leave commands recoverable, never seal a result through a weaker path.


### Epic 4 evidence read grant migration compatibility

Generate unapplied expansions in journal order: generation38 adds bounded read-grant metadata; generation39 adds the optional frozen authentication destination. Keep snapshot prevId links consistent and generate39 from38, not37. An issued grant is revocable, not immutable terminal history: issued→denied/expired clears its capability under the completion constraint; denied/expired stay immutable and request identity/deadlines never change. Revocation must remain possible even if the Evidence is no longer readable.


### Epic 4 exact authentication destination

An in-scope HTTP origin does not authorize every password-form POST beneath it. Credential entry requires the exact query-free authentication_destination frozen in a web registration and its digest; validate the effective submitter/form action before filling credentials. Legacy registrations retain the original six-key digest when the optional field is absent, but credential-bearing execution then refuses before page I/O. Do not backfill a guessed endpoint into historical frozen versions. Configure a new registration/version or explicitly reseed synthetic development data only through the existing authorized flow. A public P4 target with a declared authentication destination must not take the public-access shortcut.


### Epic 4 public ProdConsole landing navigation

The seeded ProdConsole origin is its landing page, not the configuration table URL. Public access verifies the frozen structural landing surface; then the model selects an opaque approved in-scope link before the worker navigates and captures configuration evidence. Derive integration origins and labels from the actual catalog so deeper fixture URLs cannot hide a broken user path. Credential-free execution is restricted by the validated frozen P4/single-web contract, still requires EvidenceStore and Exception signing, and never resolves its legacy compatibility credential reference. Other plans keep the strict credential manifest gate.


### Epic 4 hydrated and worker abuse verification

SSR escaping alone cannot establish that hostile escalation text leaves hydrated choices unselected. Exercise actual browser controls and durable answers, then mutate the selection/answer guard and require the relevant assertions to fail. For runtime scope-widening cases, the test-only model HTTP preload may return hostile proposals, but must never create observations or replace browser results; boot the production worker with the candidate's migrated queues and actual synthetic form authentication. Keep mutation execution inside a clean detached worktree and restore guards after each run.


### Mutation-runner failure evidence

Persist baseline and mutant diagnostics before checking success conditions. A failing baseline is not a killed mutation, and setup/report errors are never assertion evidence. Retain bounded sanitized Playwright errors so hosted failures can be reproduced without rerunning an opaque harness; restore the changed source in all paths.


### Hosted escalation baseline expectations

Retry-or-skip is the platform-owned closed option set Retry, Skip, Abort. The Abort safety action is appended by the application; fixture-supplied option labels cannot remove it. Browser regressions must assert the complete fixed set and unchanged persisted options after explicit confirmation.


### Actual worker abuse failure diagnosis

When a negative worker journey stops before its expected denial, report bounded Run/population/authentication/work status and fixed diagnostics plus model-interception count. Do not dump worker logs or provider messages to diagnose a stage prerequisite; retain the original security assertion.


### Authorized inspector consumption

Read registered artifacts through actor/run/evidence/locator-bound durable grants, signed only by the worker. Keep URLs server-side, recheck roles after bounded digest-verified download, and clear expired/revoked capabilities. Active mismatch and a concurrent seal must resolve through the shared Run failure or post-seal integrity-finding path under the proper lock; never mutate a sealed package to report tampering. Preserve human-selected versus platform-matched grounding labels.


### Agent negative-test population prerequisites

The full synthetic leavers export includes a deliberate duplicate employee key. A test of post-authentication model behavior must explicitly configure a unique bounded subject population; preserve the complete source and production duplicate refusal. Assert that model execution was reached before crediting its abuse guard. Terminal diagnostic errors aid baseline diagnosis but must not mask the security assertion during mutation tests.


### Retrieved abuse and terminal cleanup evidence

Plant hostile text only in actually authenticated synthetic HTML, leaving real form authentication and captured observations intact. Resume through the authorized closed answer; never forward answer narration as model authority. Observe production worker release without calling it from the test. Applied SQL guard mutations require the disposable loopback test database, explicit restoration, and actual assertion failures. Keep paid live-provider tests outside ordinary browser discovery.


### Source identity failure classification

Missing or duplicate included population keys are platform-decidable evidence-quality failures under addendumH. The agent path must preserve every source row and use the existing run-level Gate to seal INCONCLUSIVE. Do not misclassify these as unsupported plans, select a first duplicate, or ask a human to guess an identity. Target search ambiguity remains a separate typed escalation contract.


### Explicit live-provider acceptance

Use a separately selected read-only test workflow on an exact clean candidate and disposable database. Supply provider keys only through encrypted runner secrets. Ordinary PR pushes must not silently consume remote capacity, and missing selected-gate configuration must fail rather than skip. Retain actual provider/model/build identities, evidence digests and confirmed pre-expiry cleanup; preserve machine proposals requiring human review. Never upload raw worker logs, credentials or signed URLs as acceptance artifacts.


### Queue provisioning in concurrent PostgreSQL tests

pg-boss queue creation uses a raw transaction block. Provision it on a dedicated single-connection postgres-js client, then close that client; keep the separate multi-connection runtime pool for lock/race assertions. A setup failure means its tests did not execute and must never count as integration acceptance.


### Singleton enqueue concurrency proof

To exercise PostgreSQL singleton insertion contention, hold the first INSERT uncommitted and observe the competing INSERT blocked through pg_stat_activity. A FOR UPDATE lock on an already-committed duplicate row does not establish that ON CONFLICT DO NOTHING waits. Restore/release the held transaction in finally and require exactly one durable wake afterward. Keep root ownership of branch commits when transport reconstruction is needed.


### Performed search facts and partial results

Absence proof values must come from the saved sanitized Tool Action parameters, never copied from the expected population. Ground the parameter-to-key mapping in the captured control; retain a differing value for the shared absence judge. An explicit captured completeness failure is platform-decidable: preserve partial evidence, mark the Work Item UNINSPECTED and run the shared Gate. A nonempty partial page cannot produce an absent Observation or an invitation for a human to guess completeness.


### Canonical empty-result evidence

A synthetic target's real empty page must expose a truthful count/completeness declaration. A custom test page with a stronger summary can mask a missing canonical target contract. Fix the renderer from its actual matched rows; do not relax browser completion or call an arbitrary empty document proof of absence.


### Retained absence provenance

Preserve proof metadata beside the Observation in the shared registration transaction, with its own canonical digest recorded in the audit chain. Do not change the existing wire digest or backfill historical proof from today's values. Freeze the metadata while its Observation exists and refuse retrospective insertion after sealing. The auditor surface must show searched values, expected keys, completeness and the linked empty-result Evidence. Whole-document inspection requires that exact persisted proof binding; it never invents a matched-row locator.


### Canonical negative journeys and stricter prevention

Read the canonical expectation rows from disk and exercise the real synthetic application's pages. When an earlier authorization guard prevents a downstream defect by construction, retain that pre-I/O prevention test and label any deliberate downstream fault injection separately. The downstream browser/capture/registration/Gate proof must still fail honestly; never relax the earlier guard to make the historical defect reachable in production.


### Retrieved evidence assertions and second retry exhaustion

Compare exact retrieved text after parsing the registered structural snapshot, not against JSON transport escaping. A retry-or-skip answer permits one additional bounded cycle; its second exhaustion fails the Work Item and continues the Run through the shared Gate. A one-record Run consequently ends Inconclusive without a third-cycle human wait. Verify the production terminal cleanup path rather than using a test Abort to manufacture teardown.


### PL/pgSQL FOUND and published trigger repairs

PL/pgSQL has an implicit boolean FOUND variable. Qualify a table column named found (o.found) in trigger queries: the function can be created successfully but fail on its first INSERT. Repair published trigger code with a forward CREATE OR REPLACE migration, retaining Run locks, immutability and sealed-package guards. A populated upgrade must preserve historical missing proof rather than backfill it.


### Remote release ownership

A known live workspace's Run, provider mode and workspace ID must match before either teardown or a provider release request. Local release tests alone can hide a remote-only forged-reference branch. Reject a known mismatch without provider I/O; preserve the unknown-live persisted-reference path for legitimate restart cleanup, provider-confirmed absence and retry after provider failure.


### Durable decision race evidence

Hold the real command's transaction after its writes and before commit, then observe competing production commands blocked in pg_stat_activity. A separate fixture row lock followed by only one command, or Promise.all without a controlled hold, does not prove the required race. Check uncommitted decisions remain invisible, then release and require exactly one winner, precise loser refusal and unchanged original machine/evidence history.


### Generic landing navigation and employee scope

A canonical application landing page must expose generic query-free navigation instead of fixture-valued example searches. Offer model-selected links copied from the captured page only within frozen origins and permitted navigation. A page containing either declared identity datum is a record surface, even when its value is not the current employee; it cannot use the generic landing path to open unrelated records.


### Exact escalation and review mutation targets

A closed option-set mutation is not a closed-wait mutation. Mutate the production persistence guard and use real PostgreSQL duplicate-answer assertions while keeping independent SQL protections. Mutate the actual worker-used planner for unique grounded matching, not an unused helper. Threshold tests must exercise the inclusive frozen decimal boundary. Partial unit-only mutation reports stay incomplete.


## 2026-09-08 — Complete evaluation journey verification

Human review browser acceptance starts with the actual compiled worker producing a pending machine evaluation, then submits the real Run Detail command and checks final sealing with unchanged original facts. A clearly synthetic model HTTP fixture may choose only current opaque approved tools; it cannot insert Observations or pending Results. Sign-in audit rows record the final redirected destination plus the originating method, not an invented copy of the frozen form endpoint.


## 2026-09-08 — Grounding surface test identity

The Evidence list displays grounding directly. Metadata-only seeds assert provenance and exact protected links; they must not claim to download nonexistent objects. Actual inspector acceptance uses the separate registered-artifact/worker grant journey.


## 2026-09-08 — Retain observable mutation failures

CI mirrors sanitized synthetic mutation report JSON into logs as escaped data in addition to uploading the artifact. This makes exact per-case failures reviewable when artifact materialization is unavailable. Missing or partial reports never count as accepted; the existing mutation runner remains the gate.


## 2026-09-08 — Authorized notification bell count

The application shell reads the current authorized open-wait count using the inbox's fresh database role predicate, independent of its bounded list length. Unknown counts remain unknown on query failure, with fixed telemetry diagnostics only. Browser restart scenarios establish their own delivery baseline so a preceding failure cannot fabricate an idempotency failure.


## 2026-09-08 — Exact inspector labels and tested PR identity

Grounding tests select exact Field label headings because inert provenance labels also contain those words. GitHub pull-request CI checks a synthetic merge commit: record its SHA and compare its complete tree with the PR head before attributing results to the candidate.


## 2026-09-08 — Cleanup observation is not persistence acknowledgement

A passive browser-close observer fires before the production cleanup transaction commits. Browser tests must require closed/unusable state and separately await the persisted RELEASED row within a bound; neither fact substitutes for the other.


## 2026-09-08 — Isolated cases need independently declared sources

A unique employee inclusion does not remove source-wide invalid/duplicate rows from the Gate. Success/pending fixtures use a separately declared HTTP source with the unchanged canonical row and independent count/digest/cover; the complete golden source and its expected Inconclusive outcome remain untouched. Real captured-inspector tests follow the worker-produced grounding, not a seeded surrogate.


## 2026-09-08 — Canonical absent-account worker proof

Absence browser acceptance begins with the compiled worker reading a separately declared canonical case source. It must retain actual searched values, registered empty Evidence and complete proof through the shared judge, then open that same whole-document Evidence without inventing a matching-row locator.


## 2026-09-08 — Live case source provenance

A representative remote-target audit may use the independently declared canonical case CSV acquired by the actual worker over HTTP. Its report must label source and S3 as worker-local synthetic fixtures, never deployed integration acceptance; the model still obtains target observations through the actual Solari browser and shared audit engine.


## 2026-09-08 — Complete ProdConsole worker verification

The canonical P4 browser journey crosses the compiled worker and durable queue as well as the existing application-stage integration. It asserts the exact failing Gate set before the golden Inconclusive Result; a typed synthetic provider selects only approved tools and never returns observed values or fixture expectations.


## 2026-09-08 — Exact absence and accounting mutations

Story4.5 mutation removes a key in the producer actually called by the worker; Story4.6 mutation removes its durable measured-usage increment. A helper-level or no-test failure does not establish either contract. The shared harness retains source/test hashes and exact assertion failures.


## 2026-09-08 — Exhaustion records the shared quality Gate

An agent Run limit must still record every existing §H check before sealing. A typed limit cause supplies terminal context to the shared Gate: quality rows remain truthful, independent execution failure remains RUN_FAILED, and passing quality cannot repair an exhausted budget into Completed. The returned actual terminal state is distinct from the quality decision; original recorded results win on replay.

## 2026-09-08 — Credential containment acceptance scans

A malicious-response regression must put the synthetic credential into a valid provider response and prove refusal before persistence. Discover Run-owned persistence subjects from PostgreSQL's catalog instead of maintaining a table allowlist. Scan raw values only in memory and assert booleans so even a planted guard failure cannot echo the credential into assertion logs; retain terminal cleanup and post-shutdown scans.

## 2026-09-08 — Search continuation from captured history

An empty results page may omit its original form. Offer model-selected navigation only to a same-Run/target, query-free previously captured control page with the remaining declared key; require a fresh capture before searching. The old capture proves navigation provenance, never today's results. Keep the actual HTML parameter name distinct from the logical population lookup key.

## 2026-09-08 — Compiler field vocabulary is not target capture scope

A compiled plan carries the union of supported condition fields, including source-supplied and optional-variant values. Agent Observations retain mapped target fields and explicit Evidence Requirements, not null placeholders for every compiler field. Missing requested fields still fail required-evidence; unavailable rule inputs remain Unevaluated through the shared evaluator. Regression fixtures must derive the real plan instead of hand-trimming its vocabulary.

## 2026-09-08 — Explicit target values versus normalization

Compiler-1 named sets compare exact strings and corroboration permits no case-folding. When a target's display values differ from Template defaults, author and freeze a target-specific expression through the existing compiler; retain the default mismatch as an unnamed-value refusal. Never alter captured case or turn plain-text role display into an invented JSON list to satisfy a journey fixture.

## 2026-09-08 — Verify snapshot reads in their actual ledger

ProdConsole browser actions navigate and freeze evidence; the model then selects approved local snapshot reads. Verify those reads through persisted model turns bound to the Work Item's registered snapshot, the frozen tool catalogue and independently resolved cells. Do not invent browser HTTP actions for evidence already stored. Retain exact golden Gate, evaluation and declaration checks alongside that proof.

## 2026-09-08 — Independent completion barriers in mutation tests

Await durable WAITING/AWAITING_AUDITOR or the post-retry terminal Run before directly asserting its already-committed security event. Polling the removed guard's event wastes the entire execution budget on an intended mutation failure. For browser closure, retain the full RELEASED wait; after that commit, the passive observer has already queued its facts, so a short pipe-delivery wait suffices. Never shorten worker execution budgets or accept a missing event/closure fact.

## 2026-09-08 — Diagnose containment failures without leaking them

A passing credential test in the main suite does not waive a baseline failure in the mutation job. Preserve the expected wait and scanner assertions; report only closed-vocabulary durable diagnostics, finite counts and booleans. Independent lifecycle repetitions must all pass, with retries disabled. A terminal Run or failed setup is not a successful guard-removal result.

## 2026-09-08 — Reattachment is a pending prerequisite

Workspace reattachment commits PROVISIONING before provider I/O. Queue redelivery and the independent recovery sweep may overlap that interval even after a caller has previously provisioned successfully. A completed sign-in/extraction checkpoint alone cannot distinguish this pending workspace from a genuinely missing one. Exercise the overlap by holding actual attachment after its durable claim; require no work mutation or browser/model action until OPEN returns, then resume the original bounded retry. A passing repeated baseline is not a causal explanation for an earlier intermittent failure.

## 2026-09-08 — Losing an attach lease does not own the session

A losing provisioning claim may release only an uncommitted handle that it created. An attached existing identity remains named by the durable row and may already be used by the winning lease. Retain it for that winner or the terminal reaper; closing it as generic lost-claim cleanup revokes another live claim. Test both overlapping attachment and overlapping creation with an elapsed lease, preserving newly created orphan cleanup.

## 2026-09-08 — Pending workspace recovery must stay discoverable

Work prerequisites defer PROVISIONING/RETRY workspaces without changing Run state, evidence or work budgets. Authentication and work recovery both admit workspace RETRY and expired PROVISIONING, then provision before executing; neither selects a live provisioning lease. RETRY does not wait for the old lease timestamp because a failed claim retains it. Missing rows still fail explicitly. Cover these predicates before and after extraction, with fresh repositories and durable failure/lease injection.

## 2026-09-08 — Scan the refreshed answer page

An answer success banner is rendered before router.refresh completes. Database closure and that banner do not establish that the refreshed page/metadata has committed. Before the post-answer axe scan, require the open Escalation panel to disappear and the exact Run route title to appear. Retain all axe rules and the original violation assertion; never retry a completed failing scan or hide document-title findings.

## Closed diagnostics in malicious-output verification

The malicious HTTP fixture returns valid action JSON with an invented tool ID. Its actual-worker assertion must require model-invalid-response:invalid-selection after diagnostic classification was added; accepting every invalid-response suffix would lose that proof. Keep the durable wait, security denial, frozen scope, zero Observation and zero Pass assertions unchanged.

## Agent response contract examples

Prompt version3 states the existing strict action parameter array and uncertainty object shapes explicitly, including empty parameters and nullable rationale, with generic JSON examples. Validate that the provider receives an example accepted by the unchanged parser and still rejects invented tools. A schema-mismatch diagnostic alone does not justify increasing tokens, changing the model, or weakening validation; raw rejected responses remain unretained.

## Frozen worker search arguments

The worker deliberately rejects all model-authored search parameters and resolves values from parametersByToolId. Its planner must therefore advertise parameterNames=[] and explain that the platform supplies the frozen current-record lookup value. Advertising a writable field while withholding its required value contradicts that contract and can induce an honest insufficient-evidence wait. Preserve exact control binding, parameter-substitution denial and the original shared Observation engine.

## Action uncertainty versus final evaluation

Agent prompt version4 uses a complete empty-parameter response envelope matching the worker, and distinguishes uncertainty about a safe next action from missing final audit evidence during investigation. It must still stop on unresolved scope/identity or no safe offered action. Evaluation, persisted uncertainty, human review and evidence gates remain unchanged. Generic gateway compatibility does not by itself prove a response is executable by the worker; test the example against worker-style parameterNames=[] and retain parameter-injection refusal.

## Evaluation input corroboration

The pre-evaluation rule preview already checks the captured Observation with snapshotCorroboration. Supply that judged copy, including its actual identity/attribute verdicts, to the model instead of the original record's null corroboration placeholders. Do not invent matched states or mutate the original capture; transactional registration independently repeats its checks. The explicit human unnamed-value/Unevaluated branch retains its existing behavior. For live diagnosis, an accepted bounded user-facing uncertainty summary may be retained only after the normal credential guard and whole-report secret scan; this excludes provider reasoning, rejected output and raw logs.

## Independent live isolation gate

A genuine auditor decision may block representative audit acceptance after confirmed cleanup. The explicit solari-isolation-acceptance label can select only the existing overlapping-session test on the exact candidate. It does not make the combined audit gate green, alter maxFailures or relax any isolation assertion. Confirm prior remote cleanup before selecting it; recording remains disabled and the workflow remains read-only.


## Guided preparation hydration and historical upgrade fixtures

The outline uses native section links and keeps sections readable before hydration, then
shows the selected editor without unmounting other unsaved forms. Preserve a section selected
while JavaScript loads. Editor-contract tests must wait for data-guided-ready before exposing
panels; changing server markup first creates hydration mismatches and lost interactions.
Keep one native disabled fieldset around editing controls until hydration installs their
change handlers and submission registry. Saved text remains readable. Enabling the same
fieldset preserves component identity and focus. Tests should select nested Evidence groups
by their own accessible legend, and wait for an enabled control before calling focus().
Populated upgrade fixtures must insert the columns of their historical generation, rather
than call the current Drizzle repository against an older schema. Keep their frozen-input,
authorship, immutability and compatibility assertions intact.


## Bounded procedure writing assistance (Stories2.9–2.10)

Writing assistance has a separate application port and dedicated server-only
AUTHORING_OPENAI_API_KEY. It uses the installed OpenAI AI SDK Responses provider with
model gpt-5.6-terra, store:false, low reasoning, no summary, no temperature, no tools,
maxRetries:0 and a 30-second timeout. Plan-check and Run configuration remain independent.
Reserve a request receipt under the Procedure lock before provider I/O, release the
transaction during I/O, then persist a validated proposal. Retries reuse the same exact
request. Acceptance uses the existing authorised update command in the receipt transaction;
attribute even an identical-wording acceptance to the human. Audit payloads cannot contain
provider objects: the receipt holds identity; immutable events hold only identity references,
usage and hashes. Exercise the real audit validator in command fakes.

Suggestions bind the saved authoring revision, section basis, context hash and actor.
Any authored change conservatively stales pending suggestions; plan-worker status and
section review alone do not. Unsaved fields and uncertain acceptance block review/submission;
generation does not. Per-section sessions prevent late responses appearing in another editor.
The explicit test-only OpenAI preload proves SDK/workflow behavior and must never ship in
runtime images or be described as live-provider or semantic-faithfulness evidence.
Check supplied prose for known credential references before authoring I/O; do not silently
redact saved instructions or change the manual-writing contract. Objective proposals follow
the domain's4,000-character limit in both editor and acceptance, rather than the other prose
sections'10,000-character bound. A completed receipt can be ready but stale after submission;
persist its usage and prove acceptance is refused both before and after completion.
Authoring screenshots must be written to a named testInfo.outputPath before attachment.
Body-only Playwright attachments use opaque report filenames and cannot be selected by
the remote-review PNG exporter. Retain the original bytes, dimensions and SHA256 identity.

## Native browser timeout cleanup

Playwright's own timeout can reject just before an independently enforced action deadline.
Treat the installed Playwright TimeoutError as cleanup-worthy as well as the outer deadline
error; otherwise a one-millisecond race can leave an expired page reusable. Preserve the
deadline, execution policy and existing real-browser assertion. The deterministic regression
case forces the native timeout while ample outer budget remains and requires page disposal.


## Guided Builder browser assertions and narrow help actions (2026-09-11)

The guided outline hides unselected groups. Browser journeys must open Review and submission
before checking readiness or Submit, then navigate back to the actual editor. Keep dirty,
required-field and focus assertions intact. The adopted responsive Builder remains editable
below 900px: verify a saved mobile change and reload, not the old absence of save controls.
Long writing-reconciliation labels must wrap inside the contextual help column. Capture
inspection exposed the overflow; the stale-response browser case checks its actual bounds.
Name-editor copy must not assume it remains at the end of the whole Builder.


## Late writing-response accounting after rejection (2026-09-11)

A human may dismiss a writing request from another tab while its provider call is pending.
The late response must preserve the rejected receipt and never retain or apply its proposal,
but known token usage still belongs in the receipt and minimised audit event. Account for
that metadata without touching the procedure, authorship, preparation reviews or plan jobs.

## Authoring failure diagnostics and recovery (2026-09-13)

HTTP 200 on the authoring NDJSON route only means the stream began. Unexpected
preparation/finalisation failures can still produce an `uncertain` frame. Preserve
that uncertainty and the exact request ID; never turn a transaction exception or
partial output into a confirmed suggestion. Report the failed stage through the
existing minimising telemetry facade, without error messages, stacks or content.
OpenAI streaming errors can arrive in `onError` before a generic output rejection;
map them to the closed `AuthoringProviderError` categories before crossing the port.
Confirmed failures have durable receipts and actionable messages. HTTP auth/input
refusals must not strand a user in lost-response recovery. Test real SDK error
transport, receipt persistence/replay and manual editing separately from live model
access. A configured Railway variable name and green synthetic CI prove neither
provider access nor resolution of an opaque production incident.

## 2026-09-15 — Chat consent and trusted authentication ingress

Question marks retain their meaning before command normalization: a command-shaped
question grants no save, selection, review, dismissal or navigation authority. The
writing composer tracks fresh human edits separately from prefilled saved/proposed
prose; opening Improve wording, reconciling a proposal and submitting generation
clear command eligibility. The existing writers still own all mutations and guards.

Railway's public HTTP edge supplies `X-Real-IP`. Web deployments explicitly set
`AUTH_TRUSTED_IP_HEADER=x-real-ip`; Better Auth reads only that header, with no
fallback to a caller-controlled forwarded chain. Keep the origin behind the edge;
another hosting/proxy arrangement needs its own verified ingress contract. The
database-backed 10-per-minute sign-in limit and IPv6 normalization remain in force.
The identity integration exercises separate clients, spoofed forwarding headers
and shared counters across authentication instances.

Builder context-field assertions scope to `.ls-template-fact`, because the mounted
chat composer is another textarea and is not a fifth saved context field.

## 2026-09-15 — Authoring errors after streaming begins

The installed AI SDK reports post-output provider failures as `StreamProviderError`,
not `APICallError`. Classify both by their HTTP-equivalent status, never by copying
provider error text or arbitrary codes. A 429/503 after valid partial JSON remains
a failed receipt with no applicable proposal. Keep the `finishReason === 'stop'`
guard; valid JSON alone is insufficient. Incomplete and invalid output have distinct
closed categories. Local progress/authorization failures use `AuthoringProgressError`
and the `progress` diagnostic stage, without retaining their cause.

These corrections repair reproduced diagnostic defects. They do not retrospectively
identify the production `UNCONFIRMED` incident or prove a live provider recovery.

## 2026-09-15 — Replay fixtures with a running worker

Publish a synthetic RUNNING Run and its held population/agent checkpoints in one
transaction when a real worker is already running. Otherwise recovery can claim the
partly seeded fixture and reserve required evidence before the fixture seals its
package. A ready population plus an unexpired EXECUTING agent claim holds the Replay
fixture; mark the agent phase TERMINAL only after the Run becomes terminal. Keep the
real frame-grant worker and all authorization/evidence assertions. Cleanup removes
the phase and population rows before deleting evidence and the Run.
If a surface test temporarily reopens the Run, reopen its held agent claim in the
same transaction; a TERMINAL agent phase makes a RUNNING Run eligible for recovery.

## 2026-09-19 — Auditor Workspace P0 is a design/capability gate

Owner authorized AW v1.1 and the challenge log on `feat/auditor-workspace-v1-1`,
from main `44fb5966`; no merge/deploy permission. Preserve the full target experience,
including protected near-live preview and secure authentication for the first supported
flow. `docs/prototypes/auditor-workspace/index.html` is a synthetic, disconnected design
preview. Its local storage holds presentation preferences/drafts only; simulated receipts
are never application persistence proof. The P0 browser job supplements normal CI.
Do not count a compiled plan as the explicit strategy capability graph, provider SDK
methods as a measured preview/privacy guarantee, or the specification's models as
application tests. Current application mechanisms remain execution/evidence authority.

AW-P1 evidence-load distinction: an omitted `GroundingInspector.snapshotOf` means the
page has not loaded the detail; a supplied resolver returning null means unavailable.
Do not turn lazy loading into evidence loss, and do not hide a real mismatch/unavailable
result. The optional resolver remains separate from stored execution corroboration.

### Auditor Workspace P1 review projection — 2026-09-19

Record review membership starts with `(run_id, population_row.ordinal)` crossed with the frozen execution classification's adapter/web targets. Versioned reference files do not add required inspection units. Map observations only through their actual Work Item, frozen step, target and exact subject key; duplicate/missing keys and unmappable historical rows cannot gain coverage. Global pending assessments include unattributed stored evaluations, and an unknown exception-bearing source count is not zero. Review overlays use the existing effective-value expressions; a rejected null confirmation must never fall back to pending.

The queue persists an immutable, actor-bound ten-minute presentation snapshot with at most two retained snapshots per actor/Run and a 10,000-unit admission bound. HMAC cursors bind snapshot, actor, Run, query and unique position. Every page/detail rechecks current role. Concurrent creation uses bounded serializable retries; no transaction crosses a browser request. The worker expires these presentation copies independently of browser activity. A current inspector reads its result/evaluation facts inside one short consistent transaction; opening it never reviews or seals evidence. These caches are not audit records or an alternative execution/review authority.

### Auditor Workspace record inspector and historical checks

A missing historical check set means unknown inspection, not an invented evidence failure. Found records require matching corroboration; absence credit requires recorded search checks/provenance. Reference-only plans still retain source rows. Selected review authorization, command status and reviewer names must share the selected-record transaction; use transaction-compatible readers, not unsafe casts. Keep old artifact anchors on the technical Evidence route while normal review preserves the source ordinal and signed page cursor.

Raw Drizzle `sql` timestamp parameters must use ISO text with an explicit timestamptz cast; schema column encoders do not run for an interpolated Date in raw SQL. Keep Next.js route configuration statically exported at the route itself. Filter forms follow the POST-first guard and use authorized same-origin navigation endpoints, with bounded bodies, rather than relying on hydration.

### Auditor Workspace P2 content and composition — 2026-09-19

Conversation is off by default and has an explicit synthetic-only development mode with a dedicated content-encryption key. Keep immutable message identity/audit metadata separate from governed ciphertext; authenticated encryption binds content to the exact Run/message. Never reuse credential keys, place raw conversation text in audit payloads, or treat a secret detector as private-pixel containment. Exceptional content removal preserves metadata and cannot replace/resurrect content; real-data retention/export/key lifecycle still needs the owner's D2 policy.

Retry the same unconfirmed conversation request with the same idempotency key; generate a new key only after a durable receipt or changed semantics. A successful response requires the persisted message ID and sequence. Read-only conversation and explicit non-executing control replies are P2 groundwork, not P3 command execution. The live workspace must label action-linked captures honestly, reuse existing protected reads/wait controls, and keep decisions beside the conversation. Live count reads reuse P1 projection logic without evicting immutable review snapshots.


Browser fixtures must decode frozen JSON field names exactly: compliance condition identity is `conditionId`, even when the SQL alias is `condition_id`. Record-first Evidence navigation tests must assert the new queue/unavailable state before following Technical details for historical artifact assertions. A passing seeded model or SQL projection does not replace the actual browser fixture setup and navigation.

Operational conversation entries reference the exact immutable audit event and derive
fixed copy on authorized read; they do not copy payload prose or create another event
authority. Serialize their sequence under the existing audit aggregate head lock, shared
with human message writes. Acquire the Run key-share lock before the audit-head lock:
the metadata foreign key would otherwise acquire it in reverse order and could deadlock
with an ordinary Run command. A conversation history bound must not stop audit recording
or execution. Historical events are not silently backfilled or attributed to a source row
by nearest time. New database fixtures must preserve the unique active-standard-period
invariant even when their only intent is testing cross-Run access.

Raw parameters passed to PostgreSQL polymorphic JSON constructors need explicit types
(`runRevision::integer`); a successful page read cannot prove its write path. Client-only
conversation controls stay disabled until hydrated, so an apparently actionable SSR
button cannot discard a click. Browser role-revocation fixtures must serialize restored
timestamps as ISO text; failed cleanup can revoke the shared test identity and invalidate
later journeys. Preserve those cascading failures in the checkpoint rather than counting
the unrun tests as successful. Screenshot capture must not mutate input caret styles while
React is still hydrating server-rendered native forms.

### Auditor Workspace compact review surfaces (2026-09-19)

Keep record-review lifecycle actions in an explicitly opened details panel so the queue begins in the first viewport. Workspace decisions use frozen-plan action words and numbered supporting-capture links; raw Step/Evidence identities remain in Technical details. These presentation choices never alter wait IDs, answer options, revision checks or Evidence read grants.

### Auditor Workspace transaction-bound wait composition (2026-09-19)

Conversation-to-command adapters must bind PostgresWaitRepository, role reads and audit denial writes to the enclosing Transaction. Drizzle nested transactions use a savepoint on that same connection. Calling a pool-backed wait command while holding the Run lock risks self-deadlock and cannot make the intake/domain link atomic. The integration proof must throw after the real pauseRun call and verify that marker, audit event and narration all rolled back, then verify an outer commit preserves the original requester.

### Bounded PostgreSQL sequence assertions (2026-09-19)

postgres.js returns audit_events.sequence (bigint) as text and conversation source-event sequence (integer) as a number. Cast the bounded audit sequence explicitly in tests that compare the two; do not misreport a representation mismatch as a failed domain or atomicity effect.

- **AW-P2 browser follow-up:** CI `35450768006` retained the real active-worker capture and finished 227/230 application browser checks. Await selected-record navigation before reading its URL; calculate the oldest message from the persisted initial count because committed narration adds entries. The active/decision/inspector screenshots exposed viewport and decision-density defects, so they do not close G1.

### Auditor Workspace pause receipt identity (2026-09-19)

A conversational pause must carry a server-generated commandId on the existing RunPauseRequest. Client pause envelopes still accept only runId. Another command's pending marker is a refusal for the conversational adapter; the legacy button remains idempotent. Received/interpreted receipts precede the existing handler; queued/applied/superseded receipts derive from that handler/worker's exact audit event in the same transaction. A receipt must never infer application from the Run state or a nearby timestamp. Bind all nested wait, role and denial dependencies to the outer connection. Reserve the extra operational conversation sequence and do not charge exact safety shortcuts to the question limiter. PostgreSQL receipt-transition guards must coalesce nullable first-transition predicates to false; SQL NULL must never permit skipping received.

Exact unqualified Run pause normalizes viewing-only source/wait context to null before persistence. It skips evidence fact reads and the ordinary message quota, with a separate rate bucket; non-safety messages retain full context validation. Absolute history bounds remain enforced.

Interaction command inserts must join the exact conversation-received audit fact (actor, message, intent and semantic fingerprint), not only a generic auditor message. Receipt reads fail closed if their authoritative source event is absent or no longer matches; storage damage must not display a credible applied status. Reply context revisions are read after the domain command.

### P-4 lifecycle boundary after model response (2026-09-19)

The specialized ProdConsole page path must call the existing lifecycle boundary after its model turn, before uncertainty handling or observation/declaration registration. Otherwise a safety request arriving during that read is superseded by completion without pausing. Preserve the completed model-turn evidence on the superseded attempt; after Resume, prove the fresh successful attempt separately instead of asserting only one model read occurred. Browser fixture display names need not embed their generated isolation IDs.

### P3 real-database fixture corrections (2026-09-19)

CI `35453444876` showed that a wait-reply envelope intentionally classifies pause-now as clarification. A Run-wide safety test must use no explicit wait reply; do not weaken that interpretation to make a fixture pass. Record selection remains irrelevant to exact unqualified pause. Terminal cancellation fixtures must remove the sealed Result/Evidence package before deleting their Run, following existing pause-test teardown. Add new migrated tables to the exact schema inventory (generation 53).

### Workspace viewport and native capture follow-up (2026-09-19)

A fixed viewport percentage cannot size a workspace below variable route banners: measure its remaining space and verify actual element bounds before browser auto-scroll. Native capture mode wraps the existing protected image and must prove natural dimensions and keyboard panning; a fitting image alone is not legibility proof. On sunken record cards, muted #64748B has only 4.34:1 contrast; secondary #475569 gives 6.92:1. Compact record review must preserve a working decision link even when conversation is disabled.

Record inspection must render the selected Observation’s original attributes, not just generic account/status summaries or normalized values. Reuse inert untrusted-content rendering; frozen source values and actual captured target values are different evidence.


## 2026-09-19 — Validate the changed-operation fixture before testing idempotency

An unqualified `pause now` deliberately ignores stale selected-record context. Ordinary
messages do not inherit that exception. Reusing the pause fixture’s out-of-range ordinal
for `resume` tests malformed-envelope refusal before it can test idempotency conflict.
Keep both guards: assert the malformed ordinary request, then use a valid null selection
with the same request key to prove a changed operation conflicts. Normal CI on `f89b1a0`
passed 603 of 604 PostgreSQL cases and exposed this distinction; the follow-up must still
reach and pass the actual worker application, rollback and revocation assertions.


### Actual workspace proof must distinguish metadata from evidence bytes (2026-09-19)

Normal CI `35454413253` passed the compiled-worker pause/native-capture/record-inspector
journey and 228/230 browser cases. An unavailable protected snapshot still displays its
registered grounding label through UntrustedText; assert that no actual snapshot cell
is displayed, not that all inert metadata disappears. Measure meaningful visible chat
history as well as Send and the first contextual choice: a control can fit while leaving
almost no conversation. Compact full provenance accessibly; aria-label on a paragraph
is prohibited. Keep fresh/live-state information visible in compact workspace chrome.


### Controller fencing belongs inside the existing Resume transaction (2026-09-19)

Run controller operations lock the canonical Run before reading PostgreSQL
clock_timestamp; transaction-start time can renew a lease that expired while waiting.
Retain the row after release/expiry and advance its epoch, including same-actor
reacquisition. Resume reads that fence under the existing wait transaction, with current
role, revision and confirmation epoch. Require every Resume adapter to name its server
policy explicitly. Once enrolled, mode-off cannot restore epoch-free Resume: disable
new enrollment while retaining protected recovery controls for existing Runs.

Lease row, audit event and existing timeline notification share the transaction. An
expiry is attributed to the system observer with observedBy metadata; the auditor did
not cause the clock deadline. The insert trigger requires epoch one, so use a locked
UPDATE then INSERT, not an UPSERT whose BEFORE INSERT trigger sees a renewal epoch.
Never extend controller ownership into Pause/Stop safety or existing exact-wait rights.
Capture the Resume revision/epoch when its confirmation opens; live rereads cannot
silently rebind a previously shown decision. No new manager takeover permission is
implied. Lease-renewal payload idempotency and full conversational command receipts
remain separate uncompleted P3 work.


### Shared styling is enforced by the whole unit suite (2026-09-19)

CI `35457445681` passed TypeScript/boundaries and 4,690 unit tests, but the stylesheet
contract caught a nonexistent ls-text-caption class in the new controller view. Use the
existing ls-caption token. A focused component pass does not replace the global static
class inventory; its failing guard remains unchanged.


### A record Replay link must resolve the record it names (2026-09-19)

RecordReview emitted ?workItem links but Replay ignored searchParams, silently showing
the first capture. Resolve only from the authorized Run’s existing jump targets, with
the same Step Execution work-item fallback as its jump list. Invalid/multiple/cross-Run
or bounded-out selections must show no selected frame, not a guessed first record or
a false “this Run captured nothing” claim. Preserve explicit scrubber choices and start
paused on reload. Multi-target inspectors expose target-specific links. Evidence reads
add their legitimate evidence-access audit events; readonly Replay proof compares Run
state and all other audit facts rather than forbidding the access trail itself.


### Restore shared browser identities with encoded timestamps (2026-09-19)

postgres.js result Dates cannot be passed straight back as timestamp parameters. Encode
assigned_at as ISO text with an explicit timestamptz cast, including finally cleanup.
A failed role restoration can invalidate every later authenticated browser case; keep
those cases unverified until a clean rerun. Resume audit expectations must include the
actual controller acquisition; do not relax the authorization or event-chain assertions.


### Prove composed review with worker-produced records (2026-09-19)

The standalone evaluation fixture seeds machine proposals for command testing and is
not proof of record projection joins. The actual P-1 worker journey already produces
the frozen work item, population, capture and C2 proposal. Route its confirm/reject
journeys through the record queue and inspector, retain the selected URL across reload,
and compare original Observation/evaluation/Evidence rows before and after review.
A successful submit is insufficient: require the worker command and sealed Result.

### Await fixture notification outcomes before Replay baselines (2026-09-19)

A real raised Escalation queues independent notification deliveries; their worker audit
facts may land after fixture setup returns. Wait for both persisted channel outcomes
before taking a no-execution-effects Replay baseline. Keep the complete non-access
audit comparison, including event types for diagnosis. Role-revocation browser checks
must account for the shell bell's exact `/api/runs/events` 403 as well as the Run stream;
do not allow arbitrary console errors. Playwright screenshot paths need a `.png` suffix.

### Conversational Resume binds the reviewed pause (2026-09-19)

Persist a Resume proposal with its exact pause wait, opened/deadline instants, controller
epoch, Run revision and frozen plan digest. Confirmation accepts only Run/command IDs
and reuses `resumeRun` inside the conversation transaction. Recheck current role, live
controller, exact pause and frozen plan; a released/reacquired lease cannot rebind it.
The existing web Resume event projects directly to an applied interaction receipt in
that same transaction. Retry validates that source fact and does not close another
wait. Both intake and displayed proposal must remain readable at first confirmation.
Disclose the existing safe attempt restart. The worker-produced browser journey and
lost-response/retry journey are required application proof, not replaced by model tests.

### Size record filters for their pane, not the viewport (2026-09-19)

The actual worker-to-inspector capture exposed search/filter controls reduced to a few
pixels inside the desktop queue. The viewport was wide, but the adjacent inspector
made the queue narrow. Use an auto-fitting grid with readable field minima so controls
wrap with their own pane. Browser proof must measure the fields with the inspector open.

- Auditor Workspace revocation browser checks must keep pre-revocation console errors
  strict. After revocation, the shell and Run event streams can correctly return 403;
  only allow the exact Chrome error at the exact same-origin event paths in that phase.
  CI 35466506732: 624 PostgreSQL tests and 233/234 full browser tests passed; the last
  failure was this workspace console assertion after all access-refusal checks passed.

### Confirmed Stop carries cancellation identity through the worker (2026-09-20)

Exact conversational Stop records a proposal bound to the Run revision and frozen plan;
only explicit confirmation calls `cancelRun`. Historical evidence selection cannot retarget
it, and it never requires the controller lease. Compose cancellation, roles and audit writes
on the enclosing transaction. Preserve the server-created command ID on the existing durable
cancellation marker, including the independent result/wait readers, so worker restart and
lost-response recovery project the original event rather than infer success from Run state.
Another cancellation owner is a refusal for conversation; legacy controls remain idempotent.
A revision test must change actual Run content: the database deliberately ignores direct
revision-only updates. Terminal fixtures must use actual completion/cancellation so open waits
close and the required sealed Result exists.

Confirmed safety receipts also need storage-level ownership: bind cancellation markers to
same-Run Stop commands and original actors, then preserve the entire accepted marker. The
cancel event precedes `completeRun`, so sealed-result consistency belongs in a deferred
constraint; replay must independently verify the actual canceled/sealed outcome. Lock governed
intake/proposal content in stable ID order for first confirmation. A displayed execution wait
must not reinterpret exact Run-wide Stop as an answer to that wait.

For a terminal conversational Stop, LiveGate replaces the subscribed view with its terminal
view. The applied ledger receipt is valid lost-response reconciliation; a retry modal need
not survive that remount. Test exact authenticated replay separately, and exercise modal
retry with a still-running queued Stop. Never reopen the terminal gate to satisfy a test.

On constrained local browser-test hosts, `INTELLIFIN_LOW_DISK=1` trades disk for memory:
Turbopack cannot evict its cached graph without its filesystem cache. When disk is available,
use `INTELLIFIN_LOW_MEMORY=1` instead for full cache eviction; do not combine the two modes.
Keep worker deadlines and product assertions unchanged and warm cold routes before timed
worker journeys. The Node runtime import in `instrumentation.ts` must sit inside the positive
`NEXT_RUNTIME === 'nodejs'` branch so both bundlers can exclude it from the edge bundle.

### Renewal receipts and browser authority are separate facts (2026-09-20)

Controller renewal uses a required UUID request key scoped to actor and Run, with exact
operation/expected-epoch comparison after fresh authorization and before current-epoch
admission. The immutable renewal event is its receipt. A nullable lease renewal marker and
deferred matching-event guard bind the effect to that event; use explicit durable identity,
not PostgreSQL `xmin`/transaction-status heuristics. Retain keyed events through the Run
lifetime. Aggregate fixture cleanup must delete the event and Run in one transaction.

Keep the 30-second renewal interval independent of read projections and callbacks. Serialize
mutations, retain the original unknown renewal payload/key, and read current ownership after
receipt recovery. A historical successful receipt does not confer current control. Fence reads
by generation and Run lifetime; invalidate on hiding, disconnect, failure or elapsed expiry.
Compute conservative display expiry from request-start monotonic time plus the server's
remaining duration, counting the round trip against it. Publish unavailable ownership to all
Resume/discretionary surfaces, including already-open dialogs; safety Stop/Pause and exact
runtime answers remain independently authorized.

Retain unresolved renewal requests in bounded session storage before dispatch so a Run-state
remount or reload recovers the exact key. A document-wide mutation guard prevents remounts
from overlapping outstanding mutations. Distinguish temporary `checking` from unavailable
ownership: disable an open confirmation during reconciliation, then keep it only if the
same epoch remains current. Compare proposal epochs even when the same actor reacquires.
For unknown conversational confirmations, an authoritative queued/applied history receipt
can resolve the dialog; test exact authenticated replay without forcing that dialog to stay
open. A retained recovery dialog clears old connection refusal text when the gate reopens.

Next 16.3.4 serializes browser Server Actions in one router queue, including actions used
only for reads. A controller read held in that queue also blocks renewal and independent
safety actions; invalidating its presentation does not release the queue. Controller reads
therefore use a freshly authorized, no-store GET with cancellable same-origin fetch.
Mutation actions retain their existing authority. Test slow reads through the real GET
transport and prove safety persistence before releasing the held response. Settle initial
hydration/stream refreshes before delaying an ownership projection for expiry assertions.

Route tests that dynamically import the full infrastructure graph must warm that import
in a bounded setup hook, as the session-route tests do. A cold import inside a five-second
request test can time out and let its continuation read the next case's mocks. Keep request
assertions unchanged; account for module transformation in setup rather than request time.

### D3 manager transfer authority approved (2026-09-20)

The user approved a separately granted `run.control-transfer` permission for Audit Managers,
with a required reason and audited controller epoch change. Administrator status alone is
insufficient. Preserve accepted Pause/Stop requests and all independent answer, approval and
review permissions. Implementation must prove exact retries and stale-direction fencing;
approval does not enable an unimplemented permission or authorize deployment. See
`_bmad-output/implementation-artifacts/decision-aw-manager-transfer-d3.md`.

### Conversational answers retain the question, not the latest wait (2026-09-20)

Capture the server-read question anchor and independent selected record at the first
nonempty draft. Current-wait/record refresh must preserve an uncertain intake's exact
payload and key. Resolve only a unique whole option ID or label, optionally prefixed
`answer:`; no inferred synonyms, conditions or negation stripping. Preserve other
conversation intents and the existing exact safety phrase rules.

The canonical question digest includes the ordered complete option objects, exact
question text, raised-event identity, work item, step, supporting evidence and matching
rationale source. A latest model turn without that evidence/step binding is not the
question source. Lock the Run and addressed wait; missing/inconsistent provenance makes
conversational answering unavailable without disabling the existing decision card.

Answer confirmation remains lease-independent in the opener, modal, submit guard and
invalidation effect. It reuses `answerEscalation` with trusted dependency metadata, never
chat text as a worker note. Decorate the nested WaitContext's actual audit writer so the
authoritative event and closed wait share the outer transaction's server timestamp.
`run_wait.answer_command_id` binds the closure to its exact immutable command, event and
applied receipt through deferred storage guards. Abort retains the answer handler's
existing cancellation path; an answer is not a Stop command. Reauthorize historical
receipt recovery and do not equate it with the current Run state. Aggregate fixture
cleanup must remove retained answer/raise facts and their Run in one transaction.


A definite pre-write conversation refusal must permit draft correction; an unknown delivery
must retain the exact frozen payload and request key. Represent that distinction explicitly
instead of inferring it from a broad error code. Render answer-modal source from the current
read projection, not a cached command: removal of either governed body also removes its
confirmation/source projection, including when the intake lies on another history page.

For maximum-length workspace context, bound source text separately from its action and make
scroll regions keyboard-accessible. Test the expanded disclosure as well as the initial and
populated composer. Keep explicit native POST forms: React function actions on the form
conflict with an explicit method. Put the action on the submitter through Button.formAction
instead, letting React supply its submitter metadata. Do not weaken the form-method guard.
The no-JavaScript browser proof must assert POST, no URL query and the note in the body.

### Manager transfer requires an explicit grant and a retained review (2026-09-20)

`run.control-transfer` has two gates: current Audit Manager role and a separately granted
permission. Revoked grants retain monotonically increasing revisions; demotion/removal
revokes atomically and promotion never restores authority. Administration locks ordered
administrator role rows, then distinct actor/subject identities sorted by ID, before fresh
authorization and audit writes. Reject role identity rewrites in storage. Transfer locks
the Run then manager identity, so grant/role revocation serializes even when a row is absent.

A governed reason proposal freezes the observed controller and epoch. Confirmation accepts
only Run/command IDs. A changed lease cannot rebind the review, and an applied receipt is
historical evidence rather than current ownership. Bind the exceptional live-holder change
to an immutable proposal, durable lease marker, exact domain event and receipt. Keep the
last transfer marker through ordinary renew/release/acquire, and validate the transfer at
fact creation so legitimate later transitions in the same transaction remain possible.
Accepted Pause/Stop and deferred inspection Pause remain safety requests through transfer.

Browser recovery retains a separate monotonic `confirmRequested` flag. A server command ID
alone means only that a proposal exists: reload must recover its reason and require review.
Only a previously attempted confirmation may recover its applied receipt automatically;
then refresh the existing controller GET instead of restoring ownership from that receipt.


## 2026-09-20 — Assert the storage refusal beneath Drizzle's query wrapper

For a deliberate trigger refusal through a Drizzle adapter, assert the PostgreSQL `cause`
with its exact SQLSTATE and message. The outer message describes the failed parameterized
query; matching that message loses the intended invariant and can report a correct guard
as a failed test. Raw postgres client errors keep their SQLSTATE at the top level.

## 2026-09-20 — Retain shared platform events during fixture cleanup

Removing synthetic identities does not permit deleting their events from the shared
`platform` hash chain. Keep those events and its head intact; removing a subset corrupts
later chain verification, even when the events' storage guards allow account removal.
Run-owned aggregate cleanup remains scoped to the complete Run and its own head. Every
new migration table must also appear in the exact schema inventory integration test.

Browser fixture cleanup must lock its Run before deleting children, matching production
read/command ordering while late refreshes finish. To exercise explicit lost-response
retry, delay the competing authoritative refresh until the exact retry settles; otherwise
normal receipt reconciliation can correctly close the dialog before the test clicks it.
Release injected refresh gates in `finally`, preserving the original request and domain
effect assertions rather than increasing timeouts or suppressing the error.

For the full root-test TypeScript graph, run the compiler alone with a 2 GB Node heap
on the 8 GB Codespace; 768 MB exhausts V8 before diagnostics complete. After a Codespace
restart, recreate any ignored cache symlink target under `/tmp` before starting Next.
Temporary directories and running container state do not survive with repository files.

### Synthetic preview ownership and browser deadlines (PR 51 P2)

A settled `withActionDeadline` race is not proof that Playwright I/O stopped. The
preview-enabled LiveWorkspace tracks the actual promises through async context; if
any remain pending on return, it permanently fences and disposes that workspace
before admitting another action or private input. The same coordinator owns
registered captures and preview sampling. Stored sign-in invalidates the local
buffer/epoch before persisting the private fence, then drains actual work before
credential dispatch. A failed authentication or safe-page check does not hand back.

P2 initially supports only explicit `WORKSPACE_PREVIEW_MODE=synthetic-local` in a
non-production environment, with web and one worker on the same loopback host.
Both use the same `WORKSPACE_PREVIEW_SECRET` (minimum 32 characters) and
`WORKSPACE_PREVIEW_PORT` (default 4311). There is no remote worker routing, TLS
listener, provider enablement, or real-data authorization. Metadata generation
0061 must follow manager generation0060; do not apply the draft outside the normal
migration/journal/snapshot sequence. A missing/expired in-memory runtime cannot
reclaim the same workspace revision; a new provisioned revision is required.


### Preview ownership follows the workspace identity, not provisioning CAS (2026-09-21)

`run_workspace.revision` advances twice on every legitimate reattachment. It is a
checkpoint CAS, not a browser incarnation. Bind preview to the stored local workspace
ID and runtime; retain its first claim revision as the public generation. Keep an
unchanged owner alive during `PROVISIONING`, but withhold viewer delivery until OPEN.
A changed workspace ID must have a higher claim generation. The same ID cannot
reclaim an expired runtime, even after its provisioning revision advances. A fenced
Page must also refuse browser attachment so existing recovery can replace it.

Keep a fresh displayed preview while decoding and reauthorizing its replacement;
clearing at every poll produces blank intervals. Private/refused/expired/hidden states
withdraw both displayed and pending object URLs. Browser assertions must not print
session cookie values: compare session distinction as a boolean. A new Playwright
context can inherit configured storageState; explicitly empty it for independent login.

An aria-disabled Resume opener remains focusable and ignores clicks. Acquisition can
trigger another ownership read after its success text appears, so browser proofs must
resolve the enabled opener and assert its dialog before testing later heartbeat events.
Never infer that an asynchronously rendered Acquire control is absent from an immediate
`count()` after reload. Keep retained renewal events and their Run deletion in one
Run-first cleanup transaction, including closed/open wait rows.

## 2026-09-26 — Boundary mutation tests require sequential verification

`tests/unit/boundaries.test.ts` plants `__boundary_violation__/violation.ts` files in the
working tree while it proves each dependency rule. Run `pnpm typecheck`, `pnpm boundaries`
and `pnpm test` sequentially in a worktree; parallel invocation can inspect a deliberate
violation and report a false regression, or race another unit run's cleanup. Separate story
worktrees remain independent. Confirm the runtime used by pnpm itself: a wrapper can pin a
Node executable even when `node` on PATH reports the repository's required version.

### Story 10 screenshot evidence from CI

The opt-in `STORY_VISUAL_CAPTURE=1` helper records actual synthetic browser states at 1280×800 and also 1024×800 for Timeline/Replay. The separate visual workflow retains PNGs and page facts in a small artifact, without changing the existing test gates. A successful capture is evidence to inspect, never a visual approval. Preserve the viewport and scroll position around captures so the original interactions still run.

### Replay narration preserves record keys at 1024 pixels

The Story 10 visual captures showed Chromium wrapping `E-000102` after the hyphen in Replay’s bold narration rail. Use the existing `keySegments` and `ls-nowrap` rendering for the frame’s exact subject key; leave the narration text and image alt unchanged. A passing browser assertion does not detect this typography defect: inspect the 1024×800 capture.
